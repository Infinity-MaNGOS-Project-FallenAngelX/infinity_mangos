/* ALTERAC VALLEY */
-- Scriptnames
UPDATE `creature_template` SET ScriptName = "boss_galvangar" WHERE entry = 11947;
UPDATE `creature_template` SET ScriptName = "boss_balinda" WHERE entry = 11949;
UPDATE `creature_template` SET ScriptName = "boss_vanndar" WHERE entry = 11948;
UPDATE `creature_template` SET ScriptName = "boss_drekthar" WHERE entry = 11946;