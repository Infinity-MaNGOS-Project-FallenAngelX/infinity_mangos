UPDATE creature_template SET ScriptName='spell_dummy_npc' WHERE entry IN (29330,29338,29329);
