UPDATE creature_template SET ScriptName='npc_maxx_a_million' WHERE entry=19589;
