-- The Nexus - The Nexus

UPDATE `creature_template` SET scriptname = 'boss_commander_stoutbeard' where entry = '26796';
UPDATE `creature_template` SET scriptname = 'boss_commander_kolurg' where entry = '26798';