-- Guards

UPDATE `creature_template` SET `ScriptName` = 'g_marcus_jonathan' WHERE `entry` = 466;
UPDATE `creature_template` SET `ScriptName` = 'archbishop_benedictus' WHERE `entry` = 1284;
UPDATE `creature_template` SET `ScriptName` = 'highlord_bolvar_fordragon' WHERE `entry` = 1748;
UPDATE `creature_template` SET `ScriptName` = 'overlord_saurfang' WHERE `entry` = 14720;
UPDATE `creature_template` SET `ScriptName` = 'high_fire_mage' WHERE `entry` IN (17098);
UPDATE `creature_template` SET `ScriptName` = 'ancient_of_war' WHERE `entry` IN (3468,3469);
UPDATE `creature_template` SET `ScriptName` = 'high_sorcerer_andromath' WHERE `entry` = 5694;
UPDATE `creature_template` SET `ScriptName` = 'cathedral_of_light' WHERE `entry` = 6171;
UPDATE `creature_template` SET `ScriptName` = 'city_guard' WHERE `entry` IN (3083,1756,4423,12480,12481,12786,12787,12788,12789,12790,12791,13839,14304,20672,20674);
UPDATE `creature_template` SET `ScriptName` = 'city_officer' WHERE `entry` IN (2041,2439,14363,14365,14367,14375,14376,14377,14378,14379,14380,14402,14403,14404,14423,14438,14439,14440,14441,14442,18103,21970,21971);
