UPDATE creature_template SET AIName='', ScriptName='mob_sladran_constrictor' WHERE entry=29713;
UPDATE creature_template SET AIName='', ScriptName='boss_elemental' WHERE entry = 29573;
UPDATE creature_template SET AIName='', ScriptName='npc_living_mojo' WHERE entry = 29830;
