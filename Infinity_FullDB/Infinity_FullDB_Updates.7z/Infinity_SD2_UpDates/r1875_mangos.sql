UPDATE creature_template SET ScriptName='npc_mosswalker_victim' WHERE entry=28113;
