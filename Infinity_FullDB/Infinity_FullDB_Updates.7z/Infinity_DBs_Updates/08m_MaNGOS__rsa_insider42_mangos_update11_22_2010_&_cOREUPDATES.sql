DELETE FROM `spell_proc_event` WHERE `entry`=46945;
INSERT INTO `spell_proc_event` VALUES
(46945,0x00,4,0x00000000,0x00000000,0x00000000,0x00010000,0x00010000,0x00010000,0x00000000,0x00000000,0x00000000,0x00004000,0x00000000,0,0,0);

UPDATE `creature_template` SET `ScriptName`='mob_ooze_puddle',`scale` = '1.0', `AIName`='', `minlevel` = 82, `maxlevel` = 82, `modelid_1` = 11686, `modelid_2` = 11686, `modelid_3` = 11686, `modelid_4` = 11686, `faction_A` = 14, `faction_H` = 14  WHERE `entry`= 37690;

DELETE FROM `spell_chain` WHERE `first_spell`=46945;
INSERT INTO `spell_chain` VALUES
(46945,0,46945,1,0),
(46949,46945,46945,2,0);

ALTER TABLE db_version CHANGE COLUMN required_10749_01_mangos_mangos_string required_10762_01_mangos_spell_proc_event bit;

DELETE FROM `spell_proc_event` WHERE `entry` IN (52437);
INSERT INTO spell_proc_event VALUES
(52437, 0x00,  4, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000010, 0x00000000, 0.000000, 0.000000,  0);


ALTER TABLE db_version CHANGE COLUMN required_10762_01_mangos_spell_proc_event required_10764_01_mangos_spell_proc_event bit;

DELETE FROM `spell_proc_event` WHERE `entry` IN (74396);
INSERT INTO spell_proc_event VALUES
(74396, 0x00,  3, 0x28E212F7, 0x28E212F7, 0x28E212F7, 0x00119048, 0x00119048, 0x00119048, 0x00000000, 0x00000000, 0x00000000, 0x00010000, 0x00000000, 0.000000, 0.000000,  0);

--- FallenAngelX
ALTER TABLE db_version_Infinity_Update CHANGE COLUMN r07 r08 bit;
REPLACE INTO `db_version_Infinity_Update` (`version`) VALUES ('r08');

UPDATE db_version SET `cache_id`= 'r07';
UPDATE db_version SET `version`= 'YTDB573_Infinity_Update_r08';