/*
Navicat MySQL Data Transfer

Source Server         : 127.0.0.1_3306
Source Server Version : 50045
Source Host           : 127.0.0.1:3306
Source Database       : characters

Target Server Type    : MYSQL
Target Server Version : 50045
File Encoding         : 65001

Date: 2010-12-08 05:08:21
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `account_data`
-- ----------------------------
DROP TABLE IF EXISTS `account_data`;
CREATE TABLE `account_data` (
  `account` int(11) unsigned NOT NULL default '0',
  `type` int(11) unsigned NOT NULL default '0',
  `time` bigint(11) unsigned NOT NULL default '0',
  `data` longblob NOT NULL,
  PRIMARY KEY  (`account`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of account_data
-- ----------------------------
INSERT INTO `account_data` VALUES ('5', '0', '1291800843', 0x534554207363726970744572726F7273202231220A53455420666C61676765645475746F7269616C7320227601220A5345542063616D65726144697374616E63654D6178466163746F72202232220A5345542074616C656E744672616D6553686F776E202231220A);
INSERT INTO `account_data` VALUES ('5', '4', '1289771944', 0x4D4143524F2032202264616D22204162696C6974795F43726561747572655F446973656173655F30350D0A2E64616D616765203130303030300D0A454E440D0A4D4143524F2031202264696522204162696C6974795F43726561747572655F446973656173655F30320D0A2E6469650D0A454E440D0A4D4143524F20352022666C7922204162696C6974795F43726561747572655F4375727365645F30330D0A2E676D20666C79206F6E0D0A454E440D0A4D4143524F20342022696D6D6F7274616C22204162696C6974795F416D627573680D0A2E6D6F646966792068702039393939393939393939393939393939390D0A454E440D0A4D4143524F20332022737070656422204162696C6974795F43726561747572655F446973656173655F30330D0A2E6D6F6469667920737065656420390D0A454E440D0A);
INSERT INTO `account_data` VALUES ('6', '0', '1290957656', 0x534554207363726970744572726F7273202231220A53455420666C61676765645475746F7269616C732022760123234D23232523232623232423233A23232B23234523232823232A23235A23233823235B23233B23234B23232923235C23232D23233F23235E23235D23233723233123233C23234123234223232E23232F232340220A534554206C6F636B416374696F6E42617273202230220A5345542063616D65726156696577202235220A5345542063616D65726144697374616E63654D6178466163746F72202231220A);

-- ----------------------------
-- Table structure for `anticheat_config`
-- ----------------------------
DROP TABLE IF EXISTS `anticheat_config`;
CREATE TABLE `anticheat_config` (
  `checktype` mediumint(8) unsigned NOT NULL COMMENT 'Type of check',
  `description` varchar(255) default NULL,
  `check_period` int(11) unsigned NOT NULL default '0' COMMENT 'Time period of check, in ms, 0 - always',
  `alarmscount` int(11) unsigned NOT NULL default '1' COMMENT 'Count of alarms before action',
  `disableoperation` tinyint(3) unsigned NOT NULL default '0' COMMENT 'Anticheat disable operations in main core code after check fail',
  `messagenum` int(11) NOT NULL default '0' COMMENT 'Number of system message',
  `intparam1` mediumint(8) NOT NULL default '0' COMMENT 'Int parameter 1',
  `intparam2` mediumint(8) NOT NULL default '0' COMMENT 'Int parameter 2',
  `floatparam1` float NOT NULL default '0' COMMENT 'Float parameter 1',
  `floatparam2` float NOT NULL default '0' COMMENT 'Float parameter 2',
  `action1` mediumint(8) NOT NULL default '0' COMMENT 'Action 1',
  `actionparam1` mediumint(8) NOT NULL default '0' COMMENT 'Action parameter 1',
  `action2` mediumint(8) NOT NULL default '0' COMMENT 'Action 1',
  `actionparam2` mediumint(8) NOT NULL default '0' COMMENT 'Action parameter 1',
  PRIMARY KEY  (`checktype`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 PACK_KEYS=0 COMMENT='Anticheat configuration';

-- ----------------------------
-- Records of anticheat_config
-- ----------------------------
INSERT INTO `anticheat_config` VALUES ('0', 'Null check', '0', '1', '0', '11000', '0', '0', '0', '0', '1', '0', '0', '0');
INSERT INTO `anticheat_config` VALUES ('1', 'Movement cheat', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('2', 'Spell cheat', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('3', 'Quest cheat', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('4', 'Transport cheat', '0', '3', '0', '11000', '0', '0', '60', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('5', 'Damage cheat', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('101', 'Speed hack', '500', '5', '0', '11000', '10000', '0', '0.0012', '0', '2', '1', '6', '20000');
INSERT INTO `anticheat_config` VALUES ('102', 'Fly hack', '500', '5', '0', '11000', '20000', '0', '10', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('103', 'Wall climb hack', '500', '2', '0', '11000', '10000', '0', '2.3', '2.37', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('104', 'Waterwalking hack', '1000', '3', '0', '11000', '20000', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('105', 'Teleport to plane hack', '500', '1', '0', '11000', '0', '0', '0.0001', '0.1', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('106', 'AirJump hack', '500', '3', '0', '11000', '30000', '0', '10', '25', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('107', 'Teleport hack', '0', '1', '0', '11000', '0', '0', '50', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('108', 'Fall hack', '0', '3', '0', '11000', '10000', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('201', 'Spell invalid', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('202', 'Spellcast in dead state', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('203', 'Spell not valid for player', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('204', 'Spell not in player book', '0', '1', '0', '11000', '0', '0', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('501', 'Spell damage hack', '0', '1', '0', '11000', '0', '50000', '0', '0', '2', '1', '0', '0');
INSERT INTO `anticheat_config` VALUES ('502', 'Melee damage hack', '0', '1', '0', '11000', '0', '50000', '0', '0', '2', '1', '0', '0');

-- ----------------------------
-- Table structure for `anticheat_log`
-- ----------------------------
DROP TABLE IF EXISTS `anticheat_log`;
CREATE TABLE `anticheat_log` (
  `playername` varchar(32) NOT NULL,
  `checktype` mediumint(8) unsigned NOT NULL,
  `alarm_time` datetime NOT NULL,
  `reason` varchar(255) NOT NULL default 'Unknown',
  `guid` int(11) unsigned NOT NULL,
  `action1` mediumint(8) NOT NULL default '0',
  `action2` mediumint(8) NOT NULL default '0',
  PRIMARY KEY  (`checktype`,`alarm_time`,`guid`),
  KEY `idx_Player` (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Anticheat log table';

-- ----------------------------
-- Records of anticheat_log
-- ----------------------------
INSERT INTO `anticheat_log` VALUES ('Franklin', '106', '2010-11-26 22:19:43', 'AirJump hack Map Z = 64.112885, player Z = 108.896027, opcode MSG_MOVE_SET_FACING', '6', '2', '0');

-- ----------------------------
-- Table structure for `arena_team`
-- ----------------------------
DROP TABLE IF EXISTS `arena_team`;
CREATE TABLE `arena_team` (
  `arenateamid` int(10) unsigned NOT NULL default '0',
  `name` char(255) NOT NULL,
  `captainguid` int(10) unsigned NOT NULL default '0',
  `type` tinyint(3) unsigned NOT NULL default '0',
  `BackgroundColor` int(10) unsigned NOT NULL default '0',
  `EmblemStyle` int(10) unsigned NOT NULL default '0',
  `EmblemColor` int(10) unsigned NOT NULL default '0',
  `BorderStyle` int(10) unsigned NOT NULL default '0',
  `BorderColor` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`arenateamid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of arena_team
-- ----------------------------

-- ----------------------------
-- Table structure for `arena_team_member`
-- ----------------------------
DROP TABLE IF EXISTS `arena_team_member`;
CREATE TABLE `arena_team_member` (
  `arenateamid` int(10) unsigned NOT NULL default '0',
  `guid` int(10) unsigned NOT NULL default '0',
  `played_week` int(10) unsigned NOT NULL default '0',
  `wons_week` int(10) unsigned NOT NULL default '0',
  `played_season` int(10) unsigned NOT NULL default '0',
  `wons_season` int(10) unsigned NOT NULL default '0',
  `personal_rating` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`arenateamid`,`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of arena_team_member
-- ----------------------------

-- ----------------------------
-- Table structure for `arena_team_stats`
-- ----------------------------
DROP TABLE IF EXISTS `arena_team_stats`;
CREATE TABLE `arena_team_stats` (
  `arenateamid` int(10) unsigned NOT NULL default '0',
  `rating` int(10) unsigned NOT NULL default '0',
  `games_week` int(10) unsigned NOT NULL default '0',
  `wins_week` int(10) unsigned NOT NULL default '0',
  `games_season` int(10) unsigned NOT NULL default '0',
  `wins_season` int(10) unsigned NOT NULL default '0',
  `rank` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`arenateamid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of arena_team_stats
-- ----------------------------

-- ----------------------------
-- Table structure for `armory_character_stats`
-- ----------------------------
DROP TABLE IF EXISTS `armory_character_stats`;
CREATE TABLE `armory_character_stats` (
  `guid` int(11) NOT NULL,
  `data` longtext NOT NULL,
  PRIMARY KEY  (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='World of Warcraft Armory table';

-- ----------------------------
-- Records of armory_character_stats
-- ----------------------------

-- ----------------------------
-- Table structure for `armory_game_chart`
-- ----------------------------
DROP TABLE IF EXISTS `armory_game_chart`;
CREATE TABLE `armory_game_chart` (
  `gameid` int(11) NOT NULL,
  `teamid` int(11) NOT NULL,
  `guid` int(11) NOT NULL,
  `changeType` int(11) NOT NULL,
  `ratingChange` int(11) NOT NULL,
  `teamRating` int(11) NOT NULL,
  `damageDone` int(11) NOT NULL,
  `deaths` int(11) NOT NULL,
  `healingDone` int(11) NOT NULL,
  `damageTaken` int(11) NOT NULL,
  `healingTaken` int(11) NOT NULL,
  `killingBlows` int(11) NOT NULL,
  `mapId` int(11) NOT NULL,
  `start` int(11) NOT NULL,
  `end` int(11) NOT NULL,
  PRIMARY KEY  (`gameid`,`teamid`,`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='WoWArmory Game Chart';

-- ----------------------------
-- Records of armory_game_chart
-- ----------------------------

-- ----------------------------
-- Table structure for `auction`
-- ----------------------------
DROP TABLE IF EXISTS `auction`;
CREATE TABLE `auction` (
  `id` int(11) unsigned NOT NULL default '0',
  `houseid` int(11) unsigned NOT NULL default '0',
  `itemguid` int(11) unsigned NOT NULL default '0',
  `item_template` int(11) unsigned NOT NULL default '0' COMMENT 'Item Identifier',
  `itemowner` int(11) unsigned NOT NULL default '0',
  `buyoutprice` int(11) NOT NULL default '0',
  `time` bigint(40) NOT NULL default '0',
  `buyguid` int(11) unsigned NOT NULL default '0',
  `lastbid` int(11) NOT NULL default '0',
  `startbid` int(11) NOT NULL default '0',
  `deposit` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `item_guid` (`itemguid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of auction
-- ----------------------------
INSERT INTO `auction` VALUES ('19527', '2', '20441', '22527', '2', '377872', '1291887386', '0', '0', '294740', '0');
INSERT INTO `auction` VALUES ('19552', '2', '20466', '9060', '2', '63600', '1291844186', '0', '0', '57240', '0');
INSERT INTO `auction` VALUES ('20166', '2', '21080', '1604', '2', '1097769', '1291873046', '0', '0', '955059', '0');
INSERT INTO `auction` VALUES ('20462', '6', '21376', '24711', '2', '1623338', '1291869446', '0', '0', '1525937', '0');
INSERT INTO `auction` VALUES ('19769', '6', '20683', '9719', '2', '368500', '1291844186', '0', '0', '361130', '0');
INSERT INTO `auction` VALUES ('19846', '6', '20760', '827', '2', '61174', '1291869386', '0', '0', '51386', '0');
INSERT INTO `auction` VALUES ('20633', '7', '21547', '36498', '2', '5161961', '1291858646', '0', '0', '4181188', '0');
INSERT INTO `auction` VALUES ('19591', '2', '20505', '36045', '2', '2378732', '1291844186', '0', '0', '2117071', '0');
INSERT INTO `auction` VALUES ('20458', '6', '21372', '44475', '2', '154', '1291869446', '0', '0', '118', '0');
INSERT INTO `auction` VALUES ('19847', '6', '20761', '9719', '2', '425500', '1291833386', '0', '0', '404225', '0');
INSERT INTO `auction` VALUES ('19848', '6', '20762', '9384', '2', '811051', '1291854986', '0', '0', '616398', '0');
INSERT INTO `auction` VALUES ('20933', '7', '21883', '37145', '2', '19720', '1291830991', '0', '0', '18339', '0');
INSERT INTO `auction` VALUES ('19849', '6', '20763', '9060', '2', '89280', '1291876586', '0', '0', '73209', '0');
INSERT INTO `auction` VALUES ('19850', '6', '20764', '9719', '2', '385750', '1291840586', '0', '0', '324030', '0');
INSERT INTO `auction` VALUES ('19851', '6', '20765', '9719', '2', '337500', '1291862186', '0', '0', '307125', '0');
INSERT INTO `auction` VALUES ('19543', '2', '20457', '36172', '2', '1887561', '1291880186', '0', '0', '1585551', '0');
INSERT INTO `auction` VALUES ('19852', '6', '20766', '36056', '2', '2314623', '1291833386', '0', '0', '2106306', '0');
INSERT INTO `auction` VALUES ('20402', '6', '21316', '4402', '2', '3860', '1291837046', '0', '0', '3281', '0');
INSERT INTO `auction` VALUES ('20167', '2', '21081', '36397', '2', '3814637', '1291833446', '0', '0', '3280587', '0');
INSERT INTO `auction` VALUES ('19592', '2', '20506', '6359', '2', '455', '1291876586', '0', '0', '418', '0');
INSERT INTO `auction` VALUES ('20401', '6', '21315', '10559', '2', '75570', '1291847846', '0', '0', '58944', '0');
INSERT INTO `auction` VALUES ('18970', '2', '19884', '9719', '2', '363000', '1291851326', '0', '0', '330330', '0');
INSERT INTO `auction` VALUES ('20168', '2', '21082', '4377', '2', '23760', '1291865846', '0', '0', '22572', '0');
INSERT INTO `auction` VALUES ('19593', '2', '20507', '36430', '2', '2124998', '1291872986', '0', '0', '2018748', '0');
INSERT INTO `auction` VALUES ('19853', '6', '20767', '9719', '2', '360750', '1291844186', '0', '0', '310245', '0');
INSERT INTO `auction` VALUES ('19854', '6', '20768', '1475', '2', '3052', '1291887386', '0', '0', '2960', '0');
INSERT INTO `auction` VALUES ('20186', '2', '21100', '36666', '2', '3877552', '1291887446', '0', '0', '3102041', '0');
INSERT INTO `auction` VALUES ('19855', '6', '20769', '3164', '2', '2527', '1291869386', '0', '0', '2249', '0');
INSERT INTO `auction` VALUES ('19856', '6', '20770', '3164', '2', '618', '1291887386', '0', '0', '574', '0');
INSERT INTO `auction` VALUES ('19551', '2', '20465', '31234', '2', '5964986', '1291836986', '0', '0', '5726386', '0');
INSERT INTO `auction` VALUES ('20187', '2', '21101', '4388', '2', '9640', '1291883846', '0', '0', '7615', '0');
INSERT INTO `auction` VALUES ('19542', '2', '20456', '31181', '2', '960131', '1291847786', '0', '0', '777706', '0');
INSERT INTO `auction` VALUES ('19857', '6', '20771', '2072', '2', '244314', '1291836986', '0', '0', '210110', '0');
INSERT INTO `auction` VALUES ('19858', '6', '20772', '9719', '2', '428500', '1291854986', '0', '0', '338515', '0');
INSERT INTO `auction` VALUES ('19859', '6', '20773', '9719', '2', '318750', '1291887386', '0', '0', '274125', '0');
INSERT INTO `auction` VALUES ('20171', '2', '21085', '25152', '2', '3184557', '1291858646', '0', '0', '3025329', '0');
INSERT INTO `auction` VALUES ('19860', '6', '20774', '24709', '2', '808080', '1291865786', '0', '0', '775756', '0');
INSERT INTO `auction` VALUES ('20706', '2', '21656', '24774', '2', '1511173', '1291866991', '0', '0', '1239161', '0');
INSERT INTO `auction` VALUES ('20246', '2', '21160', '36639', '2', '4659714', '1291837046', '0', '0', '4613116', '0');
INSERT INTO `auction` VALUES ('19861', '6', '20775', '1679', '2', '540545', '1291847786', '0', '0', '464868', '0');
INSERT INTO `auction` VALUES ('19862', '6', '20776', '4359', '2', '507', '1291876586', '0', '0', '476', '0');
INSERT INTO `auction` VALUES ('20634', '7', '21548', '19943', '2', '59040', '1291883846', '0', '0', '47232', '0');
INSERT INTO `auction` VALUES ('19863', '6', '20777', '36046', '2', '1338283', '1291887386', '0', '0', '1324900', '0');
INSERT INTO `auction` VALUES ('19891', '7', '20805', '36528', '2', '6899853', '1291851386', '0', '0', '6623858', '0');
INSERT INTO `auction` VALUES ('19594', '2', '20508', '23329', '2', '76', '1291844186', '0', '0', '65', '0');
INSERT INTO `auction` VALUES ('20433', '6', '21347', '7072', '2', '14400', '1291829846', '0', '0', '10080', '0');
INSERT INTO `auction` VALUES ('19864', '6', '20778', '25268', '2', '1803942', '1291869386', '0', '0', '1605508', '0');
INSERT INTO `auction` VALUES ('20663', '7', '21577', '2265', '2', '25074', '1291844246', '0', '0', '22065', '0');
INSERT INTO `auction` VALUES ('20635', '7', '21549', '9262', '2', '42800', '1291844246', '0', '0', '41088', '0');
INSERT INTO `auction` VALUES ('20691', '2', '21641', '10514', '2', '50190', '1291848991', '0', '0', '48182', '0');
INSERT INTO `auction` VALUES ('20636', '7', '21550', '6359', '2', '314', '1291873046', '0', '0', '279', '0');
INSERT INTO `auction` VALUES ('19865', '6', '20779', '5523', '2', '1116', '1291858586', '0', '0', '814', '0');
INSERT INTO `auction` VALUES ('19866', '6', '20780', '19943', '2', '164160', '1291851386', '0', '0', '126403', '0');
INSERT INTO `auction` VALUES ('19171', '6', '20085', '37160', '2', '12670', '1291833326', '0', '0', '9122', '0');
INSERT INTO `auction` VALUES ('19172', '6', '20086', '31194', '2', '2042001', '1291854926', '0', '0', '1756120', '0');
INSERT INTO `auction` VALUES ('19892', '7', '20806', '14900', '2', '328317', '1291865786', '0', '0', '265936', '0');
INSERT INTO `auction` VALUES ('20432', '6', '21346', '10559', '2', '104580', '1291847846', '0', '0', '100396', '0');
INSERT INTO `auction` VALUES ('20707', '2', '21657', '24825', '2', '813261', '1291830991', '0', '0', '740067', '0');
INSERT INTO `auction` VALUES ('20459', '6', '21373', '36399', '2', '3084405', '1291887446', '0', '0', '2498368', '0');
INSERT INTO `auction` VALUES ('20169', '2', '21083', '18512', '2', '108960', '1291883846', '0', '0', '78451', '0');
INSERT INTO `auction` VALUES ('20170', '2', '21084', '18512', '2', '107520', '1291883846', '0', '0', '91392', '0');
INSERT INTO `auction` VALUES ('19875', '7', '20789', '31157', '2', '3588105', '1291840586', '0', '0', '2762840', '0');
INSERT INTO `auction` VALUES ('20664', '7', '21578', '21882', '2', '305500', '1291865846', '0', '0', '250510', '0');
INSERT INTO `auction` VALUES ('20665', '7', '21579', '27511', '2', '178', '1291840646', '0', '0', '174', '0');
INSERT INTO `auction` VALUES ('19173', '6', '20087', '9719', '2', '346000', '1291887326', '0', '0', '314860', '0');
INSERT INTO `auction` VALUES ('19174', '6', '20088', '13874', '2', '9', '1291858526', '0', '0', '8', '0');
INSERT INTO `auction` VALUES ('20461', '6', '21375', '4463', '2', '45400', '1291837046', '0', '0', '37682', '0');
INSERT INTO `auction` VALUES ('20708', '2', '21658', '5637', '2', '2832', '1291848991', '0', '0', '2605', '0');
INSERT INTO `auction` VALUES ('20431', '6', '21345', '27511', '2', '244', '1291851446', '0', '0', '183', '0');
INSERT INTO `auction` VALUES ('19175', '6', '20089', '16653', '2', '487', '1291858526', '0', '0', '394', '0');
INSERT INTO `auction` VALUES ('20914', '7', '21864', '25054', '2', '1354603', '1291834591', '0', '0', '1246234', '0');
INSERT INTO `auction` VALUES ('20912', '7', '21862', '45909', '2', '2976', '1291845391', '0', '0', '2797', '0');
INSERT INTO `auction` VALUES ('19893', '7', '20807', '9486', '2', '453767', '1291858586', '0', '0', '390239', '0');
INSERT INTO `auction` VALUES ('19526', '2', '20440', '36155', '2', '1094720', '1291844186', '0', '0', '1061878', '0');
INSERT INTO `auction` VALUES ('20666', '7', '21580', '35979', '2', '1092475', '1291833446', '0', '0', '972302', '0');
INSERT INTO `auction` VALUES ('20255', '2', '21169', '880', '2', '110102', '1291844246', '0', '0', '90283', '0');
INSERT INTO `auction` VALUES ('19556', '2', '20470', '28541', '2', '1364543', '1291833386', '0', '0', '1091634', '0');
INSERT INTO `auction` VALUES ('19894', '7', '20808', '9719', '2', '402750', '1291844186', '0', '0', '302062', '0');
INSERT INTO `auction` VALUES ('20188', '2', '21102', '24666', '2', '1278278', '1291876646', '0', '0', '1265495', '0');
INSERT INTO `auction` VALUES ('19176', '6', '20090', '13903', '2', '245', '1291858526', '0', '0', '213', '0');
INSERT INTO `auction` VALUES ('20735', '2', '21685', '36174', '2', '1841404', '1291877791', '0', '0', '1841404', '0');
INSERT INTO `auction` VALUES ('19177', '6', '20091', '1288', '2', '3485', '1291847726', '0', '0', '2857', '0');
INSERT INTO `auction` VALUES ('19178', '6', '20092', '9719', '2', '389750', '1291880126', '0', '0', '323492', '0');
INSERT INTO `auction` VALUES ('20736', '2', '21686', '24722', '2', '1937468', '1291870591', '0', '0', '1646847', '0');
INSERT INTO `auction` VALUES ('19525', '2', '20439', '10562', '2', '9000', '1291854986', '0', '0', '7560', '0');
INSERT INTO `auction` VALUES ('19595', '2', '20509', '5109', '2', '2220', '1291887386', '0', '0', '1909', '0');
INSERT INTO `auction` VALUES ('18875', '2', '19789', '9719', '2', '324750', '1291869326', '0', '0', '272790', '0');
INSERT INTO `auction` VALUES ('19876', '7', '20790', '40195', '2', '57240', '1291851386', '0', '0', '56095', '0');
INSERT INTO `auction` VALUES ('19596', '2', '20510', '13422', '2', '199', '1291869386', '0', '0', '189', '0');
INSERT INTO `auction` VALUES ('20256', '2', '21170', '2166', '2', '35886', '1291858646', '0', '0', '34091', '0');
INSERT INTO `auction` VALUES ('18876', '2', '19790', '2232', '2', '45202', '1291840526', '0', '0', '36161', '0');
INSERT INTO `auction` VALUES ('18877', '2', '19791', '9719', '2', '362500', '1291829726', '0', '0', '358875', '0');
INSERT INTO `auction` VALUES ('20460', '6', '21374', '45909', '2', '7824', '1291873046', '0', '0', '7667', '0');
INSERT INTO `auction` VALUES ('18878', '2', '19792', '7755', '2', '341375', '1291865726', '0', '0', '327720', '0');
INSERT INTO `auction` VALUES ('19895', '7', '20809', '5523', '2', '374', '1291865786', '0', '0', '325', '0');
INSERT INTO `auction` VALUES ('20189', '2', '21103', '31256', '2', '34059', '1291840646', '0', '0', '34059', '0');
INSERT INTO `auction` VALUES ('19550', '2', '20464', '9719', '2', '409500', '1291829786', '0', '0', '343980', '0');
INSERT INTO `auction` VALUES ('19877', '7', '20791', '12804', '2', '12400', '1291844186', '0', '0', '10540', '0');
INSERT INTO `auction` VALUES ('19896', '7', '20810', '4716', '2', '73070', '1291833386', '0', '0', '65763', '0');
INSERT INTO `auction` VALUES ('20413', '6', '21327', '37160', '2', '3925', '1291833446', '0', '0', '3297', '0');
INSERT INTO `auction` VALUES ('20190', '2', '21104', '9262', '2', '157440', '1291887446', '0', '0', '157440', '0');
INSERT INTO `auction` VALUES ('18879', '2', '19793', '3260', '2', '73', '1291829726', '0', '0', '59', '0');
INSERT INTO `auction` VALUES ('20191', '2', '21105', '25208', '2', '4716232', '1291837046', '0', '0', '4386095', '0');
INSERT INTO `auction` VALUES ('20667', '7', '21581', '44700', '2', '4525', '1291865846', '0', '0', '3212', '0');
INSERT INTO `auction` VALUES ('18880', '2', '19794', '37756', '2', '2371056', '1291854926', '0', '0', '2347345', '0');
INSERT INTO `auction` VALUES ('18881', '2', '19795', '9719', '2', '419250', '1291847726', '0', '0', '318630', '0');
INSERT INTO `auction` VALUES ('19597', '2', '20511', '3053', '2', '136476', '1291854986', '0', '0', '122828', '0');
INSERT INTO `auction` VALUES ('20721', '2', '21671', '1288', '2', '5083', '1291863391', '0', '0', '4473', '0');
INSERT INTO `auction` VALUES ('19897', '7', '20811', '9719', '2', '405750', '1291869386', '0', '0', '312427', '0');
INSERT INTO `auction` VALUES ('20913', '7', '21863', '9060', '2', '138320', '1291838191', '0', '0', '134170', '0');
INSERT INTO `auction` VALUES ('18882', '2', '19796', '9719', '2', '332000', '1291869326', '0', '0', '272240', '0');
INSERT INTO `auction` VALUES ('18883', '2', '19797', '2100', '2', '3458913', '1291847726', '0', '0', '3009254', '0');
INSERT INTO `auction` VALUES ('20454', '6', '21368', '44475', '2', '132', '1291858646', '0', '0', '114', '0');
INSERT INTO `auction` VALUES ('18884', '2', '19798', '25326', '2', '4872958', '1291854926', '0', '0', '4434391', '0');
INSERT INTO `auction` VALUES ('18885', '2', '19799', '8152', '2', '60800', '1291844126', '0', '0', '53504', '0');
INSERT INTO `auction` VALUES ('20364', '6', '21278', '28495', '2', '607897', '1291862246', '0', '0', '565344', '0');
INSERT INTO `auction` VALUES ('18886', '2', '19800', '43624', '2', '45990', '1291862126', '0', '0', '45990', '0');
INSERT INTO `auction` VALUES ('18949', '2', '19863', '14553', '2', '2575600', '1291876526', '0', '0', '2215016', '0');
INSERT INTO `auction` VALUES ('18887', '2', '19801', '1608', '2', '778466', '1291880126', '0', '0', '630557', '0');
INSERT INTO `auction` VALUES ('18888', '2', '19802', '1475', '2', '1544', '1291840526', '0', '0', '1158', '0');
INSERT INTO `auction` VALUES ('20737', '2', '21687', '10559', '2', '61200', '1291838191', '0', '0', '54468', '0');
INSERT INTO `auction` VALUES ('20192', '2', '21106', '6358', '2', '480', '1291855046', '0', '0', '436', '0');
INSERT INTO `auction` VALUES ('18889', '2', '19803', '44157', '2', '73525', '1291847726', '0', '0', '63231', '0');
INSERT INTO `auction` VALUES ('18890', '2', '19804', '38513', '2', '11592', '1291829726', '0', '0', '10664', '0');
INSERT INTO `auction` VALUES ('20421', '6', '21335', '9262', '2', '56160', '1291873046', '0', '0', '40996', '0');
INSERT INTO `auction` VALUES ('18891', '2', '19805', '36415', '2', '1604188', '1291833326', '0', '0', '1427727', '0');
INSERT INTO `auction` VALUES ('18892', '2', '19806', '32470', '2', '194000', '1291887326', '0', '0', '180420', '0');
INSERT INTO `auction` VALUES ('18893', '2', '19807', '6359', '2', '591', '1291880126', '0', '0', '466', '0');
INSERT INTO `auction` VALUES ('20193', '2', '21107', '45909', '2', '55296', '1291837046', '0', '0', '48660', '0');
INSERT INTO `auction` VALUES ('20440', '6', '21354', '4660', '2', '14542', '1291847846', '0', '0', '13669', '0');
INSERT INTO `auction` VALUES ('20692', '2', '21642', '27515', '2', '6000', '1291830991', '0', '0', '5940', '0');
INSERT INTO `auction` VALUES ('20257', '2', '21171', '9060', '2', '109760', '1291883846', '0', '0', '104272', '0');
INSERT INTO `auction` VALUES ('18894', '2', '19808', '2246', '2', '4882800', '1291862126', '0', '0', '4199208', '0');
INSERT INTO `auction` VALUES ('19898', '7', '20812', '1300', '2', '95213', '1291887386', '0', '0', '84739', '0');
INSERT INTO `auction` VALUES ('20381', '6', '21295', '12804', '2', '238160', '1291873046', '0', '0', '188146', '0');
INSERT INTO `auction` VALUES ('18895', '2', '19809', '871', '2', '5430812', '1291887326', '0', '0', '4887730', '0');
INSERT INTO `auction` VALUES ('18896', '2', '19810', '31161', '2', '2625603', '1291865726', '0', '0', '2152994', '0');
INSERT INTO `auction` VALUES ('19899', '7', '20813', '9719', '2', '316500', '1291844186', '0', '0', '250035', '0');
INSERT INTO `auction` VALUES ('18897', '2', '19811', '9719', '2', '341750', '1291887326', '0', '0', '334915', '0');
INSERT INTO `auction` VALUES ('19900', '7', '20814', '9719', '2', '418500', '1291880186', '0', '0', '397575', '0');
INSERT INTO `auction` VALUES ('19355', '7', '20269', '30738', '2', '5960523', '1291847726', '0', '0', '5960523', '0');
INSERT INTO `auction` VALUES ('20258', '2', '21172', '5752', '2', '137755', '1291873046', '0', '0', '119846', '0');
INSERT INTO `auction` VALUES ('20521', '7', '21435', '6358', '2', '240', '1291887446', '0', '0', '235', '0');
INSERT INTO `auction` VALUES ('19598', '2', '20512', '9719', '2', '408000', '1291883786', '0', '0', '326400', '0');
INSERT INTO `auction` VALUES ('19319', '7', '20233', '36280', '2', '3425473', '1291840526', '0', '0', '3219944', '0');
INSERT INTO `auction` VALUES ('18898', '2', '19812', '38303', '2', '210000', '1291869326', '0', '0', '203700', '0');
INSERT INTO `auction` VALUES ('20709', '2', '21659', '19441', '2', '36900', '1291881391', '0', '0', '36162', '0');
INSERT INTO `auction` VALUES ('18899', '2', '19813', '17054', '2', '2108764', '1291865726', '0', '0', '1940062', '0');
INSERT INTO `auction` VALUES ('18900', '2', '19814', '2245', '2', '3921633', '1291880126', '0', '0', '3294171', '0');
INSERT INTO `auction` VALUES ('18901', '2', '19815', '9719', '2', '323750', '1291887326', '0', '0', '307562', '0');
INSERT INTO `auction` VALUES ('19878', '7', '20792', '9719', '2', '418500', '1291880186', '0', '0', '376650', '0');
INSERT INTO `auction` VALUES ('20668', '7', '21582', '4723', '2', '92079', '1291858646', '0', '0', '80108', '0');
INSERT INTO `auction` VALUES ('20738', '2', '21688', '6359', '2', '504', '1291848991', '0', '0', '398', '0');
INSERT INTO `auction` VALUES ('19901', '7', '20815', '14832', '2', '211368', '1291865786', '0', '0', '205026', '0');
INSERT INTO `auction` VALUES ('20739', '2', '21689', '36054', '2', '1056990', '1291845391', '0', '0', '1004140', '0');
INSERT INTO `auction` VALUES ('18927', '2', '19841', '1263', '2', '16267582', '1291840526', '0', '0', '14966175', '0');
INSERT INTO `auction` VALUES ('18956', '2', '19870', '1443', '2', '3707015', '1291836926', '0', '0', '3039752', '0');
INSERT INTO `auction` VALUES ('19902', '7', '20816', '10567', '2', '630875', '1291862186', '0', '0', '529935', '0');
INSERT INTO `auction` VALUES ('18902', '2', '19816', '36398', '2', '1982587', '1291862126', '0', '0', '1586069', '0');
INSERT INTO `auction` VALUES ('20439', '6', '21353', '44703', '2', '7639970', '1291883846', '0', '0', '6188375', '0');
INSERT INTO `auction` VALUES ('19885', '7', '20799', '9719', '2', '411000', '1291844186', '0', '0', '341130', '0');
INSERT INTO `auction` VALUES ('19700', '6', '20614', '2738', '2', '8955', '1291829786', '0', '0', '7701', '0');
INSERT INTO `auction` VALUES ('18903', '2', '19817', '1677', '2', '686842', '1291876526', '0', '0', '556342', '0');
INSERT INTO `auction` VALUES ('19726', '6', '20640', '31246', '2', '2225823', '1291829786', '0', '0', '1936466', '0');
INSERT INTO `auction` VALUES ('20194', '2', '21108', '24834', '2', '1776743', '1291873046', '0', '0', '1581301', '0');
INSERT INTO `auction` VALUES ('19356', '7', '20270', '36270', '2', '2158638', '1291858526', '0', '0', '1899601', '0');
INSERT INTO `auction` VALUES ('20363', '6', '21277', '36156', '2', '2670397', '1291858646', '0', '0', '2243133', '0');
INSERT INTO `auction` VALUES ('18904', '2', '19818', '1913', '2', '1567', '1291883726', '0', '0', '1394', '0');
INSERT INTO `auction` VALUES ('18905', '2', '19819', '2099', '2', '9010372', '1291833326', '0', '0', '8649957', '0');
INSERT INTO `auction` VALUES ('20195', '2', '21109', '36402', '2', '1667754', '1291862246', '0', '0', '1434268', '0');
INSERT INTO `auction` VALUES ('19903', '7', '20817', '9719', '2', '319500', '1291851386', '0', '0', '300330', '0');
INSERT INTO `auction` VALUES ('18906', '2', '19820', '6311', '2', '1777', '1291880126', '0', '0', '1634', '0');
INSERT INTO `auction` VALUES ('18907', '2', '19821', '36167', '2', '1792699', '1291869326', '0', '0', '1595502', '0');
INSERT INTO `auction` VALUES ('18937', '2', '19851', '31168', '2', '3309751', '1291829726', '0', '0', '2548508', '0');
INSERT INTO `auction` VALUES ('19357', '7', '20271', '19441', '2', '45000', '1291876526', '0', '0', '34200', '0');
INSERT INTO `auction` VALUES ('20259', '2', '21173', '24780', '2', '767787', '1291855046', '0', '0', '629585', '0');
INSERT INTO `auction` VALUES ('18908', '2', '19822', '5749', '2', '178115', '1291862126', '0', '0', '170990', '0');
INSERT INTO `auction` VALUES ('18909', '2', '19823', '869', '2', '2198537', '1291854926', '0', '0', '1824785', '0');
INSERT INTO `auction` VALUES ('19320', '7', '20234', '24476', '2', '6336', '1291880126', '0', '0', '4625', '0');
INSERT INTO `auction` VALUES ('20438', '6', '21352', '24476', '2', '3540', '1291862246', '0', '0', '2938', '0');
INSERT INTO `auction` VALUES ('19321', '7', '20235', '9719', '2', '413250', '1291829726', '0', '0', '396720', '0');
INSERT INTO `auction` VALUES ('19879', '7', '20793', '36272', '2', '2603280', '1291876586', '0', '0', '2186755', '0');
INSERT INTO `auction` VALUES ('18910', '2', '19824', '24773', '2', '692359', '1291833326', '0', '0', '671588', '0');
INSERT INTO `auction` VALUES ('20637', '7', '21551', '1288', '2', '8547', '1291880246', '0', '0', '8461', '0');
INSERT INTO `auction` VALUES ('18911', '2', '19825', '9719', '2', '342250', '1291862126', '0', '0', '260110', '0');
INSERT INTO `auction` VALUES ('18912', '2', '19826', '1521', '2', '1283894', '1291829726', '0', '0', '1283894', '0');
INSERT INTO `auction` VALUES ('18913', '2', '19827', '24779', '2', '1488822', '1291883726', '0', '0', '1414380', '0');
INSERT INTO `auction` VALUES ('19880', '7', '20794', '4388', '2', '7880', '1291862186', '0', '0', '6067', '0');
INSERT INTO `auction` VALUES ('18914', '2', '19828', '36163', '2', '1309013', '1291833326', '0', '0', '1086480', '0');
INSERT INTO `auction` VALUES ('19338', '7', '20252', '9719', '2', '404500', '1291829726', '0', '0', '368095', '0');
INSERT INTO `auction` VALUES ('18915', '2', '19829', '1982', '2', '3495885', '1291840526', '0', '0', '3041419', '0');
INSERT INTO `auction` VALUES ('20196', '2', '21110', '40199', '2', '366', '1291840646', '0', '0', '278', '0');
INSERT INTO `auction` VALUES ('19631', '2', '20545', '9719', '2', '356000', '1291829786', '0', '0', '291920', '0');
INSERT INTO `auction` VALUES ('19557', '2', '20471', '1489', '2', '133454', '1291854986', '0', '0', '105428', '0');
INSERT INTO `auction` VALUES ('20457', '6', '21371', '9060', '2', '43920', '1291869446', '0', '0', '41724', '0');
INSERT INTO `auction` VALUES ('19558', '2', '20472', '4359', '2', '999', '1291876586', '0', '0', '719', '0');
INSERT INTO `auction` VALUES ('20394', '6', '21308', '5523', '2', '1896', '1291847846', '0', '0', '1839', '0');
INSERT INTO `auction` VALUES ('19555', '2', '20469', '31298', '2', '3858171', '1291880186', '0', '0', '3819589', '0');
INSERT INTO `auction` VALUES ('20089', '2', '21003', '9719', '2', '433750', '1291887446', '0', '0', '325312', '0');
INSERT INTO `auction` VALUES ('20444', '6', '21358', '32717', '2', '1395000', '1291858646', '0', '0', '1395000', '0');
INSERT INTO `auction` VALUES ('20132', '2', '21046', '12804', '2', '123760', '1291862246', '0', '0', '94057', '0');
INSERT INTO `auction` VALUES ('20090', '2', '21004', '45909', '2', '19712', '1291873046', '0', '0', '18529', '0');
INSERT INTO `auction` VALUES ('20484', '7', '21398', '9719', '2', '380750', '1291887446', '0', '0', '357905', '0');
INSERT INTO `auction` VALUES ('20393', '6', '21307', '9262', '2', '133840', '1291851446', '0', '0', '113764', '0');
INSERT INTO `auction` VALUES ('20091', '2', '21005', '9719', '2', '430250', '1291851446', '0', '0', '348502', '0');
INSERT INTO `auction` VALUES ('19559', '2', '20473', '5635', '2', '298', '1291872986', '0', '0', '259', '0');
INSERT INTO `auction` VALUES ('19560', '2', '20474', '12804', '2', '94080', '1291847786', '0', '0', '89376', '0');
INSERT INTO `auction` VALUES ('20483', '7', '21397', '22277', '2', '16', '1291880246', '0', '0', '15', '0');
INSERT INTO `auction` VALUES ('19197', '6', '20111', '7728', '2', '202777', '1291887326', '0', '0', '152082', '0');
INSERT INTO `auction` VALUES ('20133', '2', '21047', '28495', '2', '854503', '1291844246', '0', '0', '683602', '0');
INSERT INTO `auction` VALUES ('18987', '2', '19901', '13916', '2', '1356', '1291851326', '0', '0', '1356', '0');
INSERT INTO `auction` VALUES ('19561', '2', '20475', '8289', '2', '1006310', '1291887386', '0', '0', '986183', '0');
INSERT INTO `auction` VALUES ('19562', '2', '20476', '5524', '2', '963', '1291869386', '0', '0', '895', '0');
INSERT INTO `auction` VALUES ('20684', '2', '21634', '10505', '2', '32470', '1291859791', '0', '0', '26300', '0');
INSERT INTO `auction` VALUES ('19563', '2', '20477', '9719', '2', '427750', '1291829786', '0', '0', '393530', '0');
INSERT INTO `auction` VALUES ('20236', '2', '21150', '36781', '2', '1840', '1291876646', '0', '0', '1619', '0');
INSERT INTO `auction` VALUES ('20704', '2', '21654', '5524', '2', '2295', '1291863391', '0', '0', '2111', '0');
INSERT INTO `auction` VALUES ('20945', '7', '21895', '24713', '2', '1456678', '1291884991', '0', '0', '1412977', '0');
INSERT INTO `auction` VALUES ('19073', '2', '19987', '6148', '2', '544', '1291862126', '0', '0', '446', '0');
INSERT INTO `auction` VALUES ('19564', '2', '20478', '814', '2', '3458', '1291844186', '0', '0', '3112', '0');
INSERT INTO `auction` VALUES ('19763', '6', '20677', '4589', '2', '34725', '1291872986', '0', '0', '27432', '0');
INSERT INTO `auction` VALUES ('20748', '2', '21698', '2072', '2', '258439', '1291877791', '0', '0', '235179', '0');
INSERT INTO `auction` VALUES ('19565', '2', '20479', '20541', '2', '41940', '1291854986', '0', '0', '41520', '0');
INSERT INTO `auction` VALUES ('20657', '7', '21571', '12804', '2', '83600', '1291887446', '0', '0', '72732', '0');
INSERT INTO `auction` VALUES ('20685', '2', '21635', '5742', '2', '473367', '1291874191', '0', '0', '402361', '0');
INSERT INTO `auction` VALUES ('20942', '7', '21892', '24893', '2', '1435064', '1291856191', '0', '0', '1291557', '0');
INSERT INTO `auction` VALUES ('20092', '2', '21006', '2740', '2', '3660', '1291840646', '0', '0', '2745', '0');
INSERT INTO `auction` VALUES ('19566', '2', '20480', '20655', '2', '395451', '1291876586', '0', '0', '316360', '0');
INSERT INTO `auction` VALUES ('20093', '2', '21007', '24826', '2', '1730735', '1291883846', '0', '0', '1574968', '0');
INSERT INTO `auction` VALUES ('19567', '2', '20481', '18676', '2', '1355681', '1291829786', '0', '0', '1274340', '0');
INSERT INTO `auction` VALUES ('19568', '2', '20482', '44700', '2', '3875', '1291840586', '0', '0', '3293', '0');
INSERT INTO `auction` VALUES ('19569', '2', '20483', '36276', '2', '2110366', '1291887386', '0', '0', '1772707', '0');
INSERT INTO `auction` VALUES ('20623', '7', '21537', '36003', '2', '1129434', '1291880246', '0', '0', '960018', '0');
INSERT INTO `auction` VALUES ('20624', '7', '21538', '24773', '2', '984822', '1291840646', '0', '0', '965125', '0');
INSERT INTO `auction` VALUES ('19379', '7', '20293', '45909', '2', '27104', '1291847726', '0', '0', '20056', '0');
INSERT INTO `auction` VALUES ('19570', '2', '20484', '5524', '2', '270', '1291872986', '0', '0', '213', '0');
INSERT INTO `auction` VALUES ('20417', '6', '21331', '24476', '2', '1512', '1291862246', '0', '0', '1058', '0');
INSERT INTO `auction` VALUES ('20209', '2', '21123', '36555', '2', '8089945', '1291883846', '0', '0', '7119151', '0');
INSERT INTO `auction` VALUES ('20763', '2', '21713', '36582', '2', '5683160', '1291845391', '0', '0', '5001180', '0');
INSERT INTO `auction` VALUES ('19536', '2', '20450', '1288', '2', '2530', '1291876586', '0', '0', '1796', '0');
INSERT INTO `auction` VALUES ('20134', '2', '21048', '25264', '2', '2682633', '1291829846', '0', '0', '2441196', '0');
INSERT INTO `auction` VALUES ('20941', '7', '21891', '10505', '2', '26690', '1291856191', '0', '0', '23220', '0');
INSERT INTO `auction` VALUES ('20122', '2', '21036', '10562', '2', '9900', '1291844246', '0', '0', '9306', '0');
INSERT INTO `auction` VALUES ('20764', '2', '21714', '4638', '2', '6416', '1291834591', '0', '0', '5132', '0');
INSERT INTO `auction` VALUES ('20237', '2', '21151', '4767', '2', '8882', '1291858646', '0', '0', '8793', '0');
INSERT INTO `auction` VALUES ('20765', '2', '21715', '1473', '2', '97806', '1291888591', '0', '0', '78244', '0');
INSERT INTO `auction` VALUES ('19074', '2', '19988', '31248', '2', '2510437', '1291858526', '0', '0', '2284497', '0');
INSERT INTO `auction` VALUES ('20715', '2', '21665', '9061', '2', '1640', '1291852591', '0', '0', '1246', '0');
INSERT INTO `auction` VALUES ('20094', '2', '21008', '27516', '2', '15840', '1291844246', '0', '0', '13305', '0');
INSERT INTO `auction` VALUES ('19534', '2', '20448', '865', '2', '219637', '1291887386', '0', '0', '202066', '0');
INSERT INTO `auction` VALUES ('20947', '7', '21897', '36709', '2', '9671760', '1291863391', '0', '0', '8414431', '0');
INSERT INTO `auction` VALUES ('20766', '2', '21716', '24601', '2', '1024542', '1291863391', '0', '0', '850369', '0');
INSERT INTO `auction` VALUES ('20406', '6', '21320', '3019', '2', '23318', '1291847846', '0', '0', '21918', '0');
INSERT INTO `auction` VALUES ('20767', '2', '21717', '36456', '2', '4164009', '1291845391', '0', '0', '3372847', '0');
INSERT INTO `auction` VALUES ('20443', '6', '21357', '1448', '2', '16487', '1291873046', '0', '0', '15168', '0');
INSERT INTO `auction` VALUES ('20135', '2', '21049', '24599', '2', '1612996', '1291887446', '0', '0', '1564606', '0');
INSERT INTO `auction` VALUES ('20944', '7', '21894', '5028', '2', '208210', '1291863391', '0', '0', '206127', '0');
INSERT INTO `auction` VALUES ('20750', '2', '21700', '5637', '2', '1710', '1291877791', '0', '0', '1231', '0');
INSERT INTO `auction` VALUES ('20238', '2', '21152', '36043', '2', '1298170', '1291862246', '0', '0', '1103444', '0');
INSERT INTO `auction` VALUES ('20940', '7', '21890', '3164', '2', '1466', '1291874191', '0', '0', '1422', '0');
INSERT INTO `auction` VALUES ('20731', '2', '21681', '14899', '2', '375390', '1291881391', '0', '0', '360374', '0');
INSERT INTO `auction` VALUES ('19535', '2', '20449', '45909', '2', '17568', '1291876586', '0', '0', '14757', '0');
INSERT INTO `auction` VALUES ('20686', '2', '21636', '2084', '2', '296613', '1291888591', '0', '0', '284748', '0');
INSERT INTO `auction` VALUES ('20625', '7', '21539', '28497', '2', '1218404', '1291883846', '0', '0', '999091', '0');
INSERT INTO `auction` VALUES ('19910', '7', '20824', '9719', '2', '409250', '1291847786', '0', '0', '343770', '0');
INSERT INTO `auction` VALUES ('20768', '2', '21718', '36176', '2', '3160448', '1291888591', '0', '0', '2528358', '0');
INSERT INTO `auction` VALUES ('20658', '7', '21572', '25046', '2', '1156683', '1291851446', '0', '0', '994747', '0');
INSERT INTO `auction` VALUES ('20769', '2', '21719', '2233', '2', '77420', '1291877791', '0', '0', '75097', '0');
INSERT INTO `auction` VALUES ('20095', '2', '21009', '37159', '2', '9600', '1291876646', '0', '0', '6720', '0');
INSERT INTO `auction` VALUES ('20770', '2', '21720', '25138', '2', '4885585', '1291884991', '0', '0', '4250458', '0');
INSERT INTO `auction` VALUES ('20626', '7', '21540', '24601', '2', '1102806', '1291847846', '0', '0', '1069721', '0');
INSERT INTO `auction` VALUES ('20416', '6', '21330', '45909', '2', '35520', '1291865846', '0', '0', '24864', '0');
INSERT INTO `auction` VALUES ('20392', '6', '21306', '9061', '2', '28900', '1291837046', '0', '0', '27744', '0');
INSERT INTO `auction` VALUES ('20239', '2', '21153', '36383', '2', '2682115', '1291858646', '0', '0', '2655293', '0');
INSERT INTO `auction` VALUES ('20096', '2', '21010', '9444', '2', '12716', '1291829846', '0', '0', '9409', '0');
INSERT INTO `auction` VALUES ('20771', '6', '21721', '10561', '2', '99600', '1291884991', '0', '0', '98604', '0');
INSERT INTO `auction` VALUES ('20716', '2', '21666', '36058', '2', '1062103', '1291888591', '0', '0', '945271', '0');
INSERT INTO `auction` VALUES ('20128', '2', '21042', '36584', '2', '6162346', '1291865846', '0', '0', '5730981', '0');
INSERT INTO `auction` VALUES ('20136', '2', '21050', '5635', '2', '1074', '1291840646', '0', '0', '869', '0');
INSERT INTO `auction` VALUES ('20659', '7', '21573', '6359', '2', '402', '1291840646', '0', '0', '377', '0');
INSERT INTO `auction` VALUES ('20405', '6', '21319', '36063', '2', '1441095', '1291880246', '0', '0', '1152876', '0');
INSERT INTO `auction` VALUES ('20137', '2', '21051', '24608', '2', '633470', '1291851446', '0', '0', '519445', '0');
INSERT INTO `auction` VALUES ('20138', '2', '21052', '5523', '2', '498', '1291844246', '0', '0', '368', '0');
INSERT INTO `auction` VALUES ('20772', '6', '21722', '35995', '2', '969485', '1291841791', '0', '0', '882231', '0');
INSERT INTO `auction` VALUES ('20773', '6', '21723', '25172', '2', '3750461', '1291830991', '0', '0', '3750461', '0');
INSERT INTO `auction` VALUES ('20660', '7', '21574', '4359', '2', '1762', '1291847846', '0', '0', '1480', '0');
INSERT INTO `auction` VALUES ('20946', '7', '21896', '24779', '2', '1108113', '1291834591', '0', '0', '1041626', '0');
INSERT INTO `auction` VALUES ('20732', '2', '21682', '6360', '2', '110595', '1291845391', '0', '0', '103959', '0');
INSERT INTO `auction` VALUES ('20774', '6', '21724', '37159', '2', '19975', '1291845391', '0', '0', '15780', '0');
INSERT INTO `auction` VALUES ('20775', '6', '21725', '37159', '2', '7665', '1291874191', '0', '0', '7128', '0');
INSERT INTO `auction` VALUES ('20097', '2', '21011', '12804', '2', '284800', '1291829846', '0', '0', '207904', '0');
INSERT INTO `auction` VALUES ('20751', '2', '21701', '36398', '2', '1957899', '1291834591', '0', '0', '1840425', '0');
INSERT INTO `auction` VALUES ('20098', '2', '21012', '2204', '2', '46509', '1291851446', '0', '0', '42323', '0');
INSERT INTO `auction` VALUES ('20422', '6', '21336', '4402', '2', '9120', '1291858646', '0', '0', '7934', '0');
INSERT INTO `auction` VALUES ('20127', '2', '21041', '6358', '2', '541', '1291855046', '0', '0', '443', '0');
INSERT INTO `auction` VALUES ('19545', '2', '20459', '36168', '2', '3600989', '1291829786', '0', '0', '3096850', '0');
INSERT INTO `auction` VALUES ('20378', '6', '21292', '36708', '2', '5632767', '1291869446', '0', '0', '4844179', '0');
INSERT INTO `auction` VALUES ('20119', '2', '21033', '36597', '2', '6919922', '1291837046', '0', '0', '6089531', '0');
INSERT INTO `auction` VALUES ('20404', '6', '21318', '1523', '2', '541267', '1291837046', '0', '0', '465489', '0');
INSERT INTO `auction` VALUES ('20117', '2', '21031', '9719', '2', '393250', '1291865846', '0', '0', '389317', '0');
INSERT INTO `auction` VALUES ('20749', '2', '21699', '9061', '2', '40800', '1291830991', '0', '0', '35088', '0');
INSERT INTO `auction` VALUES ('20776', '6', '21726', '1475', '2', '646', '1291845391', '0', '0', '516', '0');
INSERT INTO `auction` VALUES ('20777', '6', '21727', '25068', '2', '1621548', '1291863391', '0', '0', '1621548', '0');
INSERT INTO `auction` VALUES ('20778', '6', '21728', '20655', '2', '539618', '1291863391', '0', '0', '485656', '0');
INSERT INTO `auction` VALUES ('20705', '2', '21655', '45909', '2', '33824', '1291838191', '0', '0', '30779', '0');
INSERT INTO `auction` VALUES ('20507', '7', '21421', '25744', '2', '1121276', '1291876646', '0', '0', '818531', '0');
INSERT INTO `auction` VALUES ('20687', '2', '21637', '27513', '2', '127', '1291874191', '0', '0', '114', '0');
INSERT INTO `auction` VALUES ('20717', '2', '21667', '36598', '2', '9223178', '1291856191', '0', '0', '7563005', '0');
INSERT INTO `auction` VALUES ('20779', '6', '21729', '21882', '2', '78500', '1291877791', '0', '0', '61230', '0');
INSERT INTO `auction` VALUES ('20780', '6', '21730', '2623', '2', '241179', '1291838191', '0', '0', '214649', '0');
INSERT INTO `auction` VALUES ('20752', '2', '21702', '814', '2', '1512', '1291888591', '0', '0', '1164', '0');
INSERT INTO `auction` VALUES ('20781', '6', '21731', '5524', '2', '2918', '1291841791', '0', '0', '2655', '0');
INSERT INTO `auction` VALUES ('20733', '2', '21683', '40199', '2', '2688', '1291845391', '0', '0', '1989', '0');
INSERT INTO `auction` VALUES ('20240', '2', '21154', '45909', '2', '27216', '1291858646', '0', '0', '20956', '0');
INSERT INTO `auction` VALUES ('20782', '6', '21732', '1943', '2', '40699', '1291866991', '0', '0', '36629', '0');
INSERT INTO `auction` VALUES ('20783', '6', '21733', '37147', '2', '3060', '1291888591', '0', '0', '2907', '0');
INSERT INTO `auction` VALUES ('20688', '2', '21638', '27515', '2', '24200', '1291834591', '0', '0', '18392', '0');
INSERT INTO `auction` VALUES ('20241', '2', '21155', '8152', '2', '20280', '1291862246', '0', '0', '19874', '0');
INSERT INTO `auction` VALUES ('20506', '7', '21420', '5523', '2', '1734', '1291829846', '0', '0', '1265', '0');
INSERT INTO `auction` VALUES ('20718', '2', '21668', '19441', '2', '14640', '1291834591', '0', '0', '12590', '0');
INSERT INTO `auction` VALUES ('20377', '6', '21291', '36158', '2', '1293590', '1291880246', '0', '0', '1112487', '0');
INSERT INTO `auction` VALUES ('20536', '7', '21450', '15687', '2', '1846804', '1291869446', '0', '0', '1699059', '0');
INSERT INTO `auction` VALUES ('20689', '2', '21639', '13422', '2', '1237', '1291881391', '0', '0', '890', '0');
INSERT INTO `auction` VALUES ('20784', '6', '21734', '21882', '2', '270000', '1291856191', '0', '0', '243000', '0');
INSERT INTO `auction` VALUES ('19163', '6', '20077', '4388', '2', '7040', '1291858526', '0', '0', '5913', '0');
INSERT INTO `auction` VALUES ('20139', '2', '21053', '9262', '2', '96000', '1291837046', '0', '0', '83520', '0');
INSERT INTO `auction` VALUES ('20535', '7', '21449', '24611', '2', '1133121', '1291844246', '0', '0', '1042471', '0');
INSERT INTO `auction` VALUES ('20627', '7', '21541', '10505', '2', '30970', '1291862246', '0', '0', '21988', '0');
INSERT INTO `auction` VALUES ('20403', '6', '21317', '4377', '2', '13266', '1291858646', '0', '0', '12602', '0');
INSERT INTO `auction` VALUES ('20099', '2', '21013', '2021', '2', '54264', '1291862246', '0', '0', '54264', '0');
INSERT INTO `auction` VALUES ('20785', '6', '21735', '24662', '2', '1047465', '1291870591', '0', '0', '921769', '0');
INSERT INTO `auction` VALUES ('20505', '7', '21419', '28531', '2', '946893', '1291880246', '0', '0', '946893', '0');
INSERT INTO `auction` VALUES ('20786', '6', '21736', '40199', '2', '5868', '1291884991', '0', '0', '5574', '0');
INSERT INTO `auction` VALUES ('20787', '6', '21737', '40199', '2', '7632', '1291852591', '0', '0', '7097', '0');
INSERT INTO `auction` VALUES ('20456', '6', '21370', '36666', '2', '4848948', '1291873046', '0', '0', '4412542', '0');
INSERT INTO `auction` VALUES ('20661', '7', '21575', '40199', '2', '4374', '1291847846', '0', '0', '3236', '0');
INSERT INTO `auction` VALUES ('20788', '6', '21738', '5524', '2', '2983', '1291830991', '0', '0', '2625', '0');
INSERT INTO `auction` VALUES ('20415', '6', '21329', '4394', '2', '108000', '1291873046', '0', '0', '76680', '0');
INSERT INTO `auction` VALUES ('20242', '2', '21156', '3042', '2', '283811', '1291858646', '0', '0', '241239', '0');
INSERT INTO `auction` VALUES ('20734', '2', '21684', '1944', '2', '15862', '1291863391', '0', '0', '13482', '0');
INSERT INTO `auction` VALUES ('20789', '6', '21739', '1927', '2', '32094', '1291874191', '0', '0', '32094', '0');
INSERT INTO `auction` VALUES ('20243', '2', '21157', '5523', '2', '2223', '1291851446', '0', '0', '1689', '0');
INSERT INTO `auction` VALUES ('19164', '6', '20078', '14549', '2', '2312255', '1291880126', '0', '0', '1942294', '0');
INSERT INTO `auction` VALUES ('20790', '6', '21740', '44700', '2', '5150', '1291838191', '0', '0', '5047', '0');
INSERT INTO `auction` VALUES ('20546', '7', '21460', '35955', '2', '1159653', '1291880246', '0', '0', '1090073', '0');
INSERT INTO `auction` VALUES ('20517', '7', '21431', '4402', '2', '8850', '1291880246', '0', '0', '6549', '0');
INSERT INTO `auction` VALUES ('20100', '2', '21014', '36541', '2', '7980434', '1291840646', '0', '0', '6863173', '0');
INSERT INTO `auction` VALUES ('20516', '7', '21430', '9060', '2', '79040', '1291858646', '0', '0', '63232', '0');
INSERT INTO `auction` VALUES ('19165', '6', '20079', '37756', '2', '2283798', '1291829726', '0', '0', '2123932', '0');
INSERT INTO `auction` VALUES ('20791', '6', '21741', '4394', '2', '129600', '1291852591', '0', '0', '102384', '0');
INSERT INTO `auction` VALUES ('20628', '7', '21542', '24609', '2', '1129136', '1291855046', '0', '0', '1027513', '0');
INSERT INTO `auction` VALUES ('20140', '2', '21054', '25326', '2', '4770481', '1291844246', '0', '0', '4293432', '0');
INSERT INTO `auction` VALUES ('20141', '2', '21055', '36570', '2', '7204330', '1291880246', '0', '0', '6411853', '0');
INSERT INTO `auction` VALUES ('20142', '2', '21056', '8151', '2', '14220', '1291851446', '0', '0', '10522', '0');
INSERT INTO `auction` VALUES ('20143', '2', '21057', '45909', '2', '12560', '1291880246', '0', '0', '10801', '0');
INSERT INTO `auction` VALUES ('19884', '7', '20798', '1384', '2', '87', '1291862186', '0', '0', '66', '0');
INSERT INTO `auction` VALUES ('20442', '6', '21356', '36388', '2', '3305583', '1291862246', '0', '0', '2743633', '0');
INSERT INTO `auction` VALUES ('20792', '6', '21742', '20694', '2', '646104', '1291830991', '0', '0', '516883', '0');
INSERT INTO `auction` VALUES ('18944', '2', '19858', '16655', '2', '625', '1291880126', '0', '0', '456', '0');
INSERT INTO `auction` VALUES ('20793', '6', '21743', '5743', '2', '83116', '1291863391', '0', '0', '75635', '0');
INSERT INTO `auction` VALUES ('20794', '6', '21744', '1560', '2', '21862', '1291848991', '0', '0', '21643', '0');
INSERT INTO `auction` VALUES ('20144', '2', '21058', '36428', '2', '1406016', '1291837046', '0', '0', '1152933', '0');
INSERT INTO `auction` VALUES ('20487', '7', '21401', '2730', '2', '12660', '1291876646', '0', '0', '10128', '0');
INSERT INTO `auction` VALUES ('20795', '6', '21745', '39682', '2', '391680', '1291834591', '0', '0', '301593', '0');
INSERT INTO `auction` VALUES ('20662', '7', '21576', '3011', '2', '126264', '1291862246', '0', '0', '104799', '0');
INSERT INTO `auction` VALUES ('19403', '7', '20317', '9719', '2', '436500', '1291872926', '0', '0', '388485', '0');
INSERT INTO `auction` VALUES ('20796', '6', '21746', '10333', '2', '132406', '1291830991', '0', '0', '109896', '0');
INSERT INTO `auction` VALUES ('20797', '6', '21747', '1460', '2', '86828', '1291834591', '0', '0', '72067', '0');
INSERT INTO `auction` VALUES ('20753', '2', '21703', '27511', '2', '186', '1291838191', '0', '0', '130', '0');
INSERT INTO `auction` VALUES ('20244', '2', '21158', '7072', '2', '3648', '1291833446', '0', '0', '3246', '0');
INSERT INTO `auction` VALUES ('20629', '7', '21543', '36626', '2', '4729238', '1291873046', '0', '0', '4114437', '0');
INSERT INTO `auction` VALUES ('20798', '6', '21748', '36781', '2', '30552', '1291877791', '0', '0', '26274', '0');
INSERT INTO `auction` VALUES ('20799', '6', '21749', '24775', '2', '2364353', '1291866991', '0', '0', '2056987', '0');
INSERT INTO `auction` VALUES ('20800', '6', '21750', '5523', '2', '2187', '1291848991', '0', '0', '1924', '0');
INSERT INTO `auction` VALUES ('20486', '7', '21400', '2054', '2', '144', '1291855046', '0', '0', '106', '0');
INSERT INTO `auction` VALUES ('18943', '2', '19857', '44708', '2', '14604235', '1291840526', '0', '0', '11245260', '0');
INSERT INTO `auction` VALUES ('20545', '7', '21459', '25047', '2', '1430745', '1291837046', '0', '0', '1373515', '0');
INSERT INTO `auction` VALUES ('19314', '7', '20228', '4454', '2', '290730', '1291844126', '0', '0', '241305', '0');
INSERT INTO `auction` VALUES ('18942', '2', '19856', '22528', '2', '302720', '1291836926', '0', '0', '278502', '0');
INSERT INTO `auction` VALUES ('20145', '2', '21059', '10560', '2', '54040', '1291847846', '0', '0', '47014', '0');
INSERT INTO `auction` VALUES ('19297', '7', '20211', '2163', '2', '6793969', '1291851326', '0', '0', '5978692', '0');
INSERT INTO `auction` VALUES ('20801', '6', '21751', '41119', '2', '21360', '1291848991', '0', '0', '16447', '0');
INSERT INTO `auction` VALUES ('20178', '2', '21092', '37147', '2', '10125', '1291858646', '0', '0', '8910', '0');
INSERT INTO `auction` VALUES ('20386', '6', '21300', '5637', '2', '492', '1291873046', '0', '0', '354', '0');
INSERT INTO `auction` VALUES ('20854', '6', '21804', '3330', '2', '14805', '1291870591', '0', '0', '13472', '0');
INSERT INTO `auction` VALUES ('20121', '2', '21035', '45909', '2', '16320', '1291851446', '0', '0', '14035', '0');
INSERT INTO `auction` VALUES ('20855', '6', '21805', '28496', '2', '761754', '1291841791', '0', '0', '632255', '0');
INSERT INTO `auction` VALUES ('19609', '2', '20523', '41119', '2', '42400', '1291876586', '0', '0', '36888', '0');
INSERT INTO `auction` VALUES ('20177', '2', '21091', '5523', '2', '241', '1291851446', '0', '0', '180', '0');
INSERT INTO `auction` VALUES ('20426', '6', '21340', '36266', '2', '1880788', '1291833446', '0', '0', '1861980', '0');
INSERT INTO `auction` VALUES ('20210', '2', '21124', '36781', '2', '26064', '1291837046', '0', '0', '22415', '0');
INSERT INTO `auction` VALUES ('20856', '6', '21806', '24937', '2', '1114948', '1291884991', '0', '0', '936556', '0');
INSERT INTO `auction` VALUES ('20857', '6', '21807', '17969', '2', '195150', '1291845391', '0', '0', '191247', '0');
INSERT INTO `auction` VALUES ('20152', '2', '21066', '13422', '2', '972', '1291844246', '0', '0', '797', '0');
INSERT INTO `auction` VALUES ('20425', '6', '21339', '4676', '2', '16471', '1291847846', '0', '0', '15153', '0');
INSERT INTO `auction` VALUES ('20858', '6', '21808', '36270', '2', '1764864', '1291859791', '0', '0', '1429539', '0');
INSERT INTO `auction` VALUES ('19649', '2', '20563', '4611', '2', '3360', '1291858586', '0', '0', '3292', '0');
INSERT INTO `auction` VALUES ('19610', '2', '20524', '9719', '2', '321250', '1291887386', '0', '0', '285912', '0');
INSERT INTO `auction` VALUES ('20954', '7', '21904', '5750', '2', '41941', '1291841791', '0', '0', '40682', '0');
INSERT INTO `auction` VALUES ('20153', '2', '21067', '24711', '2', '1944486', '1291862246', '0', '0', '1730592', '0');
INSERT INTO `auction` VALUES ('19549', '2', '20463', '9719', '2', '372500', '1291836986', '0', '0', '338975', '0');
INSERT INTO `auction` VALUES ('20722', '2', '21672', '18588', '2', '6208', '1291841791', '0', '0', '5090', '0');
INSERT INTO `auction` VALUES ('20948', '7', '21898', '32718', '2', '546500', '1291884991', '0', '0', '453595', '0');
INSERT INTO `auction` VALUES ('20564', '7', '21478', '4377', '2', '16224', '1291837046', '0', '0', '14439', '0');
INSERT INTO `auction` VALUES ('19611', '2', '20525', '34828', '2', '1319010', '1291854986', '0', '0', '1226679', '0');
INSERT INTO `auction` VALUES ('20181', '2', '21095', '36155', '2', '1582571', '1291865846', '0', '0', '1503442', '0');
INSERT INTO `auction` VALUES ('20211', '2', '21125', '3341', '2', '65196', '1291869446', '0', '0', '57372', '0');
INSERT INTO `auction` VALUES ('20565', '7', '21479', '4387', '2', '33696', '1291837046', '0', '0', '24261', '0');
INSERT INTO `auction` VALUES ('20400', '6', '21314', '36274', '2', '1449287', '1291829846', '0', '0', '1449287', '0');
INSERT INTO `auction` VALUES ('20154', '2', '21068', '6358', '2', '633', '1291869446', '0', '0', '525', '0');
INSERT INTO `auction` VALUES ('20640', '7', '21554', '5637', '2', '2916', '1291847846', '0', '0', '2391', '0');
INSERT INTO `auction` VALUES ('19911', '7', '20825', '18588', '2', '6656', '1291872986', '0', '0', '5724', '0');
INSERT INTO `auction` VALUES ('20566', '7', '21480', '2166', '2', '43388', '1291829846', '0', '0', '37313', '0');
INSERT INTO `auction` VALUES ('20567', '7', '21481', '6199', '2', '35386', '1291847846', '0', '0', '31139', '0');
INSERT INTO `auction` VALUES ('19548', '2', '20462', '24890', '2', '1927579', '1291829786', '0', '0', '1927579', '0');
INSERT INTO `auction` VALUES ('20212', '2', '21126', '4589', '2', '22408', '1291873046', '0', '0', '19719', '0');
INSERT INTO `auction` VALUES ('20641', '7', '21555', '37145', '2', '20400', '1291833446', '0', '0', '19176', '0');
INSERT INTO `auction` VALUES ('20949', '7', '21899', '3569', '2', '61901', '1291848991', '0', '0', '50139', '0');
INSERT INTO `auction` VALUES ('20610', '7', '21524', '5637', '2', '2364', '1291833446', '0', '0', '2222', '0');
INSERT INTO `auction` VALUES ('20568', '7', '21482', '9060', '2', '155520', '1291865846', '0', '0', '129081', '0');
INSERT INTO `auction` VALUES ('20611', '7', '21525', '5182', '2', '90082', '1291880246', '0', '0', '74768', '0');
INSERT INTO `auction` VALUES ('20569', '7', '21483', '24722', '2', '1699122', '1291851446', '0', '0', '1478236', '0');
INSERT INTO `auction` VALUES ('20757', '2', '21707', '8245', '2', '539535', '1291866991', '0', '0', '523348', '0');
INSERT INTO `auction` VALUES ('20671', '7', '21585', '13757', '2', '1908', '1291883846', '0', '0', '1354', '0');
INSERT INTO `auction` VALUES ('20464', '6', '21378', '10560', '2', '34400', '1291865846', '0', '0', '28552', '0');
INSERT INTO `auction` VALUES ('20570', '7', '21484', '1677', '2', '705010', '1291840646', '0', '0', '648609', '0');
INSERT INTO `auction` VALUES ('20155', '2', '21069', '37160', '2', '17840', '1291851446', '0', '0', '17483', '0');
INSERT INTO `auction` VALUES ('20642', '7', '21556', '6205', '2', '37927', '1291833446', '0', '0', '33375', '0');
INSERT INTO `auction` VALUES ('20156', '2', '21070', '17963', '2', '7686', '1291855046', '0', '0', '6379', '0');
INSERT INTO `auction` VALUES ('19579', '2', '20493', '6358', '2', '424', '1291876586', '0', '0', '322', '0');
INSERT INTO `auction` VALUES ('20411', '6', '21325', '756', '2', '274746', '1291865846', '0', '0', '241776', '0');
INSERT INTO `auction` VALUES ('19580', '2', '20494', '23329', '2', '80', '1291844186', '0', '0', '72', '0');
INSERT INTO `auction` VALUES ('19581', '2', '20495', '40199', '2', '5940', '1291829786', '0', '0', '5227', '0');
INSERT INTO `auction` VALUES ('20643', '7', '21557', '4589', '2', '11956', '1291865846', '0', '0', '9923', '0');
INSERT INTO `auction` VALUES ('20496', '7', '21410', '44475', '2', '129', '1291873046', '0', '0', '125', '0');
INSERT INTO `auction` VALUES ('19912', '7', '20826', '9719', '2', '365500', '1291865786', '0', '0', '310675', '0');
INSERT INTO `auction` VALUES ('20213', '2', '21127', '10560', '2', '48000', '1291862246', '0', '0', '37920', '0');
INSERT INTO `auction` VALUES ('20495', '7', '21409', '24476', '2', '2688', '1291858646', '0', '0', '2284', '0');
INSERT INTO `auction` VALUES ('20612', '7', '21526', '24828', '2', '1594719', '1291851446', '0', '0', '1514983', '0');
INSERT INTO `auction` VALUES ('20214', '2', '21128', '9262', '2', '158440', '1291887446', '0', '0', '134674', '0');
INSERT INTO `auction` VALUES ('20465', '6', '21379', '9262', '2', '28000', '1291855046', '0', '0', '24920', '0');
INSERT INTO `auction` VALUES ('19913', '7', '20827', '10561', '2', '38400', '1291862186', '0', '0', '28416', '0');
INSERT INTO `auction` VALUES ('19914', '7', '20828', '4656', '2', '43', '1291844186', '0', '0', '38', '0');
INSERT INTO `auction` VALUES ('20215', '2', '21129', '24887', '2', '1835394', '1291887446', '0', '0', '1523377', '0');
INSERT INTO `auction` VALUES ('20399', '6', '21313', '8224', '2', '357525', '1291840646', '0', '0', '350374', '0');
INSERT INTO `auction` VALUES ('20466', '6', '21380', '5635', '2', '306', '1291840646', '0', '0', '293', '0');
INSERT INTO `auction` VALUES ('20672', '7', '21586', '8152', '2', '72000', '1291844246', '0', '0', '57600', '0');
INSERT INTO `auction` VALUES ('20950', '7', '21900', '24601', '2', '914262', '1291856191', '0', '0', '740552', '0');
INSERT INTO `auction` VALUES ('20179', '2', '21093', '25033', '2', '778125', '1291883846', '0', '0', '669187', '0');
INSERT INTO `auction` VALUES ('20216', '2', '21130', '2077', '2', '298745', '1291844246', '0', '0', '292770', '0');
INSERT INTO `auction` VALUES ('20723', '2', '21673', '5523', '2', '1128', '1291866991', '0', '0', '1049', '0');
INSERT INTO `auction` VALUES ('20410', '6', '21324', '10562', '2', '116280', '1291865846', '0', '0', '83721', '0');
INSERT INTO `auction` VALUES ('19582', '2', '20496', '1639', '2', '1506967', '1291840586', '0', '0', '1416548', '0');
INSERT INTO `auction` VALUES ('20494', '7', '21408', '3164', '2', '3375', '1291840646', '0', '0', '2632', '0');
INSERT INTO `auction` VALUES ('19583', '2', '20497', '2300', '2', '10428', '1291829786', '0', '0', '8968', '0');
INSERT INTO `auction` VALUES ('20453', '6', '21367', '19441', '2', '24600', '1291858646', '0', '0', '19188', '0');
INSERT INTO `auction` VALUES ('19584', '2', '20498', '4096', '2', '3652', '1291883786', '0', '0', '3177', '0');
INSERT INTO `auction` VALUES ('20157', '2', '21071', '7517', '2', '473795', '1291855046', '0', '0', '440629', '0');
INSERT INTO `auction` VALUES ('20758', '2', '21708', '24712', '2', '961020', '1291830991', '0', '0', '884138', '0');
INSERT INTO `auction` VALUES ('20694', '2', '21644', '36556', '2', '6512946', '1291881391', '0', '0', '5991910', '0');
INSERT INTO `auction` VALUES ('20644', '7', '21558', '4402', '2', '11100', '1291887446', '0', '0', '9768', '0');
INSERT INTO `auction` VALUES ('20250', '2', '21164', '35971', '2', '768610', '1291887446', '0', '0', '622574', '0');
INSERT INTO `auction` VALUES ('20420', '6', '21334', '36166', '2', '1315123', '1291840646', '0', '0', '1183610', '0');
INSERT INTO `auction` VALUES ('19585', '2', '20499', '36570', '2', '5167244', '1291840586', '0', '0', '4288812', '0');
INSERT INTO `auction` VALUES ('20724', '2', '21674', '13422', '2', '1062', '1291834591', '0', '0', '817', '0');
INSERT INTO `auction` VALUES ('20217', '2', '21131', '10559', '2', '25950', '1291847846', '0', '0', '24393', '0');
INSERT INTO `auction` VALUES ('19915', '7', '20829', '9719', '2', '436500', '1291851386', '0', '0', '410310', '0');
INSERT INTO `auction` VALUES ('20613', '7', '21527', '1959', '2', '80512', '1291862246', '0', '0', '67630', '0');
INSERT INTO `auction` VALUES ('20918', '7', '21868', '9262', '2', '51520', '1291863391', '0', '0', '48944', '0');
INSERT INTO `auction` VALUES ('19813', '6', '20727', '27516', '2', '10860', '1291872986', '0', '0', '8579', '0');
INSERT INTO `auction` VALUES ('20645', '7', '21559', '3164', '2', '1861', '1291847846', '0', '0', '1470', '0');
INSERT INTO `auction` VALUES ('20759', '2', '21709', '8284', '2', '680268', '1291830991', '0', '0', '673465', '0');
INSERT INTO `auction` VALUES ('18946', '2', '19860', '36046', '2', '1210828', '1291887326', '0', '0', '1077636', '0');
INSERT INTO `auction` VALUES ('20369', '6', '21283', '40195', '2', '6600', '1291880246', '0', '0', '6138', '0');
INSERT INTO `auction` VALUES ('19814', '6', '20728', '6355', '2', '6', '1291858586', '0', '0', '5', '0');
INSERT INTO `auction` VALUES ('19916', '7', '20830', '1189', '2', '23225', '1291833386', '0', '0', '21599', '0');
INSERT INTO `auction` VALUES ('20710', '2', '21660', '9061', '2', '10260', '1291866991', '0', '0', '7695', '0');
INSERT INTO `auction` VALUES ('19917', '7', '20831', '754', '2', '1489967', '1291876586', '0', '0', '1177073', '0');
INSERT INTO `auction` VALUES ('19815', '6', '20729', '2971', '2', '981', '1291869386', '0', '0', '774', '0');
INSERT INTO `auction` VALUES ('20158', '2', '21072', '6358', '2', '234', '1291833446', '0', '0', '166', '0');
INSERT INTO `auction` VALUES ('20695', '2', '21645', '3164', '2', '324', '1291841791', '0', '0', '243', '0');
INSERT INTO `auction` VALUES ('20493', '7', '21407', '3643', '2', '795', '1291862246', '0', '0', '588', '0');
INSERT INTO `auction` VALUES ('20254', '2', '21168', '37160', '2', '1100', '1291869446', '0', '0', '770', '0');
INSERT INTO `auction` VALUES ('20760', '2', '21710', '4676', '2', '15998', '1291838191', '0', '0', '13598', '0');
INSERT INTO `auction` VALUES ('19816', '6', '20730', '36382', '2', '2397556', '1291876586', '0', '0', '2013947', '0');
INSERT INTO `auction` VALUES ('19817', '6', '20731', '2623', '2', '152670', '1291836986', '0', '0', '125189', '0');
INSERT INTO `auction` VALUES ('19818', '6', '20732', '767', '2', '1159', '1291869386', '0', '0', '857', '0');
INSERT INTO `auction` VALUES ('20951', '7', '21901', '1608', '2', '1026591', '1291874191', '0', '0', '821272', '0');
INSERT INTO `auction` VALUES ('20180', '2', '21094', '20406', '2', '82561', '1291847846', '0', '0', '81735', '0');
INSERT INTO `auction` VALUES ('20218', '2', '21132', '2620', '2', '163024', '1291858646', '0', '0', '158133', '0');
INSERT INTO `auction` VALUES ('20159', '2', '21073', '24942', '2', '1044940', '1291880246', '0', '0', '909097', '0');
INSERT INTO `auction` VALUES ('20126', '2', '21040', '7072', '2', '2724', '1291837046', '0', '0', '2478', '0');
INSERT INTO `auction` VALUES ('20160', '2', '21074', '25005', '2', '1548558', '1291869446', '0', '0', '1238846', '0');
INSERT INTO `auction` VALUES ('20673', '7', '21587', '4388', '2', '8680', '1291829846', '0', '0', '6596', '0');
INSERT INTO `auction` VALUES ('20161', '2', '21075', '5523', '2', '396', '1291883846', '0', '0', '320', '0');
INSERT INTO `auction` VALUES ('20368', '6', '21282', '19943', '2', '142560', '1291865846', '0', '0', '108345', '0');
INSERT INTO `auction` VALUES ('19819', '6', '20733', '4388', '2', '8120', '1291880186', '0', '0', '6090', '0');
INSERT INTO `auction` VALUES ('19541', '2', '20455', '19943', '2', '97440', '1291847786', '0', '0', '81849', '0');
INSERT INTO `auction` VALUES ('20162', '2', '21076', '32717', '2', '1128000', '1291869446', '0', '0', '981360', '0');
INSERT INTO `auction` VALUES ('20163', '2', '21077', '44475', '2', '148', '1291873046', '0', '0', '113', '0');
INSERT INTO `auction` VALUES ('20696', '2', '21646', '1990', '2', '432807', '1291845391', '0', '0', '411166', '0');
INSERT INTO `auction` VALUES ('20452', '6', '21366', '10560', '2', '56320', '1291869446', '0', '0', '51251', '0');
INSERT INTO `auction` VALUES ('19820', '6', '20734', '18742', '2', '1651764', '1291876586', '0', '0', '1552658', '0');
INSERT INTO `auction` VALUES ('20492', '7', '21406', '7072', '2', '9360', '1291873046', '0', '0', '8143', '0');
INSERT INTO `auction` VALUES ('19821', '6', '20735', '12549', '2', '1038920', '1291872986', '0', '0', '883082', '0');
INSERT INTO `auction` VALUES ('19822', '6', '20736', '36456', '2', '3593736', '1291858586', '0', '0', '3306237', '0');
INSERT INTO `auction` VALUES ('20761', '2', '21711', '24999', '2', '1869390', '1291838191', '0', '0', '1719838', '0');
INSERT INTO `auction` VALUES ('19823', '6', '20737', '9719', '2', '379750', '1291883786', '0', '0', '345572', '0');
INSERT INTO `auction` VALUES ('19083', '6', '19997', '13023', '2', '3343862', '1291872926', '0', '0', '3210107', '0');
INSERT INTO `auction` VALUES ('20398', '6', '21312', '36274', '2', '1582500', '1291855046', '0', '0', '1471725', '0');
INSERT INTO `auction` VALUES ('20952', '7', '21902', '36040', '2', '2485368', '1291863391', '0', '0', '2236831', '0');
INSERT INTO `auction` VALUES ('20957', '7', '21907', '36667', '2', '3449040', '1291870591', '0', '0', '3069645', '0');
INSERT INTO `auction` VALUES ('20437', '6', '21351', '10135', '2', '832898', '1291880246', '0', '0', '741279', '0');
INSERT INTO `auction` VALUES ('19824', '6', '20738', '24938', '2', '1340302', '1291854986', '0', '0', '1206271', '0');
INSERT INTO `auction` VALUES ('20917', '7', '21867', '36781', '2', '28424', '1291866991', '0', '0', '27855', '0');
INSERT INTO `auction` VALUES ('20958', '7', '21908', '1927', '2', '29229', '1291888591', '0', '0', '25136', '0');
INSERT INTO `auction` VALUES ('19825', '6', '20739', '9719', '2', '314500', '1291844186', '0', '0', '254745', '0');
INSERT INTO `auction` VALUES ('19826', '6', '20740', '10514', '2', '56160', '1291865786', '0', '0', '39873', '0');
INSERT INTO `auction` VALUES ('20436', '6', '21350', '25292', '2', '2976273', '1291869446', '0', '0', '2619120', '0');
INSERT INTO `auction` VALUES ('20959', '7', '21909', '1929', '2', '30386', '1291830991', '0', '0', '24916', '0');
INSERT INTO `auction` VALUES ('19827', '6', '20741', '9719', '2', '389750', '1291858586', '0', '0', '339082', '0');
INSERT INTO `auction` VALUES ('20424', '6', '21338', '1214', '2', '48985', '1291837046', '0', '0', '41147', '0');
INSERT INTO `auction` VALUES ('19528', '2', '20442', '36168', '2', '3293237', '1291851386', '0', '0', '2832183', '0');
INSERT INTO `auction` VALUES ('19828', '6', '20742', '7973', '2', '8091', '1291862186', '0', '0', '7362', '0');
INSERT INTO `auction` VALUES ('20674', '7', '21588', '25172', '2', '3915974', '1291851446', '0', '0', '3250258', '0');
INSERT INTO `auction` VALUES ('20423', '6', '21337', '37145', '2', '8225', '1291847846', '0', '0', '5839', '0');
INSERT INTO `auction` VALUES ('20675', '2', '21625', '8350', '2', '63054', '1291848991', '0', '0', '59901', '0');
INSERT INTO `auction` VALUES ('19829', '6', '20743', '9719', '2', '320000', '1291883786', '0', '0', '265600', '0');
INSERT INTO `auction` VALUES ('19830', '6', '20744', '9719', '2', '319250', '1291869386', '0', '0', '268170', '0');
INSERT INTO `auction` VALUES ('20697', '2', '21647', '24685', '2', '622985', '1291877791', '0', '0', '616755', '0');
INSERT INTO `auction` VALUES ('20219', '2', '21133', '24835', '2', '2342497', '1291840646', '0', '0', '2084822', '0');
INSERT INTO `auction` VALUES ('19918', '7', '20832', '44475', '2', '192', '1291872986', '0', '0', '159', '0');
INSERT INTO `auction` VALUES ('20182', '2', '21096', '10562', '2', '45840', '1291851446', '0', '0', '33004', '0');
INSERT INTO `auction` VALUES ('19831', '6', '20745', '935', '2', '127906', '1291851386', '0', '0', '124068', '0');
INSERT INTO `auction` VALUES ('20960', '7', '21910', '24998', '2', '1314316', '1291856191', '0', '0', '1248600', '0');
INSERT INTO `auction` VALUES ('20115', '2', '21029', '9719', '2', '391250', '1291840646', '0', '0', '356037', '0');
INSERT INTO `auction` VALUES ('19832', '6', '20746', '31554', '2', '2724577', '1291880186', '0', '0', '2615593', '0');
INSERT INTO `auction` VALUES ('19833', '6', '20747', '37822', '2', '3033899', '1291876586', '0', '0', '3033899', '0');
INSERT INTO `auction` VALUES ('20916', '7', '21866', '40195', '2', '105300', '1291874191', '0', '0', '92664', '0');
INSERT INTO `auction` VALUES ('19084', '6', '19998', '871', '2', '4230878', '1291869326', '0', '0', '3384702', '0');
INSERT INTO `auction` VALUES ('20220', '2', '21134', '8151', '2', '26000', '1291840646', '0', '0', '20800', '0');
INSERT INTO `auction` VALUES ('19325', '7', '20239', '6205', '2', '39495', '1291844126', '0', '0', '33570', '0');
INSERT INTO `auction` VALUES ('19834', '6', '20748', '36416', '2', '1800191', '1291862186', '0', '0', '1764187', '0');
INSERT INTO `auction` VALUES ('19835', '6', '20749', '1958', '2', '57792', '1291844186', '0', '0', '48545', '0');
INSERT INTO `auction` VALUES ('20961', '7', '21911', '1460', '2', '99384', '1291848991', '0', '0', '90439', '0');
INSERT INTO `auction` VALUES ('19836', '6', '20750', '9719', '2', '363000', '1291847786', '0', '0', '304920', '0');
INSERT INTO `auction` VALUES ('19554', '2', '20468', '9719', '2', '328250', '1291872986', '0', '0', '318402', '0');
INSERT INTO `auction` VALUES ('20711', '2', '21661', '37147', '2', '20160', '1291841791', '0', '0', '16329', '0');
INSERT INTO `auction` VALUES ('19837', '6', '20751', '31176', '2', '1768713', '1291887386', '0', '0', '1609528', '0');
INSERT INTO `auction` VALUES ('19838', '6', '20752', '3415', '2', '309856', '1291883786', '0', '0', '281968', '0');
INSERT INTO `auction` VALUES ('20221', '2', '21135', '1936', '2', '61102', '1291865846', '0', '0', '48881', '0');
INSERT INTO `auction` VALUES ('20367', '6', '21281', '6358', '2', '515', '1291873046', '0', '0', '437', '0');
INSERT INTO `auction` VALUES ('20962', '7', '21912', '3057', '2', '48445', '1291848991', '0', '0', '43116', '0');
INSERT INTO `auction` VALUES ('19280', '7', '20194', '30736', '2', '6338931', '1291840526', '0', '0', '6338931', '0');
INSERT INTO `auction` VALUES ('20164', '2', '21078', '36264', '2', '4005020', '1291869446', '0', '0', '3844819', '0');
INSERT INTO `auction` VALUES ('20222', '2', '21136', '9262', '2', '115600', '1291840646', '0', '0', '89012', '0');
INSERT INTO `auction` VALUES ('19839', '6', '20753', '20674', '2', '1267690', '1291833386', '0', '0', '1153597', '0');
INSERT INTO `auction` VALUES ('19281', '7', '20195', '7728', '2', '240334', '1291844126', '0', '0', '237930', '0');
INSERT INTO `auction` VALUES ('20463', '6', '21377', '24892', '2', '1830792', '1291887446', '0', '0', '1464633', '0');
INSERT INTO `auction` VALUES ('19840', '6', '20754', '31198', '2', '1437437', '1291880186', '0', '0', '1193072', '0');
INSERT INTO `auction` VALUES ('20762', '2', '21712', '36539', '2', '5975750', '1291888591', '0', '0', '5915992', '0');
INSERT INTO `auction` VALUES ('20529', '7', '21443', '5967', '2', '11380', '1291862246', '0', '0', '9104', '0');
INSERT INTO `auction` VALUES ('19841', '6', '20755', '36154', '2', '1295247', '1291858586', '0', '0', '1100959', '0');
INSERT INTO `auction` VALUES ('19842', '6', '20756', '35593', '2', '3206170', '1291836986', '0', '0', '2404627', '0');
INSERT INTO `auction` VALUES ('20165', '2', '21079', '25172', '2', '4296303', '1291865846', '0', '0', '3565931', '0');
INSERT INTO `auction` VALUES ('19540', '2', '20454', '2258', '2', '838', '1291851386', '0', '0', '670', '0');
INSERT INTO `auction` VALUES ('19085', '6', '19999', '5767', '2', '333', '1291869326', '0', '0', '243', '0');
INSERT INTO `auction` VALUES ('19967', '7', '20881', '3312', '2', '732', '1291840586', '0', '0', '666', '0');
INSERT INTO `auction` VALUES ('20067', '7', '20981', '27516', '2', '15200', '1291858586', '0', '0', '10640', '0');
INSERT INTO `auction` VALUES ('20068', '7', '20982', '37160', '2', '15225', '1291858586', '0', '0', '13398', '0');
INSERT INTO `auction` VALUES ('20646', '7', '21560', '9060', '2', '142200', '1291833446', '0', '0', '106650', '0');
INSERT INTO `auction` VALUES ('19843', '6', '20757', '5819', '2', '269911', '1291858586', '0', '0', '242919', '0');
INSERT INTO `auction` VALUES ('19844', '6', '20758', '2277', '2', '230101', '1291854986', '0', '0', '207090', '0');
INSERT INTO `auction` VALUES ('19845', '6', '20759', '44700', '2', '4225', '1291869386', '0', '0', '3084', '0');
INSERT INTO `auction` VALUES ('20743', '2', '21693', '36054', '2', '1365374', '1291863391', '0', '0', '1269797', '0');
INSERT INTO `auction` VALUES ('20647', '7', '21561', '10561', '2', '35840', '1291851446', '0', '0', '35840', '0');
INSERT INTO `auction` VALUES ('19919', '7', '20833', '9719', '2', '435750', '1291829786', '0', '0', '435750', '0');
INSERT INTO `auction` VALUES ('20278', '6', '21192', '24665', '2', '976051', '1291847846', '0', '0', '849164', '0');
INSERT INTO `auction` VALUES ('19289', '7', '20203', '9719', '2', '404250', '1291854926', '0', '0', '404250', '0');
INSERT INTO `auction` VALUES ('20084', '2', '20998', '40199', '2', '1688', '1291883846', '0', '0', '1637', '0');
INSERT INTO `auction` VALUES ('19415', '7', '20329', '44475', '2', '158', '1291851326', '0', '0', '120', '0');
INSERT INTO `auction` VALUES ('20085', '2', '20999', '3164', '2', '2697', '1291862246', '0', '0', '2508', '0');
INSERT INTO `auction` VALUES ('20279', '6', '21193', '27511', '2', '152', '1291829846', '0', '0', '135', '0');
INSERT INTO `auction` VALUES ('19907', '7', '20821', '9719', '2', '423500', '1291829786', '0', '0', '317625', '0');
INSERT INTO `auction` VALUES ('19546', '2', '20460', '24948', '2', '1319413', '1291872986', '0', '0', '1253442', '0');
INSERT INTO `auction` VALUES ('20280', '6', '21194', '24476', '2', '3312', '1291862246', '0', '0', '3146', '0');
INSERT INTO `auction` VALUES ('20281', '6', '21195', '36378', '2', '1833142', '1291869446', '0', '0', '1723153', '0');
INSERT INTO `auction` VALUES ('20282', '6', '21196', '4436', '2', '14697', '1291880246', '0', '0', '13227', '0');
INSERT INTO `auction` VALUES ('19701', '6', '20615', '1459', '2', '130326', '1291862186', '0', '0', '125112', '0');
INSERT INTO `auction` VALUES ('19199', '6', '20113', '9251', '2', '427', '1291854926', '0', '0', '392', '0');
INSERT INTO `auction` VALUES ('19137', '6', '20051', '36485', '2', '4759614', '1291872926', '0', '0', '4569229', '0');
INSERT INTO `auction` VALUES ('20283', '6', '21197', '10561', '2', '67520', '1291855046', '0', '0', '54691', '0');
INSERT INTO `auction` VALUES ('20284', '6', '21198', '37145', '2', '3140', '1291873046', '0', '0', '2857', '0');
INSERT INTO `auction` VALUES ('20728', '2', '21678', '4402', '2', '8920', '1291859791', '0', '0', '7314', '0');
INSERT INTO `auction` VALUES ('20285', '6', '21199', '12804', '2', '94000', '1291840646', '0', '0', '82720', '0');
INSERT INTO `auction` VALUES ('19359', '7', '20273', '36042', '2', '898870', '1291883726', '0', '0', '835949', '0');
INSERT INTO `auction` VALUES ('19416', '7', '20330', '2039', '2', '39210', '1291883726', '0', '0', '38425', '0');
INSERT INTO `auction` VALUES ('20729', '2', '21679', '36377', '2', '3307508', '1291874191', '0', '0', '3075982', '0');
INSERT INTO `auction` VALUES ('19702', '6', '20616', '13915', '2', '1075', '1291840586', '0', '0', '1010', '0');
INSERT INTO `auction` VALUES ('19138', '6', '20052', '25152', '2', '4544983', '1291865726', '0', '0', '4544983', '0');
INSERT INTO `auction` VALUES ('20730', '2', '21680', '12804', '2', '109440', '1291863391', '0', '0', '106156', '0');
INSERT INTO `auction` VALUES ('20086', '2', '21000', '5524', '2', '550', '1291847846', '0', '0', '456', '0');
INSERT INTO `auction` VALUES ('19139', '6', '20053', '814', '2', '2171', '1291869326', '0', '0', '2084', '0');
INSERT INTO `auction` VALUES ('19100', '6', '20014', '2227', '2', '241815', '1291872926', '0', '0', '193452', '0');
INSERT INTO `auction` VALUES ('20286', '6', '21200', '4290', '2', '48897', '1291862246', '0', '0', '44985', '0');
INSERT INTO `auction` VALUES ('20435', '6', '21349', '17965', '2', '11665', '1291873046', '0', '0', '10965', '0');
INSERT INTO `auction` VALUES ('20287', '6', '21201', '45909', '2', '30960', '1291880246', '0', '0', '27864', '0');
INSERT INTO `auction` VALUES ('19346', '7', '20260', '34829', '2', '1025200', '1291840526', '0', '0', '922680', '0');
INSERT INTO `auction` VALUES ('19330', '7', '20244', '37117', '2', '2790380', '1291836926', '0', '0', '2148592', '0');
INSERT INTO `auction` VALUES ('20558', '7', '21472', '4634', '2', '3370', '1291847846', '0', '0', '3066', '0');
INSERT INTO `auction` VALUES ('19347', '7', '20261', '37158', '2', '885', '1291887326', '0', '0', '761', '0');
INSERT INTO `auction` VALUES ('20288', '6', '21202', '40195', '2', '14520', '1291855046', '0', '0', '11180', '0');
INSERT INTO `auction` VALUES ('20289', '6', '21203', '37159', '2', '9540', '1291869446', '0', '0', '8299', '0');
INSERT INTO `auction` VALUES ('19331', '7', '20245', '9719', '2', '403250', '1291833326', '0', '0', '318567', '0');
INSERT INTO `auction` VALUES ('19759', '6', '20673', '9719', '2', '382750', '1291836986', '0', '0', '298545', '0');
INSERT INTO `auction` VALUES ('19760', '6', '20674', '19441', '2', '22800', '1291865786', '0', '0', '19152', '0');
INSERT INTO `auction` VALUES ('18930', '2', '19844', '9719', '2', '349250', '1291851326', '0', '0', '342265', '0');
INSERT INTO `auction` VALUES ('20290', '6', '21204', '1475', '2', '759', '1291851446', '0', '0', '629', '0');
INSERT INTO `auction` VALUES ('19761', '6', '20675', '1935', '2', '209723', '1291829786', '0', '0', '165681', '0');
INSERT INTO `auction` VALUES ('19703', '6', '20617', '16692', '2', '586699', '1291869386', '0', '0', '457625', '0');
INSERT INTO `auction` VALUES ('20291', '6', '21205', '1679', '2', '501522', '1291873046', '0', '0', '451369', '0');
INSERT INTO `auction` VALUES ('19101', '6', '20015', '1726', '2', '1038617', '1291840526', '0', '0', '955527', '0');
INSERT INTO `auction` VALUES ('19140', '6', '20054', '30723', '2', '15428136', '1291872926', '0', '0', '14502447', '0');
INSERT INTO `auction` VALUES ('20292', '6', '21206', '24826', '2', '1793212', '1291880246', '0', '0', '1721483', '0');
INSERT INTO `auction` VALUES ('19332', '7', '20246', '720', '2', '72827', '1291829726', '0', '0', '61174', '0');
INSERT INTO `auction` VALUES ('19141', '6', '20055', '9719', '2', '418500', '1291847726', '0', '0', '389205', '0');
INSERT INTO `auction` VALUES ('20293', '6', '21207', '25047', '2', '1115416', '1291855046', '0', '0', '948103', '0');
INSERT INTO `auction` VALUES ('19704', '6', '20618', '9719', '2', '392500', '1291869386', '0', '0', '384650', '0');
INSERT INTO `auction` VALUES ('20124', '2', '21038', '9719', '2', '415000', '1291862246', '0', '0', '381800', '0');
INSERT INTO `auction` VALUES ('20294', '6', '21208', '36044', '2', '1665235', '1291887446', '0', '0', '1515363', '0');
INSERT INTO `auction` VALUES ('19200', '6', '20114', '44749', '2', '311100', '1291869326', '0', '0', '289323', '0');
INSERT INTO `auction` VALUES ('20295', '6', '21209', '5182', '2', '110347', '1291833446', '0', '0', '90484', '0');
INSERT INTO `auction` VALUES ('18929', '2', '19843', '4044', '2', '236315', '1291876526', '0', '0', '219772', '0');
INSERT INTO `auction` VALUES ('19201', '6', '20115', '31229', '2', '1378667', '1291872926', '0', '0', '1089146', '0');
INSERT INTO `auction` VALUES ('20296', '6', '21210', '24825', '2', '863593', '1291873046', '0', '0', '777233', '0');
INSERT INTO `auction` VALUES ('20557', '7', '21471', '4768', '2', '9011', '1291840646', '0', '0', '8290', '0');
INSERT INTO `auction` VALUES ('19762', '6', '20676', '44700', '2', '5700', '1291887386', '0', '0', '4446', '0');
INSERT INTO `auction` VALUES ('19906', '7', '20820', '13757', '2', '51600', '1291869386', '0', '0', '43860', '0');
INSERT INTO `auction` VALUES ('19905', '7', '20819', '24603', '2', '898296', '1291865786', '0', '0', '853381', '0');
INSERT INTO `auction` VALUES ('20520', '7', '21434', '5319', '2', '3328', '1291858646', '0', '0', '2496', '0');
INSERT INTO `auction` VALUES ('20297', '6', '21211', '4465', '2', '104821', '1291862246', '0', '0', '104821', '0');
INSERT INTO `auction` VALUES ('19371', '7', '20285', '2291', '2', '6530970', '1291865726', '0', '0', '6139111', '0');
INSERT INTO `auction` VALUES ('20298', '6', '21212', '27511', '2', '180', '1291858646', '0', '0', '160', '0');
INSERT INTO `auction` VALUES ('19417', '7', '20331', '34828', '2', '1234095', '1291829726', '0', '0', '900889', '0');
INSERT INTO `auction` VALUES ('20299', '6', '21213', '24476', '2', '848', '1291844246', '0', '0', '644', '0');
INSERT INTO `auction` VALUES ('19202', '6', '20116', '9719', '2', '399750', '1291829726', '0', '0', '339787', '0');
INSERT INTO `auction` VALUES ('20300', '6', '21214', '8152', '2', '6160', '1291869446', '0', '0', '4866', '0');
INSERT INTO `auction` VALUES ('19290', '7', '20204', '36174', '2', '1304611', '1291840526', '0', '0', '1174149', '0');
INSERT INTO `auction` VALUES ('20301', '6', '21215', '20661', '2', '704720', '1291855046', '0', '0', '620153', '0');
INSERT INTO `auction` VALUES ('20480', '7', '21394', '36163', '2', '1705433', '1291855046', '0', '0', '1568998', '0');
INSERT INTO `auction` VALUES ('19203', '6', '20117', '5624', '2', '201377', '1291840526', '0', '0', '161101', '0');
INSERT INTO `auction` VALUES ('20302', '6', '21216', '13757', '2', '15480', '1291887446', '0', '0', '11300', '0');
INSERT INTO `auction` VALUES ('20479', '7', '21393', '9480', '2', '2604638', '1291880246', '0', '0', '2213942', '0');
INSERT INTO `auction` VALUES ('19291', '7', '20205', '32464', '2', '130680', '1291847726', '0', '0', '99316', '0');
INSERT INTO `auction` VALUES ('19204', '6', '20118', '21296', '2', '5732000', '1291829726', '0', '0', '4470960', '0');
INSERT INTO `auction` VALUES ('20303', '6', '21217', '24716', '2', '753803', '1291887446', '0', '0', '618118', '0');
INSERT INTO `auction` VALUES ('18952', '2', '19866', '2567', '2', '170876', '1291883726', '0', '0', '145244', '0');
INSERT INTO `auction` VALUES ('20304', '6', '21218', '24824', '2', '2289382', '1291840646', '0', '0', '1991762', '0');
INSERT INTO `auction` VALUES ('20305', '6', '21219', '8106', '2', '642508', '1291847846', '0', '0', '526856', '0');
INSERT INTO `auction` VALUES ('20501', '7', '21415', '5256', '2', '361008', '1291887446', '0', '0', '310466', '0');
INSERT INTO `auction` VALUES ('20306', '6', '21220', '39682', '2', '102720', '1291883846', '0', '0', '99638', '0');
INSERT INTO `auction` VALUES ('20434', '6', '21348', '9262', '2', '98280', '1291865846', '0', '0', '86486', '0');
INSERT INTO `auction` VALUES ('20199', '2', '21113', '8151', '2', '3620', '1291851446', '0', '0', '3185', '0');
INSERT INTO `auction` VALUES ('20478', '7', '21392', '9719', '2', '392500', '1291880246', '0', '0', '349325', '0');
INSERT INTO `auction` VALUES ('20307', '6', '21221', '2632', '2', '34015', '1291876646', '0', '0', '28912', '0');
INSERT INTO `auction` VALUES ('19372', '7', '20286', '45909', '2', '23760', '1291836926', '0', '0', '20433', '0');
INSERT INTO `auction` VALUES ('19292', '7', '20206', '25270', '2', '2154692', '1291858526', '0', '0', '1853035', '0');
INSERT INTO `auction` VALUES ('20680', '2', '21630', '25117', '2', '3790540', '1291834591', '0', '0', '3221959', '0');
INSERT INTO `auction` VALUES ('19348', '7', '20262', '24942', '2', '927993', '1291833326', '0', '0', '760954', '0');
INSERT INTO `auction` VALUES ('20308', '6', '21222', '37160', '2', '19760', '1291873046', '0', '0', '18376', '0');
INSERT INTO `auction` VALUES ('19673', '2', '20587', '27511', '2', '163', '1291858586', '0', '0', '153', '0');
INSERT INTO `auction` VALUES ('20681', '2', '21631', '10505', '2', '34920', '1291841791', '0', '0', '24444', '0');
INSERT INTO `auction` VALUES ('20525', '7', '21439', '25033', '2', '797372', '1291869446', '0', '0', '661818', '0');
INSERT INTO `auction` VALUES ('20309', '6', '21223', '14897', '2', '271902', '1291862246', '0', '0', '266463', '0');
INSERT INTO `auction` VALUES ('19102', '6', '20016', '6353', '2', '9', '1291876526', '0', '0', '7', '0');
INSERT INTO `auction` VALUES ('19205', '6', '20119', '9719', '2', '323250', '1291887326', '0', '0', '248902', '0');
INSERT INTO `auction` VALUES ('19373', '7', '20287', '868', '2', '4511163', '1291829726', '0', '0', '4285604', '0');
INSERT INTO `auction` VALUES ('20310', '6', '21224', '13757', '2', '50388', '1291869446', '0', '0', '44341', '0');
INSERT INTO `auction` VALUES ('20500', '7', '21414', '2281', '2', '18754', '1291855046', '0', '0', '18003', '0');
INSERT INTO `auction` VALUES ('20682', '2', '21632', '4394', '2', '120870', '1291866991', '0', '0', '96696', '0');
INSERT INTO `auction` VALUES ('20519', '7', '21433', '10329', '2', '135535', '1291883846', '0', '0', '135535', '0');
INSERT INTO `auction` VALUES ('19293', '7', '20207', '20679', '2', '20280', '1291854926', '0', '0', '17440', '0');
INSERT INTO `auction` VALUES ('20311', '6', '21225', '24710', '2', '977596', '1291887446', '0', '0', '870060', '0');
INSERT INTO `auction` VALUES ('18922', '2', '19836', '2745', '2', '23700', '1291865726', '0', '0', '18960', '0');
INSERT INTO `auction` VALUES ('19206', '6', '20120', '8152', '2', '60000', '1291833326', '0', '0', '43200', '0');
INSERT INTO `auction` VALUES ('19294', '7', '20208', '4359', '2', '1529', '1291865726', '0', '0', '1437', '0');
INSERT INTO `auction` VALUES ('20312', '6', '21226', '36383', '2', '2300929', '1291847846', '0', '0', '2277919', '0');
INSERT INTO `auction` VALUES ('20313', '6', '21227', '31256', '2', '44469', '1291880246', '0', '0', '36909', '0');
INSERT INTO `auction` VALUES ('19295', '7', '20209', '9719', '2', '328000', '1291869326', '0', '0', '246000', '0');
INSERT INTO `auction` VALUES ('19207', '6', '20121', '6358', '2', '582', '1291829726', '0', '0', '430', '0');
INSERT INTO `auction` VALUES ('19374', '7', '20288', '5637', '2', '2016', '1291887326', '0', '0', '1512', '0');
INSERT INTO `auction` VALUES ('20683', '2', '21633', '41119', '2', '2180', '1291870591', '0', '0', '2071', '0');
INSERT INTO `auction` VALUES ('19158', '6', '20072', '826', '2', '45115', '1291840526', '0', '0', '44663', '0');
INSERT INTO `auction` VALUES ('20314', '6', '21228', '1288', '2', '1206', '1291865846', '0', '0', '856', '0');
INSERT INTO `auction` VALUES ('20518', '7', '21432', '21113', '2', '23', '1291840646', '0', '0', '20', '0');
INSERT INTO `auction` VALUES ('19397', '7', '20311', '16713', '2', '901918', '1291880126', '0', '0', '793687', '0');
INSERT INTO `auction` VALUES ('19208', '6', '20122', '2054', '2', '155', '1291876526', '0', '0', '155', '0');
INSERT INTO `auction` VALUES ('19375', '7', '20289', '2057', '2', '142', '1291847726', '0', '0', '103', '0');
INSERT INTO `auction` VALUES ('19103', '6', '20017', '4589', '2', '34132', '1291872926', '0', '0', '29694', '0');
INSERT INTO `auction` VALUES ('20315', '6', '21229', '5524', '2', '1808', '1291829846', '0', '0', '1554', '0');
INSERT INTO `auction` VALUES ('20316', '6', '21230', '24773', '2', '1092257', '1291829846', '0', '0', '1004876', '0');
INSERT INTO `auction` VALUES ('20317', '6', '21231', '25089', '2', '1177776', '1291858646', '0', '0', '1107109', '0');
INSERT INTO `auction` VALUES ('19376', '7', '20290', '36161', '2', '2279281', '1291836926', '0', '0', '2210902', '0');
INSERT INTO `auction` VALUES ('20318', '6', '21232', '4611', '2', '7258', '1291837046', '0', '0', '6604', '0');
INSERT INTO `auction` VALUES ('19377', '7', '20291', '5637', '2', '2625', '1291847726', '0', '0', '2126', '0');
INSERT INTO `auction` VALUES ('19104', '6', '20018', '1443', '2', '2061800', '1291847726', '0', '0', '1876238', '0');
INSERT INTO `auction` VALUES ('19705', '6', '20619', '1203', '2', '2015570', '1291876586', '0', '0', '1672923', '0');
INSERT INTO `auction` VALUES ('19105', '6', '20019', '30722', '2', '17008149', '1291862126', '0', '0', '13946682', '0');
INSERT INTO `auction` VALUES ('20319', '6', '21233', '4388', '2', '7400', '1291873046', '0', '0', '6216', '0');
INSERT INTO `auction` VALUES ('20200', '2', '21114', '2168', '2', '28469', '1291844246', '0', '0', '26760', '0');
INSERT INTO `auction` VALUES ('20320', '6', '21234', '37145', '2', '2685', '1291869446', '0', '0', '2335', '0');
INSERT INTO `auction` VALUES ('20321', '6', '21235', '5743', '2', '91414', '1291855046', '0', '0', '78616', '0');
INSERT INTO `auction` VALUES ('19418', '7', '20332', '6356', '2', '6', '1291865726', '0', '0', '5', '0');
INSERT INTO `auction` VALUES ('20322', '6', '21236', '36680', '2', '6264224', '1291862246', '0', '0', '5951012', '0');
INSERT INTO `auction` VALUES ('20323', '6', '21237', '4387', '2', '13280', '1291858646', '0', '0', '12616', '0');
INSERT INTO `auction` VALUES ('19419', '7', '20333', '9719', '2', '412000', '1291862126', '0', '0', '366680', '0');
INSERT INTO `auction` VALUES ('19296', '7', '20210', '25264', '2', '3243107', '1291844126', '0', '0', '2594485', '0');
INSERT INTO `auction` VALUES ('20324', '6', '21238', '1351', '2', '43744', '1291862246', '0', '0', '37182', '0');
INSERT INTO `auction` VALUES ('20325', '6', '21239', '21882', '2', '322000', '1291876646', '0', '0', '241500', '0');
INSERT INTO `auction` VALUES ('20326', '6', '21240', '40199', '2', '7170', '1291876646', '0', '0', '6094', '0');
INSERT INTO `auction` VALUES ('19106', '6', '20020', '20658', '2', '1068290', '1291883726', '0', '0', '982826', '0');
INSERT INTO `auction` VALUES ('20327', '6', '21241', '4359', '2', '197', '1291840646', '0', '0', '137', '0');
INSERT INTO `auction` VALUES ('19420', '7', '20334', '7973', '2', '1254', '1291851326', '0', '0', '927', '0');
INSERT INTO `auction` VALUES ('20328', '6', '21242', '36596', '2', '6938448', '1291876646', '0', '0', '6660910', '0');
INSERT INTO `auction` VALUES ('20329', '6', '21243', '4387', '2', '2784', '1291876646', '0', '0', '2255', '0');
INSERT INTO `auction` VALUES ('19159', '6', '20073', '18711', '2', '725178', '1291876526', '0', '0', '587394', '0');
INSERT INTO `auction` VALUES ('19904', '7', '20818', '11937', '2', '1220', '1291887386', '0', '0', '963', '0');
INSERT INTO `auction` VALUES ('20330', '6', '21244', '2620', '2', '197227', '1291844246', '0', '0', '195254', '0');
INSERT INTO `auction` VALUES ('19209', '6', '20123', '44475', '2', '183', '1291865726', '0', '0', '131', '0');
INSERT INTO `auction` VALUES ('20331', '6', '21245', '2265', '2', '19366', '1291869446', '0', '0', '18397', '0');
INSERT INTO `auction` VALUES ('19421', '7', '20335', '5524', '2', '2218', '1291887326', '0', '0', '1996', '0');
INSERT INTO `auction` VALUES ('20332', '6', '21246', '4611', '2', '7080', '1291840646', '0', '0', '5097', '0');
INSERT INTO `auction` VALUES ('20333', '6', '21247', '36286', '2', '1903972', '1291858646', '0', '0', '1599336', '0');
INSERT INTO `auction` VALUES ('19160', '6', '20074', '36582', '2', '6802338', '1291858526', '0', '0', '6462221', '0');
INSERT INTO `auction` VALUES ('20334', '6', '21248', '18512', '2', '26080', '1291876646', '0', '0', '24776', '0');
INSERT INTO `auction` VALUES ('19422', '7', '20336', '9719', '2', '370250', '1291865726', '0', '0', '281390', '0');
INSERT INTO `auction` VALUES ('20335', '6', '21249', '45909', '2', '15840', '1291847846', '0', '0', '13147', '0');
INSERT INTO `auction` VALUES ('20548', '7', '21462', '24944', '2', '2025300', '1291847846', '0', '0', '1762011', '0');
INSERT INTO `auction` VALUES ('19360', '7', '20274', '5183', '2', '95949', '1291844126', '0', '0', '88273', '0');
INSERT INTO `auction` VALUES ('20336', '6', '21250', '14826', '2', '203013', '1291862246', '0', '0', '196922', '0');
INSERT INTO `auction` VALUES ('19361', '7', '20275', '14549', '2', '1625601', '1291880126', '0', '0', '1609344', '0');
INSERT INTO `auction` VALUES ('19378', '7', '20292', '10402', '2', '16525', '1291858526', '0', '0', '15698', '0');
INSERT INTO `auction` VALUES ('19362', '7', '20276', '14555', '2', '8936945', '1291865726', '0', '0', '7507033', '0');
INSERT INTO `auction` VALUES ('19161', '6', '20075', '2164', '2', '4695458', '1291833326', '0', '0', '4413730', '0');
INSERT INTO `auction` VALUES ('19210', '6', '20124', '24663', '2', '1392298', '1291847726', '0', '0', '1253068', '0');
INSERT INTO `auction` VALUES ('19706', '6', '20620', '36443', '2', '1688483', '1291865786', '0', '0', '1654713', '0');
INSERT INTO `auction` VALUES ('20197', '2', '21111', '24476', '2', '9856', '1291837046', '0', '0', '8377', '0');
INSERT INTO `auction` VALUES ('20337', '6', '21251', '10562', '2', '107400', '1291873046', '0', '0', '85920', '0');
INSERT INTO `auction` VALUES ('19707', '6', '20621', '4700', '2', '2886', '1291851386', '0', '0', '2020', '0');
INSERT INTO `auction` VALUES ('20338', '6', '21252', '25256', '2', '2772088', '1291847846', '0', '0', '2716646', '0');
INSERT INTO `auction` VALUES ('19423', '7', '20337', '13422', '2', '864', '1291858526', '0', '0', '820', '0');
INSERT INTO `auction` VALUES ('20260', '2', '21174', '24724', '2', '738033', '1291840646', '0', '0', '619947', '0');
INSERT INTO `auction` VALUES ('19107', '6', '20021', '3048', '2', '84375', '1291883726', '0', '0', '79312', '0');
INSERT INTO `auction` VALUES ('19708', '6', '20622', '13000', '2', '3998612', '1291833386', '0', '0', '3958625', '0');
INSERT INTO `auction` VALUES ('20339', '6', '21253', '4388', '2', '7880', '1291865846', '0', '0', '7013', '0');
INSERT INTO `auction` VALUES ('20340', '6', '21254', '28498', '2', '1497532', '1291869446', '0', '0', '1302852', '0');
INSERT INTO `auction` VALUES ('19162', '6', '20076', '31182', '2', '2250963', '1291887326', '0', '0', '2138414', '0');
INSERT INTO `auction` VALUES ('20341', '6', '21255', '8283', '2', '977277', '1291844246', '0', '0', '977277', '0');
INSERT INTO `auction` VALUES ('19211', '6', '20125', '8956', '2', '1344', '1291880126', '0', '0', '1155', '0');
INSERT INTO `auction` VALUES ('20499', '7', '21413', '36667', '2', '4535611', '1291844246', '0', '0', '4218118', '0');
INSERT INTO `auction` VALUES ('19363', '7', '20277', '45909', '2', '16320', '1291833326', '0', '0', '12566', '0');
INSERT INTO `auction` VALUES ('20342', '6', '21256', '27515', '2', '12720', '1291865846', '0', '0', '9285', '0');
INSERT INTO `auction` VALUES ('19709', '6', '20623', '11040', '2', '8', '1291876586', '0', '0', '6', '0');
INSERT INTO `auction` VALUES ('19142', '6', '20056', '27515', '2', '14580', '1291887326', '0', '0', '13705', '0');
INSERT INTO `auction` VALUES ('19212', '6', '20126', '31269', '2', '60531', '1291840526', '0', '0', '60531', '0');
INSERT INTO `auction` VALUES ('18928', '2', '19842', '5637', '2', '2676', '1291862126', '0', '0', '2194', '0');
INSERT INTO `auction` VALUES ('20547', '7', '21461', '2981', '2', '43910', '1291837046', '0', '0', '39958', '0');
INSERT INTO `auction` VALUES ('19672', '2', '20586', '5523', '2', '1280', '1291844186', '0', '0', '1203', '0');
INSERT INTO `auction` VALUES ('20343', '6', '21257', '25186', '2', '3153181', '1291829846', '0', '0', '3027053', '0');
INSERT INTO `auction` VALUES ('20344', '6', '21258', '25200', '2', '3530383', '1291847846', '0', '0', '2930217', '0');
INSERT INTO `auction` VALUES ('19213', '6', '20127', '9061', '2', '22050', '1291836926', '0', '0', '18742', '0');
INSERT INTO `auction` VALUES ('20345', '6', '21259', '6359', '2', '352', '1291869446', '0', '0', '344', '0');
INSERT INTO `auction` VALUES ('20262', '2', '21176', '5635', '2', '2016', '1291865846', '0', '0', '1411', '0');
INSERT INTO `auction` VALUES ('20261', '2', '21175', '24663', '2', '1613079', '1291844246', '0', '0', '1451771', '0');
INSERT INTO `auction` VALUES ('20346', '6', '21260', '10367', '2', '1457967', '1291876646', '0', '0', '1370488', '0');
INSERT INTO `auction` VALUES ('19108', '6', '20022', '17965', '2', '8360', '1291854926', '0', '0', '7524', '0');
INSERT INTO `auction` VALUES ('18921', '2', '19835', '9060', '2', '79200', '1291854926', '0', '0', '69696', '0');
INSERT INTO `auction` VALUES ('19364', '7', '20278', '13887', '2', '534', '1291858526', '0', '0', '491', '0');
INSERT INTO `auction` VALUES ('19890', '7', '20804', '13001', '2', '563944', '1291840586', '0', '0', '507549', '0');
INSERT INTO `auction` VALUES ('20071', '7', '20985', '10460', '2', '5464', '1291851386', '0', '0', '4862', '0');
INSERT INTO `auction` VALUES ('20648', '7', '21562', '6333', '2', '92206', '1291873046', '0', '0', '73764', '0');
INSERT INTO `auction` VALUES ('19684', '6', '20598', '10403', '2', '34717', '1291836986', '0', '0', '34022', '0');
INSERT INTO `auction` VALUES ('18954', '2', '19868', '9719', '2', '345500', '1291854926', '0', '0', '304040', '0');
INSERT INTO `auction` VALUES ('19086', '6', '20000', '9719', '2', '421500', '1291869326', '0', '0', '366705', '0');
INSERT INTO `auction` VALUES ('20347', '6', '21261', '25215', '2', '4292109', '1291833446', '0', '0', '4034582', '0');
INSERT INTO `auction` VALUES ('20348', '6', '21262', '1446', '2', '28249', '1291851446', '0', '0', '24859', '0');
INSERT INTO `auction` VALUES ('19924', '7', '20838', '5750', '2', '26057', '1291880186', '0', '0', '25014', '0');
INSERT INTO `auction` VALUES ('19424', '7', '20338', '44156', '2', '16500', '1291847726', '0', '0', '16335', '0');
INSERT INTO `auction` VALUES ('19087', '6', '20001', '9719', '2', '400500', '1291887326', '0', '0', '364455', '0');
INSERT INTO `auction` VALUES ('19396', '7', '20310', '31284', '2', '1960248', '1291869326', '0', '0', '1881838', '0');
INSERT INTO `auction` VALUES ('19539', '2', '20453', '10505', '2', '19360', '1291829786', '0', '0', '17036', '0');
INSERT INTO `auction` VALUES ('20349', '6', '21263', '40199', '2', '1432', '1291840646', '0', '0', '1331', '0');
INSERT INTO `auction` VALUES ('19305', '7', '20219', '36781', '2', '16240', '1291829726', '0', '0', '12017', '0');
INSERT INTO `auction` VALUES ('20350', '6', '21264', '2899', '2', '7030', '1291880246', '0', '0', '6467', '0');
INSERT INTO `auction` VALUES ('20351', '6', '21265', '24476', '2', '696', '1291855046', '0', '0', '494', '0');
INSERT INTO `auction` VALUES ('19881', '7', '20795', '1215', '2', '21263', '1291836986', '0', '0', '20625', '0');
INSERT INTO `auction` VALUES ('20072', '7', '20986', '9719', '2', '385250', '1291880186', '0', '0', '385250', '0');
INSERT INTO `auction` VALUES ('20676', '2', '21626', '24589', '2', '713658', '1291863391', '0', '0', '628019', '0');
INSERT INTO `auction` VALUES ('20352', '6', '21266', '5524', '2', '705', '1291862246', '0', '0', '697', '0');
INSERT INTO `auction` VALUES ('20649', '7', '21563', '39681', '2', '89600', '1291862246', '0', '0', '77952', '0');
INSERT INTO `auction` VALUES ('19088', '6', '20002', '25074', '2', '1496777', '1291865726', '0', '0', '1272260', '0');
INSERT INTO `auction` VALUES ('20915', '7', '21865', '1475', '2', '1752', '1291877791', '0', '0', '1296', '0');
INSERT INTO `auction` VALUES ('20353', '6', '21267', '10559', '2', '20400', '1291858646', '0', '0', '19380', '0');
INSERT INTO `auction` VALUES ('20451', '6', '21365', '4359', '2', '107', '1291883846', '0', '0', '82', '0');
INSERT INTO `auction` VALUES ('18934', '2', '19848', '9719', '2', '353500', '1291883726', '0', '0', '286335', '0');
INSERT INTO `auction` VALUES ('19425', '7', '20339', '24101', '2', '6328000', '1291833326', '0', '0', '5821760', '0');
INSERT INTO `auction` VALUES ('20354', '6', '21268', '44700', '2', '5175', '1291847846', '0', '0', '3622', '0');
INSERT INTO `auction` VALUES ('19089', '6', '20003', '9253', '2', '582', '1291872926', '0', '0', '459', '0');
INSERT INTO `auction` VALUES ('19685', '6', '20599', '6358', '2', '193', '1291887386', '0', '0', '135', '0');
INSERT INTO `auction` VALUES ('18953', '2', '19867', '9719', '2', '433000', '1291880126', '0', '0', '363720', '0');
INSERT INTO `auction` VALUES ('20677', '2', '21627', '4303', '2', '22856', '1291884991', '0', '0', '19199', '0');
INSERT INTO `auction` VALUES ('20252', '2', '21166', '3227', '2', '113911', '1291833446', '0', '0', '100241', '0');
INSERT INTO `auction` VALUES ('19342', '7', '20256', '30735', '2', '4601491', '1291854926', '0', '0', '3773222', '0');
INSERT INTO `auction` VALUES ('20379', '6', '21293', '10561', '2', '18320', '1291837046', '0', '0', '15022', '0');
INSERT INTO `auction` VALUES ('19306', '7', '20220', '13905', '2', '208', '1291836926', '0', '0', '162', '0');
INSERT INTO `auction` VALUES ('20184', '2', '21098', '18588', '2', '16320', '1291862246', '0', '0', '11587', '0');
INSERT INTO `auction` VALUES ('20073', '7', '20987', '19441', '2', '9900', '1291869386', '0', '0', '7128', '0');
INSERT INTO `auction` VALUES ('20678', '2', '21628', '9262', '2', '9000', '1291838191', '0', '0', '7470', '0');
INSERT INTO `auction` VALUES ('20679', '2', '21629', '6359', '2', '640', '1291841791', '0', '0', '640', '0');
INSERT INTO `auction` VALUES ('20355', '6', '21269', '14812', '2', '1786458', '1291855046', '0', '0', '1750728', '0');
INSERT INTO `auction` VALUES ('20356', '6', '21270', '25257', '2', '3105347', '1291880246', '0', '0', '2981133', '0');
INSERT INTO `auction` VALUES ('19090', '6', '20004', '1926', '2', '34586', '1291869326', '0', '0', '33894', '0');
INSERT INTO `auction` VALUES ('19925', '7', '20839', '1455', '2', '157416', '1291847786', '0', '0', '133803', '0');
INSERT INTO `auction` VALUES ('20357', '6', '21271', '6358', '2', '143', '1291862246', '0', '0', '130', '0');
INSERT INTO `auction` VALUES ('19926', '7', '20840', '4589', '2', '14437', '1291836986', '0', '0', '12127', '0');
INSERT INTO `auction` VALUES ('19186', '6', '20100', '36041', '2', '1231505', '1291883726', '0', '0', '1059094', '0');
INSERT INTO `auction` VALUES ('20540', '7', '21454', '37159', '2', '7910', '1291880246', '0', '0', '6960', '0');
INSERT INTO `auction` VALUES ('18945', '2', '19859', '2163', '2', '8342406', '1291829726', '0', '0', '8258981', '0');
INSERT INTO `auction` VALUES ('19426', '7', '20340', '40199', '2', '2520', '1291883726', '0', '0', '2419', '0');
INSERT INTO `auction` VALUES ('19123', '6', '20037', '31214', '2', '2820391', '1291833326', '0', '0', '2707575', '0');
INSERT INTO `auction` VALUES ('19187', '6', '20101', '10559', '2', '135000', '1291865726', '0', '0', '133650', '0');
INSERT INTO `auction` VALUES ('19427', '7', '20341', '25229', '2', '3952697', '1291872926', '0', '0', '3755062', '0');
INSERT INTO `auction` VALUES ('19091', '6', '20005', '8483', '2', '21700', '1291844126', '0', '0', '19530', '0');
INSERT INTO `auction` VALUES ('19399', '7', '20313', '24773', '2', '950715', '1291851326', '0', '0', '865150', '0');
INSERT INTO `auction` VALUES ('18920', '2', '19834', '9719', '2', '400750', '1291836926', '0', '0', '308577', '0');
INSERT INTO `auction` VALUES ('20358', '6', '21272', '36554', '2', '6137436', '1291837046', '0', '0', '5339569', '0');
INSERT INTO `auction` VALUES ('20359', '6', '21273', '1945', '2', '17407', '1291862246', '0', '0', '14621', '0');
INSERT INTO `auction` VALUES ('19966', '7', '20880', '9060', '2', '25600', '1291876586', '0', '0', '20224', '0');
INSERT INTO `auction` VALUES ('20360', '6', '21274', '5524', '2', '1683', '1291837046', '0', '0', '1683', '0');
INSERT INTO `auction` VALUES ('20361', '6', '21275', '9060', '2', '79640', '1291847846', '0', '0', '61322', '0');
INSERT INTO `auction` VALUES ('20074', '7', '20988', '3186', '2', '289892', '1291833386', '0', '0', '260902', '0');
INSERT INTO `auction` VALUES ('19889', '7', '20803', '1713', '2', '303452', '1291865786', '0', '0', '242761', '0');
INSERT INTO `auction` VALUES ('19744', '6', '20658', '20527', '2', '47320', '1291872986', '0', '0', '44007', '0');
INSERT INTO `auction` VALUES ('19326', '7', '20240', '9719', '2', '323500', '1291858526', '0', '0', '310560', '0');
INSERT INTO `auction` VALUES ('20125', '2', '21039', '9719', '2', '363750', '1291851446', '0', '0', '356475', '0');
INSERT INTO `auction` VALUES ('19698', '6', '20612', '9719', '2', '387750', '1291844186', '0', '0', '310200', '0');
INSERT INTO `auction` VALUES ('19188', '6', '20102', '9719', '2', '421250', '1291876526', '0', '0', '328575', '0');
INSERT INTO `auction` VALUES ('19124', '6', '20038', '16714', '2', '789363', '1291844126', '0', '0', '789363', '0');
INSERT INTO `auction` VALUES ('19125', '6', '20039', '944', '2', '17092627', '1291829726', '0', '0', '16921700', '0');
INSERT INTO `auction` VALUES ('19745', '6', '20659', '9719', '2', '363500', '1291836986', '0', '0', '352595', '0');
INSERT INTO `auction` VALUES ('19428', '7', '20342', '2623', '2', '162267', '1291880126', '0', '0', '152530', '0');
INSERT INTO `auction` VALUES ('19746', '6', '20660', '44682', '2', '2584790', '1291876586', '0', '0', '2093679', '0');
INSERT INTO `auction` VALUES ('19747', '6', '20661', '9719', '2', '391750', '1291840586', '0', '0', '293812', '0');
INSERT INTO `auction` VALUES ('19748', '6', '20662', '36668', '2', '4817195', '1291865786', '0', '0', '4479991', '0');
INSERT INTO `auction` VALUES ('20251', '2', '21165', '15687', '2', '1899920', '1291833446', '0', '0', '1576933', '0');
INSERT INTO `auction` VALUES ('20362', '6', '21276', '36484', '2', '5299660', '1291851446', '0', '0', '4769694', '0');
INSERT INTO `auction` VALUES ('19571', '2', '20485', '2745', '2', '18150', '1291876586', '0', '0', '16879', '0');
INSERT INTO `auction` VALUES ('19156', '6', '20070', '9262', '2', '134520', '1291872926', '0', '0', '115687', '0');
INSERT INTO `auction` VALUES ('19327', '7', '20241', '9719', '2', '420750', '1291851326', '0', '0', '382882', '0');
INSERT INTO `auction` VALUES ('19126', '6', '20040', '9719', '2', '396500', '1291876526', '0', '0', '317200', '0');
INSERT INTO `auction` VALUES ('19572', '2', '20486', '2065', '2', '1280', '1291840586', '0', '0', '985', '0');
INSERT INTO `auction` VALUES ('19573', '2', '20487', '9719', '2', '404000', '1291865786', '0', '0', '319160', '0');
INSERT INTO `auction` VALUES ('19092', '6', '20006', '31170', '2', '3245461', '1291872926', '0', '0', '2791096', '0');
INSERT INTO `auction` VALUES ('19667', '2', '20581', '18679', '2', '1210573', '1291880186', '0', '0', '1186361', '0');
INSERT INTO `auction` VALUES ('19574', '2', '20488', '9719', '2', '437000', '1291833386', '0', '0', '332120', '0');
INSERT INTO `auction` VALUES ('19575', '2', '20489', '814', '2', '2820', '1291880186', '0', '0', '2368', '0');
INSERT INTO `auction` VALUES ('19093', '6', '20007', '14553', '2', '2721162', '1291836926', '0', '0', '2367410', '0');
INSERT INTO `auction` VALUES ('19576', '2', '20490', '6205', '2', '37188', '1291851386', '0', '0', '34212', '0');
INSERT INTO `auction` VALUES ('19577', '2', '20491', '2108', '2', '81', '1291872986', '0', '0', '79', '0');
INSERT INTO `auction` VALUES ('19749', '6', '20663', '9719', '2', '410500', '1291865786', '0', '0', '348925', '0');
INSERT INTO `auction` VALUES ('19729', '6', '20643', '9719', '2', '355500', '1291858586', '0', '0', '291510', '0');
INSERT INTO `auction` VALUES ('19888', '7', '20802', '18588', '2', '10080', '1291887386', '0', '0', '9273', '0');
INSERT INTO `auction` VALUES ('19750', '6', '20664', '4611', '2', '1808', '1291833386', '0', '0', '1717', '0');
INSERT INTO `auction` VALUES ('19686', '6', '20600', '6355', '2', '6', '1291840586', '0', '0', '4', '0');
INSERT INTO `auction` VALUES ('18933', '2', '19847', '10505', '2', '16590', '1291836926', '0', '0', '13769', '0');
INSERT INTO `auction` VALUES ('19687', '6', '20601', '20545', '2', '27000', '1291872986', '0', '0', '21870', '0');
INSERT INTO `auction` VALUES ('20539', '7', '21453', '4589', '2', '4664', '1291851446', '0', '0', '4477', '0');
INSERT INTO `auction` VALUES ('19688', '6', '20602', '9719', '2', '334250', '1291840586', '0', '0', '327565', '0');
INSERT INTO `auction` VALUES ('19157', '6', '20071', '1982', '2', '5111755', '1291876526', '0', '0', '4242756', '0');
INSERT INTO `auction` VALUES ('18932', '2', '19846', '9719', '2', '349500', '1291880126', '0', '0', '269115', '0');
INSERT INTO `auction` VALUES ('20253', '2', '21167', '36003', '2', '1002900', '1291862246', '0', '0', '802320', '0');
INSERT INTO `auction` VALUES ('19127', '6', '20041', '44155', '2', '11850', '1291869326', '0', '0', '9243', '0');
INSERT INTO `auction` VALUES ('19429', '7', '20343', '9719', '2', '377750', '1291869326', '0', '0', '317310', '0');
INSERT INTO `auction` VALUES ('19578', '2', '20492', '44695', '2', '4843027', '1291883786', '0', '0', '4649305', '0');
INSERT INTO `auction` VALUES ('19971', '7', '20885', '6292', '2', '53', '1291862186', '0', '0', '39', '0');
INSERT INTO `auction` VALUES ('19972', '7', '20886', '3000', '2', '7050', '1291883786', '0', '0', '6345', '0');
INSERT INTO `auction` VALUES ('19689', '6', '20603', '9719', '2', '402750', '1291880186', '0', '0', '314145', '0');
INSERT INTO `auction` VALUES ('19307', '7', '20221', '9719', '2', '368250', '1291840526', '0', '0', '338790', '0');
INSERT INTO `auction` VALUES ('19690', '6', '20604', '7973', '2', '6537', '1291876586', '0', '0', '4641', '0');
INSERT INTO `auction` VALUES ('19400', '7', '20314', '19441', '2', '24480', '1291851326', '0', '0', '22766', '0');
INSERT INTO `auction` VALUES ('19282', '7', '20196', '9719', '2', '435750', '1291872926', '0', '0', '331170', '0');
INSERT INTO `auction` VALUES ('19751', '6', '20665', '20678', '2', '40500', '1291847786', '0', '0', '33210', '0');
INSERT INTO `auction` VALUES ('19691', '6', '20605', '6360', '2', '156537', '1291880186', '0', '0', '154971', '0');
INSERT INTO `auction` VALUES ('19283', '7', '20197', '41119', '2', '41420', '1291876526', '0', '0', '41420', '0');
INSERT INTO `auction` VALUES ('19973', '7', '20887', '35654', '2', '2250426', '1291869386', '0', '0', '1980374', '0');
INSERT INTO `auction` VALUES ('20550', '7', '21464', '9060', '2', '13760', '1291883846', '0', '0', '10870', '0');
INSERT INTO `auction` VALUES ('18919', '2', '19833', '36597', '2', '6552431', '1291833326', '0', '0', '6224809', '0');
INSERT INTO `auction` VALUES ('19308', '7', '20222', '5110', '2', '2835', '1291887326', '0', '0', '2494', '0');
INSERT INTO `auction` VALUES ('19974', '7', '20888', '4698', '2', '3183', '1291876586', '0', '0', '2896', '0');
INSERT INTO `auction` VALUES ('19975', '7', '20889', '21595', '2', '1830', '1291836986', '0', '0', '1299', '0');
INSERT INTO `auction` VALUES ('19976', '7', '20890', '9719', '2', '420000', '1291847786', '0', '0', '390600', '0');
INSERT INTO `auction` VALUES ('19128', '6', '20042', '9719', '2', '413000', '1291880126', '0', '0', '351050', '0');
INSERT INTO `auction` VALUES ('19189', '6', '20103', '10514', '2', '18090', '1291887326', '0', '0', '17547', '0');
INSERT INTO `auction` VALUES ('19094', '6', '20008', '13880', '2', '261', '1291865726', '0', '0', '227', '0');
INSERT INTO `auction` VALUES ('19977', '7', '20891', '13024', '2', '423880', '1291887386', '0', '0', '406924', '0');
INSERT INTO `auction` VALUES ('19978', '7', '20892', '44700', '2', '5975', '1291872986', '0', '0', '5377', '0');
INSERT INTO `auction` VALUES ('19728', '6', '20642', '20662', '2', '1247604', '1291872986', '0', '0', '1085415', '0');
INSERT INTO `auction` VALUES ('20549', '7', '21463', '37160', '2', '3300', '1291855046', '0', '0', '3300', '0');
INSERT INTO `auction` VALUES ('19979', '7', '20893', '27515', '2', '19360', '1291847786', '0', '0', '14520', '0');
INSERT INTO `auction` VALUES ('19980', '7', '20894', '38303', '2', '126000', '1291876586', '0', '0', '98280', '0');
INSERT INTO `auction` VALUES ('20562', '7', '21476', '27516', '2', '12400', '1291851446', '0', '0', '11160', '0');
INSERT INTO `auction` VALUES ('19981', '7', '20895', '21882', '2', '165200', '1291844186', '0', '0', '142072', '0');
INSERT INTO `auction` VALUES ('19190', '6', '20104', '24476', '2', '9856', '1291883726', '0', '0', '7293', '0');
INSERT INTO `auction` VALUES ('19982', '7', '20896', '28452', '2', '27664', '1291840586', '0', '0', '24344', '0');
INSERT INTO `auction` VALUES ('19191', '6', '20105', '3261', '2', '84', '1291833326', '0', '0', '66', '0');
INSERT INTO `auction` VALUES ('19365', '7', '20279', '24637', '2', '577000', '1291833326', '0', '0', '496220', '0');
INSERT INTO `auction` VALUES ('19095', '6', '20009', '6359', '2', '288', '1291851326', '0', '0', '253', '0');
INSERT INTO `auction` VALUES ('19983', '7', '20897', '3415', '2', '262352', '1291833386', '0', '0', '215128', '0');
INSERT INTO `auction` VALUES ('19752', '6', '20666', '16647', '2', '582', '1291836986', '0', '0', '453', '0');
INSERT INTO `auction` VALUES ('19753', '6', '20667', '31157', '2', '2968817', '1291847786', '0', '0', '2909440', '0');
INSERT INTO `auction` VALUES ('19984', '7', '20898', '4377', '2', '12312', '1291833386', '0', '0', '11696', '0');
INSERT INTO `auction` VALUES ('19284', '7', '20198', '1475', '2', '1712', '1291872926', '0', '0', '1403', '0');
INSERT INTO `auction` VALUES ('19328', '7', '20242', '3844', '2', '444498', '1291880126', '0', '0', '440053', '0');
INSERT INTO `auction` VALUES ('19985', '7', '20899', '27513', '2', '162', '1291851386', '0', '0', '152', '0');
INSERT INTO `auction` VALUES ('20183', '2', '21097', '36287', '2', '2854668', '1291887446', '0', '0', '2283734', '0');
INSERT INTO `auction` VALUES ('20370', '6', '21284', '4387', '2', '11840', '1291851446', '0', '0', '11721', '0');
INSERT INTO `auction` VALUES ('19309', '7', '20223', '2824', '2', '5000195', '1291883726', '0', '0', '4100159', '0');
INSERT INTO `auction` VALUES ('19986', '7', '20900', '9719', '2', '357500', '1291883786', '0', '0', '296725', '0');
INSERT INTO `auction` VALUES ('19727', '6', '20641', '32715', '2', '855000', '1291847786', '0', '0', '820800', '0');
INSERT INTO `auction` VALUES ('20498', '7', '21412', '2265', '2', '19438', '1291840646', '0', '0', '17688', '0');
INSERT INTO `auction` VALUES ('19430', '7', '20344', '9420', '2', '348109', '1291876526', '0', '0', '309817', '0');
INSERT INTO `auction` VALUES ('19431', '7', '20345', '5110', '2', '3067', '1291858526', '0', '0', '2698', '0');
INSERT INTO `auction` VALUES ('19987', '7', '20901', '9719', '2', '366250', '1291844186', '0', '0', '311312', '0');
INSERT INTO `auction` VALUES ('20528', '7', '21442', '2203', '2', '68071', '1291883846', '0', '0', '59221', '0');
INSERT INTO `auction` VALUES ('19096', '6', '20010', '6651', '2', '2146', '1291862126', '0', '0', '1824', '0');
INSERT INTO `auction` VALUES ('19754', '6', '20668', '9719', '2', '351000', '1291869386', '0', '0', '312390', '0');
INSERT INTO `auction` VALUES ('19988', '7', '20902', '13877', '2', '270', '1291862186', '0', '0', '202', '0');
INSERT INTO `auction` VALUES ('19192', '6', '20106', '9719', '2', '418750', '1291865726', '0', '0', '418750', '0');
INSERT INTO `auction` VALUES ('19989', '7', '20903', '4377', '2', '990', '1291880186', '0', '0', '732', '0');
INSERT INTO `auction` VALUES ('19990', '7', '20904', '23329', '2', '27', '1291865786', '0', '0', '19', '0');
INSERT INTO `auction` VALUES ('19129', '6', '20043', '36486', '2', '5437975', '1291840526', '0', '0', '5383595', '0');
INSERT INTO `auction` VALUES ('19991', '7', '20905', '2265', '2', '25933', '1291862186', '0', '0', '23080', '0');
INSERT INTO `auction` VALUES ('19755', '6', '20669', '9719', '2', '418750', '1291847786', '0', '0', '326625', '0');
INSERT INTO `auction` VALUES ('19097', '6', '20011', '1981', '2', '2910141', '1291887326', '0', '0', '2473619', '0');
INSERT INTO `auction` VALUES ('19398', '7', '20312', '9719', '2', '427250', '1291829726', '0', '0', '410160', '0');
INSERT INTO `auction` VALUES ('19285', '7', '20199', '2100', '2', '5068737', '1291844126', '0', '0', '5018049', '0');
INSERT INTO `auction` VALUES ('19992', '7', '20906', '24823', '2', '1830906', '1291869386', '0', '0', '1666124', '0');
INSERT INTO `auction` VALUES ('19098', '6', '20012', '36743', '2', '43000', '1291883726', '0', '0', '31390', '0');
INSERT INTO `auction` VALUES ('19404', '7', '20318', '31234', '2', '6630901', '1291854926', '0', '0', '6166737', '0');
INSERT INTO `auction` VALUES ('19993', '7', '20907', '4377', '2', '12342', '1291844186', '0', '0', '9750', '0');
INSERT INTO `auction` VALUES ('19756', '6', '20670', '9719', '2', '321500', '1291833386', '0', '0', '318285', '0');
INSERT INTO `auction` VALUES ('19343', '7', '20257', '36665', '2', '4253757', '1291833326', '0', '0', '3870918', '0');
INSERT INTO `auction` VALUES ('19757', '6', '20671', '18709', '2', '425863', '1291887386', '0', '0', '336431', '0');
INSERT INTO `auction` VALUES ('19994', '7', '20908', '9719', '2', '423500', '1291829786', '0', '0', '359975', '0');
INSERT INTO `auction` VALUES ('20538', '7', '21452', '8284', '2', '707605', '1291833446', '0', '0', '629768', '0');
INSERT INTO `auction` VALUES ('20561', '7', '21475', '36158', '2', '1182484', '1291883846', '0', '0', '1170659', '0');
INSERT INTO `auction` VALUES ('19193', '6', '20107', '6514', '2', '328', '1291829726', '0', '0', '295', '0');
INSERT INTO `auction` VALUES ('19995', '7', '20909', '44700', '2', '4850', '1291844186', '0', '0', '4607', '0');
INSERT INTO `auction` VALUES ('19996', '7', '20910', '17969', '2', '221311', '1291851386', '0', '0', '221311', '0');
INSERT INTO `auction` VALUES ('19099', '6', '20013', '866', '2', '667296', '1291851326', '0', '0', '613912', '0');
INSERT INTO `auction` VALUES ('19997', '7', '20911', '9719', '2', '405000', '1291854986', '0', '0', '311850', '0');
INSERT INTO `auction` VALUES ('19998', '7', '20912', '6357', '2', '8', '1291883786', '0', '0', '6', '0');
INSERT INTO `auction` VALUES ('18931', '2', '19845', '24934', '2', '965137', '1291883726', '0', '0', '810715', '0');
INSERT INTO `auction` VALUES ('19286', '7', '20200', '9719', '2', '419750', '1291851326', '0', '0', '402960', '0');
INSERT INTO `auction` VALUES ('19999', '7', '20913', '18600', '2', '745440', '1291847786', '0', '0', '559080', '0');
INSERT INTO `auction` VALUES ('20000', '7', '20914', '12549', '2', '1086081', '1291851386', '0', '0', '955751', '0');
INSERT INTO `auction` VALUES ('19194', '6', '20108', '3279', '2', '1236', '1291854926', '0', '0', '1050', '0');
INSERT INTO `auction` VALUES ('19310', '7', '20224', '37749', '2', '8318866', '1291883726', '0', '0', '7154224', '0');
INSERT INTO `auction` VALUES ('18918', '2', '19832', '24245', '2', '24862', '1291833326', '0', '0', '22127', '0');
INSERT INTO `auction` VALUES ('19329', '7', '20243', '2257', '2', '1701', '1291865726', '0', '0', '1547', '0');
INSERT INTO `auction` VALUES ('19692', '6', '20606', '9719', '2', '336500', '1291851386', '0', '0', '289390', '0');
INSERT INTO `auction` VALUES ('19432', '7', '20346', '3319', '2', '942', '1291876526', '0', '0', '734', '0');
INSERT INTO `auction` VALUES ('19730', '6', '20644', '36161', '2', '2768845', '1291844186', '0', '0', '2353518', '0');
INSERT INTO `auction` VALUES ('20510', '7', '21424', '27516', '2', '3620', '1291873046', '0', '0', '3402', '0');
INSERT INTO `auction` VALUES ('20001', '7', '20915', '10574', '2', '306783', '1291847786', '0', '0', '245426', '0');
INSERT INTO `auction` VALUES ('20615', '7', '21529', '1314', '2', '17940', '1291837046', '0', '0', '16146', '0');
INSERT INTO `auction` VALUES ('20802', '6', '21752', '5637', '2', '1446', '1291830991', '0', '0', '1055', '0');
INSERT INTO `auction` VALUES ('20803', '6', '21753', '4388', '2', '6560', '1291830991', '0', '0', '6560', '0');
INSERT INTO `auction` VALUES ('20726', '2', '21676', '10561', '2', '64080', '1291841791', '0', '0', '61516', '0');
INSERT INTO `auction` VALUES ('20804', '6', '21754', '36162', '2', '1686104', '1291870591', '0', '0', '1601798', '0');
INSERT INTO `auction` VALUES ('20713', '2', '21663', '9061', '2', '13950', '1291884991', '0', '0', '12694', '0');
INSERT INTO `auction` VALUES ('20744', '2', '21694', '1951', '2', '87759', '1291830991', '0', '0', '80738', '0');
INSERT INTO `auction` VALUES ('20901', '7', '21851', '5637', '2', '558', '1291856191', '0', '0', '541', '0');
INSERT INTO `auction` VALUES ('20875', '7', '21825', '24936', '2', '1986481', '1291838191', '0', '0', '1887156', '0');
INSERT INTO `auction` VALUES ('20754', '2', '21704', '2241', '2', '17365', '1291884991', '0', '0', '14239', '0');
INSERT INTO `auction` VALUES ('20616', '7', '21530', '4637', '2', '7440', '1291837046', '0', '0', '7291', '0');
INSERT INTO `auction` VALUES ('20376', '6', '21290', '40195', '2', '4650', '1291876646', '0', '0', '4324', '0');
INSERT INTO `auction` VALUES ('20373', '6', '21287', '37145', '2', '9240', '1291880246', '0', '0', '8870', '0');
INSERT INTO `auction` VALUES ('20617', '7', '21531', '8151', '2', '29400', '1291855046', '0', '0', '23520', '0');
INSERT INTO `auction` VALUES ('20805', '6', '21755', '36396', '2', '3203572', '1291888591', '0', '0', '2562857', '0');
INSERT INTO `auction` VALUES ('19927', '7', '20841', '16654', '2', '427', '1291880186', '0', '0', '371', '0');
INSERT INTO `auction` VALUES ('20618', '7', '21532', '1475', '2', '3448', '1291844246', '0', '0', '3344', '0');
INSERT INTO `auction` VALUES ('20902', '7', '21852', '10514', '2', '98400', '1291870591', '0', '0', '78720', '0');
INSERT INTO `auction` VALUES ('20806', '6', '21756', '27511', '2', '179', '1291845391', '0', '0', '125', '0');
INSERT INTO `auction` VALUES ('20118', '2', '21032', '814', '2', '1158', '1291869446', '0', '0', '822', '0');
INSERT INTO `auction` VALUES ('20807', '6', '21757', '25228', '2', '4331132', '1291830991', '0', '0', '3638150', '0');
INSERT INTO `auction` VALUES ('20372', '6', '21286', '3186', '2', '202281', '1291855046', '0', '0', '202281', '0');
INSERT INTO `auction` VALUES ('19538', '2', '20452', '6195', '2', '18886', '1291872986', '0', '0', '18697', '0');
INSERT INTO `auction` VALUES ('20698', '2', '21648', '24476', '2', '9120', '1291870591', '0', '0', '7113', '0');
INSERT INTO `auction` VALUES ('20808', '6', '21758', '6358', '2', '653', '1291881391', '0', '0', '607', '0');
INSERT INTO `auction` VALUES ('20809', '6', '21759', '4388', '2', '8040', '1291877791', '0', '0', '7316', '0');
INSERT INTO `auction` VALUES ('20391', '6', '21305', '1938', '2', '109087', '1291887446', '0', '0', '107996', '0');
INSERT INTO `auction` VALUES ('20810', '6', '21760', '2623', '2', '201368', '1291834591', '0', '0', '191299', '0');
INSERT INTO `auction` VALUES ('20745', '2', '21695', '39682', '2', '83040', '1291888591', '0', '0', '59788', '0');
INSERT INTO `auction` VALUES ('20811', '6', '21761', '27513', '2', '183', '1291870591', '0', '0', '175', '0');
INSERT INTO `auction` VALUES ('20812', '6', '21762', '1214', '2', '59778', '1291841791', '0', '0', '52006', '0');
INSERT INTO `auction` VALUES ('20929', '7', '21879', '13757', '2', '21360', '1291866991', '0', '0', '20292', '0');
INSERT INTO `auction` VALUES ('20813', '6', '21763', '814', '2', '3819', '1291877791', '0', '0', '3475', '0');
INSERT INTO `auction` VALUES ('19928', '7', '20842', '31181', '2', '1085248', '1291840586', '0', '0', '955018', '0');
INSERT INTO `auction` VALUES ('19929', '7', '20843', '9719', '2', '424250', '1291847786', '0', '0', '352127', '0');
INSERT INTO `auction` VALUES ('20146', '2', '21060', '39682', '2', '108480', '1291851446', '0', '0', '83529', '0');
INSERT INTO `auction` VALUES ('18980', '2', '19894', '36147', '2', '1822110', '1291844126', '0', '0', '1585235', '0');
INSERT INTO `auction` VALUES ('20872', '7', '21822', '3223', '2', '15140', '1291841791', '0', '0', '13474', '0');
INSERT INTO `auction` VALUES ('20490', '7', '21404', '4359', '2', '900', '1291833446', '0', '0', '648', '0');
INSERT INTO `auction` VALUES ('20223', '2', '21137', '10559', '2', '90300', '1291833446', '0', '0', '87591', '0');
INSERT INTO `auction` VALUES ('20814', '6', '21764', '790', '2', '115050', '1291845391', '0', '0', '105846', '0');
INSERT INTO `auction` VALUES ('20815', '6', '21765', '37159', '2', '1720', '1291856191', '0', '0', '1599', '0');
INSERT INTO `auction` VALUES ('20816', '6', '21766', '36681', '2', '4711216', '1291856191', '0', '0', '4240094', '0');
INSERT INTO `auction` VALUES ('19930', '7', '20844', '24607', '2', '1096119', '1291833386', '0', '0', '986507', '0');
INSERT INTO `auction` VALUES ('20817', '6', '21767', '24667', '2', '1052661', '1291838191', '0', '0', '884235', '0');
INSERT INTO `auction` VALUES ('20818', '6', '21768', '24948', '2', '2012067', '1291863391', '0', '0', '1931584', '0');
INSERT INTO `auction` VALUES ('20147', '2', '21061', '45909', '2', '7776', '1291847846', '0', '0', '5754', '0');
INSERT INTO `auction` VALUES ('20819', '6', '21769', '3164', '2', '1706', '1291863391', '0', '0', '1211', '0');
INSERT INTO `auction` VALUES ('20075', '2', '20989', '9719', '2', '343000', '1291855046', '0', '0', '308700', '0');
INSERT INTO `auction` VALUES ('19452', '7', '20366', '7072', '2', '2844', '1291851326', '0', '0', '2047', '0');
INSERT INTO `auction` VALUES ('20874', '7', '21824', '4634', '2', '3230', '1291848991', '0', '0', '3036', '0');
INSERT INTO `auction` VALUES ('20654', '7', '21568', '36154', '2', '1024979', '1291858646', '0', '0', '942980', '0');
INSERT INTO `auction` VALUES ('20820', '6', '21770', '3563', '2', '23419', '1291845391', '0', '0', '20140', '0');
INSERT INTO `auction` VALUES ('20821', '6', '21771', '5029', '2', '258631', '1291863391', '0', '0', '243113', '0');
INSERT INTO `auction` VALUES ('20822', '6', '21772', '9060', '2', '60480', '1291866991', '0', '0', '42336', '0');
INSERT INTO `auction` VALUES ('20755', '2', '21705', '9249', '2', '50341', '1291866991', '0', '0', '42789', '0');
INSERT INTO `auction` VALUES ('19533', '2', '20447', '25215', '2', '4336131', '1291840586', '0', '0', '4206047', '0');
INSERT INTO `auction` VALUES ('20714', '2', '21664', '27516', '2', '14580', '1291856191', '0', '0', '12684', '0');
INSERT INTO `auction` VALUES ('20148', '2', '21062', '8152', '2', '57000', '1291862246', '0', '0', '53010', '0');
INSERT INTO `auction` VALUES ('20823', '6', '21773', '36176', '2', '2358012', '1291863391', '0', '0', '2192951', '0');
INSERT INTO `auction` VALUES ('20375', '6', '21289', '32717', '2', '1648500', '1291858646', '0', '0', '1500135', '0');
INSERT INTO `auction` VALUES ('20878', '7', '21828', '24948', '2', '2062637', '1291841791', '0', '0', '1959505', '0');
INSERT INTO `auction` VALUES ('20123', '2', '21037', '10514', '2', '118200', '1291844246', '0', '0', '105198', '0');
INSERT INTO `auction` VALUES ('20224', '2', '21138', '9060', '2', '162640', '1291865846', '0', '0', '141496', '0');
INSERT INTO `auction` VALUES ('19931', '7', '20845', '9396', '2', '498437', '1291833386', '0', '0', '373827', '0');
INSERT INTO `auction` VALUES ('20824', '6', '21774', '6204', '2', '111335', '1291877791', '0', '0', '111335', '0');
INSERT INTO `auction` VALUES ('20076', '2', '20990', '10505', '2', '37810', '1291837046', '0', '0', '32138', '0');
INSERT INTO `auction` VALUES ('20746', '2', '21696', '897', '2', '65548', '1291856191', '0', '0', '55060', '0');
INSERT INTO `auction` VALUES ('20825', '6', '21775', '37160', '2', '8010', '1291838191', '0', '0', '6648', '0');
INSERT INTO `auction` VALUES ('19532', '2', '20446', '25194', '2', '4227574', '1291840586', '0', '0', '3804816', '0');
INSERT INTO `auction` VALUES ('20699', '2', '21649', '814', '2', '1728', '1291830991', '0', '0', '1641', '0');
INSERT INTO `auction` VALUES ('20446', '6', '21360', '5523', '2', '1051', '1291873046', '0', '0', '1051', '0');
INSERT INTO `auction` VALUES ('20225', '2', '21139', '35995', '2', '1017290', '1291833446', '0', '0', '935906', '0');
INSERT INTO `auction` VALUES ('18981', '2', '19895', '32620', '2', '1383300', '1291833326', '0', '0', '1161972', '0');
INSERT INTO `auction` VALUES ('19531', '2', '20445', '9719', '2', '399250', '1291847786', '0', '0', '347347', '0');
INSERT INTO `auction` VALUES ('20619', '7', '21533', '31264', '2', '20484', '1291844246', '0', '0', '19869', '0');
INSERT INTO `auction` VALUES ('20826', '6', '21776', '36038', '2', '1271478', '1291856191', '0', '0', '1233333', '0');
INSERT INTO `auction` VALUES ('19537', '2', '20451', '31892', '2', '1709000', '1291862186', '0', '0', '1367200', '0');
INSERT INTO `auction` VALUES ('20747', '2', '21697', '3571', '2', '137073', '1291856191', '0', '0', '128848', '0');
INSERT INTO `auction` VALUES ('20077', '2', '20991', '27516', '2', '16960', '1291829846', '0', '0', '15772', '0');
INSERT INTO `auction` VALUES ('20871', '7', '21821', '24937', '2', '890926', '1291848991', '0', '0', '766196', '0');
INSERT INTO `auction` VALUES ('20655', '7', '21569', '9060', '2', '40200', '1291858646', '0', '0', '28542', '0');
INSERT INTO `auction` VALUES ('20149', '2', '21063', '36399', '2', '3078730', '1291847846', '0', '0', '2924793', '0');
INSERT INTO `auction` VALUES ('20418', '6', '21332', '3164', '2', '1073', '1291837046', '0', '0', '933', '0');
INSERT INTO `auction` VALUES ('20130', '2', '21044', '24608', '2', '740117', '1291844246', '0', '0', '680907', '0');
INSERT INTO `auction` VALUES ('20827', '6', '21777', '826', '2', '39805', '1291877791', '0', '0', '32640', '0');
INSERT INTO `auction` VALUES ('20129', '2', '21043', '40199', '2', '6448', '1291858646', '0', '0', '5996', '0');
INSERT INTO `auction` VALUES ('20408', '6', '21322', '2265', '2', '31306', '1291887446', '0', '0', '27549', '0');
INSERT INTO `auction` VALUES ('20078', '2', '20992', '9719', '2', '427250', '1291876646', '0', '0', '341800', '0');
INSERT INTO `auction` VALUES ('20150', '2', '21064', '6204', '2', '118668', '1291840646', '0', '0', '96121', '0');
INSERT INTO `auction` VALUES ('20226', '2', '21140', '4359', '2', '1320', '1291873046', '0', '0', '963', '0');
INSERT INTO `auction` VALUES ('20828', '6', '21778', '39681', '2', '280896', '1291863391', '0', '0', '235952', '0');
INSERT INTO `auction` VALUES ('19130', '6', '20044', '1608', '2', '1268086', '1291844126', '0', '0', '1179319', '0');
INSERT INTO `auction` VALUES ('19932', '7', '20846', '36056', '2', '1777747', '1291829786', '0', '0', '1546639', '0');
INSERT INTO `auction` VALUES ('20227', '2', '21141', '8254', '2', '562896', '1291887446', '0', '0', '484090', '0');
INSERT INTO `auction` VALUES ('20396', '6', '21310', '9060', '2', '43200', '1291862246', '0', '0', '34128', '0');
INSERT INTO `auction` VALUES ('20079', '2', '20993', '22277', '2', '12', '1291876646', '0', '0', '11', '0');
INSERT INTO `auction` VALUES ('19530', '2', '20444', '10328', '2', '513271', '1291858586', '0', '0', '415749', '0');
INSERT INTO `auction` VALUES ('20407', '6', '21321', '36525', '2', '5109129', '1291858646', '0', '0', '4547124', '0');
INSERT INTO `auction` VALUES ('19131', '6', '20045', '9719', '2', '361750', '1291844126', '0', '0', '285782', '0');
INSERT INTO `auction` VALUES ('20509', '7', '21423', '36400', '2', '3896453', '1291862246', '0', '0', '3117162', '0');
INSERT INTO `auction` VALUES ('20829', '6', '21779', '13422', '2', '1046', '1291874191', '0', '0', '889', '0');
INSERT INTO `auction` VALUES ('20390', '6', '21304', '4394', '2', '80640', '1291829846', '0', '0', '57254', '0');
INSERT INTO `auction` VALUES ('20830', '6', '21780', '13757', '2', '57840', '1291834591', '0', '0', '49164', '0');
INSERT INTO `auction` VALUES ('19344', '7', '20258', '32540', '2', '3698572', '1291836926', '0', '0', '3291729', '0');
INSERT INTO `auction` VALUES ('20831', '6', '21781', '4464', '2', '114616', '1291884991', '0', '0', '107739', '0');
INSERT INTO `auction` VALUES ('20116', '2', '21030', '9719', '2', '421500', '1291873046', '0', '0', '387780', '0');
INSERT INTO `auction` VALUES ('20832', '6', '21782', '5637', '2', '3525', '1291841791', '0', '0', '3031', '0');
INSERT INTO `auction` VALUES ('19529', '2', '20443', '9719', '2', '436750', '1291872986', '0', '0', '345032', '0');
INSERT INTO `auction` VALUES ('20833', '6', '21783', '36428', '2', '1971546', '1291834591', '0', '0', '1695529', '0');
INSERT INTO `auction` VALUES ('20228', '2', '21142', '10562', '2', '9120', '1291858646', '0', '0', '9120', '0');
INSERT INTO `auction` VALUES ('20080', '2', '20994', '6555', '2', '803', '1291880246', '0', '0', '690', '0');
INSERT INTO `auction` VALUES ('20560', '7', '21474', '1955', '2', '74037', '1291858646', '0', '0', '70335', '0');
INSERT INTO `auction` VALUES ('20389', '6', '21303', '18588', '2', '13752', '1291869446', '0', '0', '13752', '0');
INSERT INTO `auction` VALUES ('20081', '2', '20995', '2108', '2', '87', '1291833446', '0', '0', '61', '0');
INSERT INTO `auction` VALUES ('20834', '6', '21784', '5524', '2', '3250', '1291881391', '0', '0', '2470', '0');
INSERT INTO `auction` VALUES ('20727', '2', '21677', '5523', '2', '333', '1291870591', '0', '0', '273', '0');
INSERT INTO `auction` VALUES ('20835', '6', '21785', '39682', '2', '456960', '1291888591', '0', '0', '438681', '0');
INSERT INTO `auction` VALUES ('20489', '7', '21403', '6358', '2', '29', '1291851446', '0', '0', '23', '0');
INSERT INTO `auction` VALUES ('20836', '6', '21786', '36287', '2', '3378146', '1291884991', '0', '0', '3006549', '0');
INSERT INTO `auction` VALUES ('20229', '2', '21143', '36540', '2', '7989765', '1291883846', '0', '0', '7670174', '0');
INSERT INTO `auction` VALUES ('20120', '2', '21034', '885', '2', '156122', '1291833446', '0', '0', '124897', '0');
INSERT INTO `auction` VALUES ('20837', '6', '21787', '36057', '2', '2006956', '1291881391', '0', '0', '1786190', '0');
INSERT INTO `auction` VALUES ('20230', '2', '21144', '24712', '2', '919812', '1291876646', '0', '0', '800236', '0');
INSERT INTO `auction` VALUES ('20838', '6', '21788', '25278', '2', '3713740', '1291881391', '0', '0', '3082404', '0');
INSERT INTO `auction` VALUES ('19184', '6', '20098', '9719', '2', '347000', '1291876526', '0', '0', '291480', '0');
INSERT INTO `auction` VALUES ('19183', '6', '20097', '9719', '2', '378250', '1291854926', '0', '0', '355555', '0');
INSERT INTO `auction` VALUES ('20620', '7', '21534', '3341', '2', '71926', '1291840646', '0', '0', '71926', '0');
INSERT INTO `auction` VALUES ('20839', '6', '21789', '28541', '2', '1811817', '1291863391', '0', '0', '1467571', '0');
INSERT INTO `auction` VALUES ('20231', '2', '21145', '4290', '2', '33981', '1291840646', '0', '0', '27184', '0');
INSERT INTO `auction` VALUES ('19311', '7', '20225', '24368', '2', '96800', '1291829726', '0', '0', '67760', '0');
INSERT INTO `auction` VALUES ('20559', '7', '21473', '36444', '2', '1495972', '1291858646', '0', '0', '1466052', '0');
INSERT INTO `auction` VALUES ('19345', '7', '20259', '9251', '2', '410', '1291883726', '0', '0', '328', '0');
INSERT INTO `auction` VALUES ('20621', '7', '21535', '4464', '2', '105927', '1291865846', '0', '0', '97452', '0');
INSERT INTO `auction` VALUES ('20840', '6', '21790', '880', '2', '125043', '1291830991', '0', '0', '108787', '0');
INSERT INTO `auction` VALUES ('20700', '2', '21650', '13422', '2', '838', '1291859791', '0', '0', '653', '0');
INSERT INTO `auction` VALUES ('20841', '6', '21791', '5112', '2', '45710', '1291841791', '0', '0', '44795', '0');
INSERT INTO `auction` VALUES ('20371', '6', '21285', '25062', '2', '1055094', '1291855046', '0', '0', '844075', '0');
INSERT INTO `auction` VALUES ('19312', '7', '20226', '7730', '2', '687432', '1291854926', '0', '0', '549945', '0');
INSERT INTO `auction` VALUES ('19933', '7', '20847', '10562', '2', '89490', '1291851386', '0', '0', '74276', '0');
INSERT INTO `auction` VALUES ('20842', '6', '21792', '4767', '2', '5636', '1291888591', '0', '0', '4621', '0');
INSERT INTO `auction` VALUES ('20701', '2', '21651', '4402', '2', '8500', '1291859791', '0', '0', '8500', '0');
INSERT INTO `auction` VALUES ('20843', '6', '21793', '36375', '2', '2233654', '1291874191', '0', '0', '1853932', '0');
INSERT INTO `auction` VALUES ('19406', '7', '20320', '4402', '2', '3940', '1291887326', '0', '0', '3624', '0');
INSERT INTO `auction` VALUES ('20844', '6', '21794', '36413', '2', '1493720', '1291838191', '0', '0', '1478782', '0');
INSERT INTO `auction` VALUES ('20845', '6', '21795', '36399', '2', '2570811', '1291845391', '0', '0', '2545102', '0');
INSERT INTO `auction` VALUES ('20702', '2', '21652', '36036', '2', '1293818', '1291874191', '0', '0', '1216188', '0');
INSERT INTO `auction` VALUES ('19934', '7', '20848', '9719', '2', '395500', '1291887386', '0', '0', '355950', '0');
INSERT INTO `auction` VALUES ('20846', '6', '21796', '10367', '2', '1166374', '1291870591', '0', '0', '1131382', '0');
INSERT INTO `auction` VALUES ('19935', '7', '20849', '13916', '2', '936', '1291851386', '0', '0', '814', '0');
INSERT INTO `auction` VALUES ('20847', '6', '21797', '5749', '2', '157599', '1291863391', '0', '0', '132383', '0');
INSERT INTO `auction` VALUES ('18982', '2', '19896', '9406', '2', '358504', '1291887326', '0', '0', '351333', '0');
INSERT INTO `auction` VALUES ('20151', '2', '21065', '5256', '2', '363899', '1291865846', '0', '0', '342065', '0');
INSERT INTO `auction` VALUES ('19936', '7', '20850', '36286', '2', '1686282', '1291883786', '0', '0', '1433339', '0');
INSERT INTO `auction` VALUES ('20488', '7', '21402', '45909', '2', '13760', '1291844246', '0', '0', '12108', '0');
INSERT INTO `auction` VALUES ('20703', '2', '21653', '4402', '2', '12100', '1291870591', '0', '0', '9196', '0');
INSERT INTO `auction` VALUES ('20388', '6', '21302', '24949', '2', '925783', '1291840646', '0', '0', '814689', '0');
INSERT INTO `auction` VALUES ('20873', '7', '21823', '27511', '2', '200', '1291845391', '0', '0', '152', '0');
INSERT INTO `auction` VALUES ('20527', '7', '21441', '16654', '2', '407', '1291844246', '0', '0', '345', '0');
INSERT INTO `auction` VALUES ('20622', '7', '21536', '37147', '2', '1760', '1291880246', '0', '0', '1496', '0');
INSERT INTO `auction` VALUES ('19132', '6', '20046', '45909', '2', '51376', '1291887326', '0', '0', '48293', '0');
INSERT INTO `auction` VALUES ('20508', '7', '21422', '25062', '2', '1445152', '1291829846', '0', '0', '1300636', '0');
INSERT INTO `auction` VALUES ('20877', '7', '21827', '8151', '2', '1840', '1291830991', '0', '0', '1637', '0');
INSERT INTO `auction` VALUES ('20848', '6', '21798', '24890', '2', '2180019', '1291888591', '0', '0', '1765815', '0');
INSERT INTO `auction` VALUES ('20537', '7', '21451', '36485', '2', '7437244', '1291873046', '0', '0', '6991009', '0');
INSERT INTO `auction` VALUES ('20232', '2', '21146', '7973', '2', '7026', '1291862246', '0', '0', '6393', '0');
INSERT INTO `auction` VALUES ('19937', '7', '20851', '2911', '2', '38767', '1291887386', '0', '0', '36053', '0');
INSERT INTO `auction` VALUES ('20526', '7', '21440', '40199', '2', '600', '1291847846', '0', '0', '462', '0');
INSERT INTO `auction` VALUES ('19133', '6', '20047', '9361', '2', '4000', '1291862126', '0', '0', '3360', '0');
INSERT INTO `auction` VALUES ('20387', '6', '21301', '3053', '2', '126414', '1291876646', '0', '0', '120093', '0');
INSERT INTO `auction` VALUES ('19134', '6', '20048', '9719', '2', '379500', '1291858526', '0', '0', '352935', '0');
INSERT INTO `auction` VALUES ('19313', '7', '20227', '40195', '2', '79800', '1291862126', '0', '0', '59850', '0');
INSERT INTO `auction` VALUES ('20849', '6', '21799', '14895', '2', '411154', '1291881391', '0', '0', '337146', '0');
INSERT INTO `auction` VALUES ('20850', '6', '21800', '4771', '2', '8832', '1291838191', '0', '0', '7772', '0');
INSERT INTO `auction` VALUES ('19696', '6', '20610', '27516', '2', '19280', '1291833386', '0', '0', '15616', '0');
INSERT INTO `auction` VALUES ('19287', '7', '20201', '2110', '2', '61', '1291836926', '0', '0', '52', '0');
INSERT INTO `auction` VALUES ('20851', '6', '21801', '36387', '2', '1637119', '1291859791', '0', '0', '1391551', '0');
INSERT INTO `auction` VALUES ('20852', '6', '21802', '14832', '2', '219482', '1291874191', '0', '0', '215092', '0');
INSERT INTO `auction` VALUES ('19135', '6', '20049', '2100', '2', '3290814', '1291872926', '0', '0', '2928824', '0');
INSERT INTO `auction` VALUES ('20477', '7', '21391', '9719', '2', '357750', '1291865846', '0', '0', '282622', '0');
INSERT INTO `auction` VALUES ('19136', '6', '20050', '39970', '2', '69750', '1291862126', '0', '0', '62077', '0');
INSERT INTO `auction` VALUES ('20853', '6', '21803', '4047', '2', '206701', '1291888591', '0', '0', '167427', '0');
INSERT INTO `auction` VALUES ('20756', '2', '21706', '2058', '2', '229586', '1291834591', '0', '0', '192852', '0');
INSERT INTO `auction` VALUES ('19288', '7', '20202', '4278', '2', '4760', '1291847726', '0', '0', '4760', '0');
INSERT INTO `auction` VALUES ('20476', '7', '21390', '9719', '2', '330000', '1291862246', '0', '0', '273900', '0');
INSERT INTO `auction` VALUES ('20198', '2', '21112', '44700', '2', '4525', '1291851446', '0', '0', '3212', '0');
INSERT INTO `auction` VALUES ('19697', '6', '20611', '9719', '2', '381000', '1291833386', '0', '0', '354330', '0');
INSERT INTO `auction` VALUES ('19938', '7', '20852', '2227', '2', '249462', '1291869386', '0', '0', '224515', '0');
INSERT INTO `auction` VALUES ('19166', '6', '20080', '21590', '2', '455', '1291880126', '0', '0', '373', '0');
INSERT INTO `auction` VALUES ('19883', '7', '20797', '9719', '2', '324000', '1291869386', '0', '0', '320760', '0');
INSERT INTO `auction` VALUES ('20101', '2', '21015', '9719', '2', '373750', '1291858646', '0', '0', '351325', '0');
INSERT INTO `auction` VALUES ('20544', '7', '21458', '40199', '2', '1432', '1291869446', '0', '0', '1317', '0');
INSERT INTO `auction` VALUES ('18957', '2', '19871', '9719', '2', '369500', '1291829726', '0', '0', '277125', '0');
INSERT INTO `auction` VALUES ('18941', '2', '19855', '13755', '2', '2956', '1291858526', '0', '0', '2808', '0');
INSERT INTO `auction` VALUES ('18958', '2', '19872', '16717', '2', '895094', '1291854926', '0', '0', '895094', '0');
INSERT INTO `auction` VALUES ('19349', '7', '20263', '6197', '2', '45902', '1291851326', '0', '0', '37180', '0');
INSERT INTO `auction` VALUES ('18959', '2', '19873', '2567', '2', '190699', '1291844126', '0', '0', '181164', '0');
INSERT INTO `auction` VALUES ('18960', '2', '19874', '19258', '2', '629000', '1291840526', '0', '0', '610130', '0');
INSERT INTO `auction` VALUES ('18961', '2', '19875', '30722', '2', '30712504', '1291840526', '0', '0', '28255503', '0');
INSERT INTO `auction` VALUES ('19681', '6', '20595', '16656', '2', '397', '1291829786', '0', '0', '329', '0');
INSERT INTO `auction` VALUES ('18962', '2', '19876', '9719', '2', '393250', '1291862126', '0', '0', '365722', '0');
INSERT INTO `auction` VALUES ('20102', '2', '21016', '9719', '2', '408750', '1291887446', '0', '0', '314737', '0');
INSERT INTO `auction` VALUES ('18963', '2', '19877', '4402', '2', '7200', '1291836926', '0', '0', '6120', '0');
INSERT INTO `auction` VALUES ('19683', '6', '20597', '7734', '2', '803880', '1291887386', '0', '0', '602910', '0');
INSERT INTO `auction` VALUES ('18964', '2', '19878', '20676', '2', '24800', '1291854926', '0', '0', '20832', '0');
INSERT INTO `auction` VALUES ('18951', '2', '19865', '10560', '2', '21600', '1291887326', '0', '0', '20088', '0');
INSERT INTO `auction` VALUES ('20630', '7', '21544', '36380', '2', '3189761', '1291858646', '0', '0', '2870784', '0');
INSERT INTO `auction` VALUES ('18965', '2', '19879', '9719', '2', '382250', '1291887326', '0', '0', '359315', '0');
INSERT INTO `auction` VALUES ('19167', '6', '20081', '4359', '2', '747', '1291876526', '0', '0', '672', '0');
INSERT INTO `auction` VALUES ('19109', '6', '20023', '30736', '2', '9416807', '1291872926', '0', '0', '8380958', '0');
INSERT INTO `auction` VALUES ('18966', '2', '19880', '826', '2', '31493', '1291876526', '0', '0', '28028', '0');
INSERT INTO `auction` VALUES ('19350', '7', '20264', '4394', '2', '39480', '1291880126', '0', '0', '28820', '0');
INSERT INTO `auction` VALUES ('19143', '6', '20057', '24291', '2', '653300', '1291847726', '0', '0', '587970', '0');
INSERT INTO `auction` VALUES ('19144', '6', '20058', '21561', '2', '912', '1291833326', '0', '0', '665', '0');
INSERT INTO `auction` VALUES ('19145', '6', '20059', '13874', '2', '9', '1291844126', '0', '0', '8', '0');
INSERT INTO `auction` VALUES ('18967', '2', '19881', '31174', '2', '1793936', '1291865726', '0', '0', '1596603', '0');
INSERT INTO `auction` VALUES ('19315', '7', '20229', '6197', '2', '37725', '1291847726', '0', '0', '36970', '0');
INSERT INTO `auction` VALUES ('19713', '6', '20627', '3429', '2', '27472', '1291851386', '0', '0', '25274', '0');
INSERT INTO `auction` VALUES ('19316', '7', '20230', '36428', '2', '1799700', '1291840526', '0', '0', '1493751', '0');
INSERT INTO `auction` VALUES ('18968', '2', '19882', '5635', '2', '406', '1291872926', '0', '0', '353', '0');
INSERT INTO `auction` VALUES ('20103', '2', '21017', '9262', '2', '146880', '1291880246', '0', '0', '141004', '0');
INSERT INTO `auction` VALUES ('19380', '7', '20294', '31234', '2', '5730907', '1291854926', '0', '0', '4355489', '0');
INSERT INTO `auction` VALUES ('19351', '7', '20265', '9719', '2', '409750', '1291858526', '0', '0', '360580', '0');
INSERT INTO `auction` VALUES ('19402', '7', '20316', '9719', '2', '413000', '1291880126', '0', '0', '355180', '0');
INSERT INTO `auction` VALUES ('18969', '2', '19883', '32717', '2', '1237000', '1291869326', '0', '0', '1162780', '0');
INSERT INTO `auction` VALUES ('20859', '6', '21809', '36442', '2', '2091839', '1291888591', '0', '0', '1694389', '0');
INSERT INTO `auction` VALUES ('20860', '6', '21810', '36514', '2', '8375966', '1291859791', '0', '0', '6868292', '0');
INSERT INTO `auction` VALUES ('20485', '7', '21399', '1664', '2', '897876', '1291858646', '0', '0', '852982', '0');
INSERT INTO `auction` VALUES ('20534', '7', '21448', '1287', '2', '48865', '1291862246', '0', '0', '41046', '0');
INSERT INTO `auction` VALUES ('20861', '6', '21811', '24716', '2', '857544', '1291859791', '0', '0', '848968', '0');
INSERT INTO `auction` VALUES ('19671', '2', '20585', '4394', '2', '6720', '1291883786', '0', '0', '5241', '0');
INSERT INTO `auction` VALUES ('20503', '7', '21417', '39682', '2', '403200', '1291858646', '0', '0', '379008', '0');
INSERT INTO `auction` VALUES ('20862', '6', '21812', '1659', '2', '91446', '1291838191', '0', '0', '82301', '0');
INSERT INTO `auction` VALUES ('20863', '6', '21813', '38513', '2', '13548', '1291830991', '0', '0', '11244', '0');
INSERT INTO `auction` VALUES ('20864', '6', '21814', '25102', '2', '3266747', '1291845391', '0', '0', '3070742', '0');
INSERT INTO `auction` VALUES ('19352', '7', '20266', '44700', '2', '6025', '1291876526', '0', '0', '5603', '0');
INSERT INTO `auction` VALUES ('18940', '2', '19854', '9719', '2', '330500', '1291847726', '0', '0', '251180', '0');
INSERT INTO `auction` VALUES ('20524', '7', '21438', '36037', '2', '2237847', '1291858646', '0', '0', '2125954', '0');
INSERT INTO `auction` VALUES ('19381', '7', '20295', '16671', '2', '881048', '1291840526', '0', '0', '872237', '0');
INSERT INTO `auction` VALUES ('19382', '7', '20296', '37761', '2', '2012642', '1291854926', '0', '0', '2012642', '0');
INSERT INTO `auction` VALUES ('20504', '7', '21418', '10407', '2', '3931', '1291847846', '0', '0', '3026', '0');
INSERT INTO `auction` VALUES ('19407', '7', '20321', '31125', '2', '2292896', '1291854926', '0', '0', '1742600', '0');
INSERT INTO `auction` VALUES ('19940', '7', '20854', '31125', '2', '2715581', '1291880186', '0', '0', '2498334', '0');
INSERT INTO `auction` VALUES ('20515', '7', '21429', '6311', '2', '1845', '1291858646', '0', '0', '1678', '0');
INSERT INTO `auction` VALUES ('20865', '6', '21815', '8106', '2', '574655', '1291856191', '0', '0', '488456', '0');
INSERT INTO `auction` VALUES ('19110', '6', '20024', '4449', '2', '155289', '1291836926', '0', '0', '139760', '0');
INSERT INTO `auction` VALUES ('19146', '6', '20060', '13001', '2', '700245', '1291887326', '0', '0', '630220', '0');
INSERT INTO `auction` VALUES ('19941', '7', '20855', '1351', '2', '31290', '1291833386', '0', '0', '27222', '0');
INSERT INTO `auction` VALUES ('20866', '6', '21816', '2072', '2', '274330', '1291863391', '0', '0', '274330', '0');
INSERT INTO `auction` VALUES ('18939', '2', '19853', '1297', '2', '117944', '1291851326', '0', '0', '101431', '0');
INSERT INTO `auction` VALUES ('19111', '6', '20025', '37771', '2', '2657574', '1291887326', '0', '0', '2630998', '0');
INSERT INTO `auction` VALUES ('20083', '2', '20997', '10407', '2', '5184', '1291851446', '0', '0', '4821', '0');
INSERT INTO `auction` VALUES ('19358', '7', '20272', '37145', '2', '4075', '1291858526', '0', '0', '3382', '0');
INSERT INTO `auction` VALUES ('19112', '6', '20026', '30730', '2', '11562664', '1291883726', '0', '0', '10984530', '0');
INSERT INTO `auction` VALUES ('19298', '7', '20212', '2291', '2', '7473837', '1291844126', '0', '0', '6651714', '0');
INSERT INTO `auction` VALUES ('19942', '7', '20856', '10505', '2', '19440', '1291858586', '0', '0', '15357', '0');
INSERT INTO `auction` VALUES ('20571', '7', '21485', '39682', '2', '168000', '1291865846', '0', '0', '131040', '0');
INSERT INTO `auction` VALUES ('20572', '7', '21486', '5523', '2', '612', '1291862246', '0', '0', '575', '0');
INSERT INTO `auction` VALUES ('19383', '7', '20297', '9719', '2', '315250', '1291880126', '0', '0', '308945', '0');
INSERT INTO `auction` VALUES ('19922', '7', '20836', '29426', '2', '135936', '1291869386', '0', '0', '100592', '0');
INSERT INTO `auction` VALUES ('19714', '6', '20628', '814', '2', '624', '1291865786', '0', '0', '468', '0');
INSERT INTO `auction` VALUES ('20573', '7', '21487', '4810', '2', '186036', '1291883846', '0', '0', '152549', '0');
INSERT INTO `auction` VALUES ('19113', '6', '20027', '39681', '2', '317968', '1291869326', '0', '0', '302069', '0');
INSERT INTO `auction` VALUES ('19679', '6', '20593', '9746', '2', '438', '1291887386', '0', '0', '433', '0');
INSERT INTO `auction` VALUES ('19408', '7', '20322', '9719', '2', '376250', '1291883726', '0', '0', '331100', '0');
INSERT INTO `auction` VALUES ('20574', '7', '21488', '12804', '2', '275520', '1291873046', '0', '0', '225926', '0');
INSERT INTO `auction` VALUES ('18926', '2', '19840', '9719', '2', '383000', '1291851326', '0', '0', '317890', '0');
INSERT INTO `auction` VALUES ('19939', '7', '20853', '40199', '2', '1600', '1291865786', '0', '0', '1232', '0');
INSERT INTO `auction` VALUES ('19384', '7', '20298', '12531', '2', '2472419', '1291880126', '0', '0', '2324073', '0');
INSERT INTO `auction` VALUES ('19317', '7', '20231', '9719', '2', '325750', '1291887326', '0', '0', '286660', '0');
INSERT INTO `auction` VALUES ('19715', '6', '20629', '5423', '2', '152369', '1291854986', '0', '0', '135608', '0');
INSERT INTO `auction` VALUES ('19716', '6', '20630', '1384', '2', '132', '1291880186', '0', '0', '116', '0');
INSERT INTO `auction` VALUES ('19943', '7', '20857', '3321', '2', '420', '1291851386', '0', '0', '352', '0');
INSERT INTO `auction` VALUES ('20575', '7', '21489', '19943', '2', '77600', '1291862246', '0', '0', '67512', '0');
INSERT INTO `auction` VALUES ('19944', '7', '20858', '9719', '2', '410750', '1291844186', '0', '0', '320385', '0');
INSERT INTO `auction` VALUES ('20576', '7', '21490', '1288', '2', '3885', '1291837046', '0', '0', '3069', '0');
INSERT INTO `auction` VALUES ('19945', '7', '20859', '24476', '2', '12096', '1291840586', '0', '0', '11612', '0');
INSERT INTO `auction` VALUES ('20523', '7', '21437', '35836', '2', '65600', '1291855046', '0', '0', '62976', '0');
INSERT INTO `auction` VALUES ('20577', '7', '21491', '36584', '2', '5266593', '1291837046', '0', '0', '4476604', '0');
INSERT INTO `auction` VALUES ('20578', '7', '21492', '4589', '2', '18062', '1291855046', '0', '0', '14268', '0');
INSERT INTO `auction` VALUES ('19882', '7', '20796', '9480', '2', '2334974', '1291851386', '0', '0', '2264924', '0');
INSERT INTO `auction` VALUES ('20579', '7', '21493', '37160', '2', '22600', '1291844246', '0', '0', '16950', '0');
INSERT INTO `auction` VALUES ('19385', '7', '20299', '9719', '2', '377750', '1291840526', '0', '0', '328642', '0');
INSERT INTO `auction` VALUES ('20580', '7', '21494', '5112', '2', '43045', '1291880246', '0', '0', '42614', '0');
INSERT INTO `auction` VALUES ('20581', '7', '21495', '24888', '2', '1927913', '1291862246', '0', '0', '1908633', '0');
INSERT INTO `auction` VALUES ('20582', '7', '21496', '9061', '2', '42660', '1291851446', '0', '0', '31141', '0');
INSERT INTO `auction` VALUES ('19946', '7', '20860', '21595', '2', '1649', '1291862186', '0', '0', '1220', '0');
INSERT INTO `auction` VALUES ('20380', '6', '21294', '36667', '2', '5605719', '1291847846', '0', '0', '5493604', '0');
INSERT INTO `auction` VALUES ('19333', '7', '20247', '36581', '2', '6555152', '1291883726', '0', '0', '5375224', '0');
INSERT INTO `auction` VALUES ('20583', '7', '21497', '36584', '2', '7252358', '1291840646', '0', '0', '6962263', '0');
INSERT INTO `auction` VALUES ('20584', '7', '21498', '37145', '2', '12600', '1291887446', '0', '0', '11088', '0');
INSERT INTO `auction` VALUES ('20543', '7', '21457', '36398', '2', '1950303', '1291837046', '0', '0', '1813781', '0');
INSERT INTO `auction` VALUES ('19670', '2', '20584', '25144', '2', '3632538', '1291872986', '0', '0', '3341934', '0');
INSERT INTO `auction` VALUES ('19147', '6', '20061', '7973', '2', '1413', '1291833326', '0', '0', '1186', '0');
INSERT INTO `auction` VALUES ('19947', '7', '20861', '13422', '2', '744', '1291829786', '0', '0', '691', '0');
INSERT INTO `auction` VALUES ('19717', '6', '20631', '9308', '2', '1477', '1291851386', '0', '0', '1225', '0');
INSERT INTO `auction` VALUES ('19718', '6', '20632', '8223', '2', '689072', '1291833386', '0', '0', '537476', '0');
INSERT INTO `auction` VALUES ('20585', '7', '21499', '4465', '2', '73422', '1291858646', '0', '0', '68282', '0');
INSERT INTO `auction` VALUES ('19699', '6', '20613', '13904', '2', '173', '1291829786', '0', '0', '167', '0');
INSERT INTO `auction` VALUES ('19386', '7', '20300', '28494', '2', '3303761', '1291876526', '0', '0', '2576933', '0');
INSERT INTO `auction` VALUES ('20586', '7', '21500', '24685', '2', '697594', '1291840646', '0', '0', '613882', '0');
INSERT INTO `auction` VALUES ('20587', '7', '21501', '14895', '2', '355790', '1291847846', '0', '0', '348674', '0');
INSERT INTO `auction` VALUES ('19948', '7', '20862', '9719', '2', '322750', '1291836986', '0', '0', '293702', '0');
INSERT INTO `auction` VALUES ('19387', '7', '20301', '22897', '2', '658400', '1291865726', '0', '0', '625480', '0');
INSERT INTO `auction` VALUES ('20588', '7', '21502', '24612', '2', '610936', '1291829846', '0', '0', '562061', '0');
INSERT INTO `auction` VALUES ('19334', '7', '20248', '2898', '2', '298', '1291865726', '0', '0', '217', '0');
INSERT INTO `auction` VALUES ('20589', '7', '21503', '37160', '2', '14580', '1291829846', '0', '0', '11955', '0');
INSERT INTO `auction` VALUES ('20502', '7', '21416', '20518', '2', '24800', '1291873046', '0', '0', '20336', '0');
INSERT INTO `auction` VALUES ('19148', '6', '20062', '1475', '2', '3009', '1291847726', '0', '0', '2587', '0');
INSERT INTO `auction` VALUES ('19353', '7', '20267', '5637', '2', '498', '1291883726', '0', '0', '368', '0');
INSERT INTO `auction` VALUES ('19318', '7', '20232', '36040', '2', '2040318', '1291836926', '0', '0', '1999511', '0');
INSERT INTO `auction` VALUES ('19299', '7', '20213', '2065', '2', '870', '1291865726', '0', '0', '765', '0');
INSERT INTO `auction` VALUES ('19921', '7', '20835', '5758', '2', '11270', '1291883786', '0', '0', '9354', '0');
INSERT INTO `auction` VALUES ('19114', '6', '20028', '9719', '2', '328000', '1291887326', '0', '0', '255840', '0');
INSERT INTO `auction` VALUES ('19335', '7', '20249', '10026', '2', '374815', '1291833326', '0', '0', '326089', '0');
INSERT INTO `auction` VALUES ('19149', '6', '20063', '21882', '2', '108000', '1291844126', '0', '0', '91800', '0');
INSERT INTO `auction` VALUES ('19336', '7', '20250', '9719', '2', '335250', '1291876526', '0', '0', '251437', '0');
INSERT INTO `auction` VALUES ('18950', '2', '19864', '14554', '2', '8223149', '1291883726', '0', '0', '7154139', '0');
INSERT INTO `auction` VALUES ('18938', '2', '19852', '44475', '2', '188', '1291836926', '0', '0', '131', '0');
INSERT INTO `auction` VALUES ('20590', '7', '21504', '41119', '2', '49800', '1291837046', '0', '0', '47310', '0');
INSERT INTO `auction` VALUES ('19923', '7', '20837', '9719', '2', '323000', '1291833386', '0', '0', '287470', '0');
INSERT INTO `auction` VALUES ('20591', '7', '21505', '13757', '2', '33696', '1291869446', '0', '0', '27967', '0');
INSERT INTO `auction` VALUES ('19669', '2', '20583', '34859', '2', '528582', '1291865786', '0', '0', '422865', '0');
INSERT INTO `auction` VALUES ('19719', '6', '20633', '9719', '2', '378500', '1291887386', '0', '0', '352005', '0');
INSERT INTO `auction` VALUES ('19409', '7', '20323', '40195', '2', '5160', '1291887326', '0', '0', '3766', '0');
INSERT INTO `auction` VALUES ('19115', '6', '20029', '14558', '2', '1863120', '1291869326', '0', '0', '1732701', '0');
INSERT INTO `auction` VALUES ('19410', '7', '20324', '9719', '2', '426000', '1291887326', '0', '0', '404700', '0');
INSERT INTO `auction` VALUES ('20556', '7', '21470', '37160', '2', '16915', '1291840646', '0', '0', '13193', '0');
INSERT INTO `auction` VALUES ('19388', '7', '20302', '9719', '2', '430500', '1291862126', '0', '0', '400365', '0');
INSERT INTO `auction` VALUES ('20592', '7', '21506', '10400', '2', '38212', '1291865846', '0', '0', '36683', '0');
INSERT INTO `auction` VALUES ('20593', '7', '21507', '36167', '2', '2078585', '1291876646', '0', '0', '1766797', '0');
INSERT INTO `auction` VALUES ('20555', '7', '21469', '15687', '2', '1645235', '1291887446', '0', '0', '1365545', '0');
INSERT INTO `auction` VALUES ('19300', '7', '20214', '8152', '2', '69540', '1291883726', '0', '0', '48678', '0');
INSERT INTO `auction` VALUES ('19337', '7', '20251', '4589', '2', '36464', '1291858526', '0', '0', '28806', '0');
INSERT INTO `auction` VALUES ('19389', '7', '20303', '37756', '2', '2669745', '1291844126', '0', '0', '2429467', '0');
INSERT INTO `auction` VALUES ('19401', '7', '20315', '9719', '2', '411000', '1291880126', '0', '0', '374010', '0');
INSERT INTO `auction` VALUES ('20594', '7', '21508', '7072', '2', '2736', '1291869446', '0', '0', '1997', '0');
INSERT INTO `auction` VALUES ('19411', '7', '20325', '13422', '2', '60', '1291883726', '0', '0', '45', '0');
INSERT INTO `auction` VALUES ('19682', '6', '20596', '10514', '2', '46080', '1291836986', '0', '0', '42393', '0');
INSERT INTO `auction` VALUES ('20595', '7', '21509', '1475', '2', '1082', '1291887446', '0', '0', '768', '0');
INSERT INTO `auction` VALUES ('19168', '6', '20082', '36288', '2', '3323099', '1291851326', '0', '0', '2891096', '0');
INSERT INTO `auction` VALUES ('19680', '6', '20594', '8179', '2', '299', '1291851386', '0', '0', '287', '0');
INSERT INTO `auction` VALUES ('20596', '7', '21510', '24999', '2', '2335844', '1291858646', '0', '0', '2312485', '0');
INSERT INTO `auction` VALUES ('20522', '7', '21436', '36556', '2', '8319354', '1291847846', '0', '0', '6655483', '0');
INSERT INTO `auction` VALUES ('19116', '6', '20030', '31200', '2', '3249753', '1291851326', '0', '0', '2859782', '0');
INSERT INTO `auction` VALUES ('19677', '6', '20591', '20708', '2', '23', '1291833386', '0', '0', '22', '0');
INSERT INTO `auction` VALUES ('19169', '6', '20083', '32470', '2', '171000', '1291844126', '0', '0', '153900', '0');
INSERT INTO `auction` VALUES ('20597', '7', '21511', '18588', '2', '9240', '1291887446', '0', '0', '9147', '0');
INSERT INTO `auction` VALUES ('18925', '2', '19839', '13422', '2', '1672', '1291887326', '0', '0', '1504', '0');
INSERT INTO `auction` VALUES ('20598', '7', '21512', '7973', '2', '6097', '1291855046', '0', '0', '5792', '0');
INSERT INTO `auction` VALUES ('19678', '6', '20592', '1604', '2', '1287543', '1291854986', '0', '0', '1042909', '0');
INSERT INTO `auction` VALUES ('20599', '7', '21513', '5079', '2', '188114', '1291844246', '0', '0', '184351', '0');
INSERT INTO `auction` VALUES ('20600', '7', '21514', '10514', '2', '35550', '1291840646', '0', '0', '33417', '0');
INSERT INTO `auction` VALUES ('19412', '7', '20326', '27516', '2', '14080', '1291880126', '0', '0', '11123', '0');
INSERT INTO `auction` VALUES ('19390', '7', '20304', '36168', '2', '2418875', '1291887326', '0', '0', '2080232', '0');
INSERT INTO `auction` VALUES ('19391', '7', '20305', '9719', '2', '362750', '1291829726', '0', '0', '286572', '0');
INSERT INTO `auction` VALUES ('19413', '7', '20327', '21882', '2', '144800', '1291887326', '0', '0', '133216', '0');
INSERT INTO `auction` VALUES ('19214', '6', '20128', '9719', '2', '392500', '1291847726', '0', '0', '341475', '0');
INSERT INTO `auction` VALUES ('20601', '7', '21515', '36696', '2', '6858959', '1291865846', '0', '0', '6173063', '0');
INSERT INTO `auction` VALUES ('20602', '7', '21516', '892', '2', '22736', '1291862246', '0', '0', '19552', '0');
INSERT INTO `auction` VALUES ('19215', '6', '20129', '7973', '2', '2136', '1291883726', '0', '0', '2114', '0');
INSERT INTO `auction` VALUES ('20603', '7', '21517', '789', '2', '98470', '1291880246', '0', '0', '92561', '0');
INSERT INTO `auction` VALUES ('20070', '7', '20984', '6309', '2', '772', '1291880186', '0', '0', '602', '0');
INSERT INTO `auction` VALUES ('20604', '7', '21518', '12804', '2', '15120', '1291873046', '0', '0', '14061', '0');
INSERT INTO `auction` VALUES ('18924', '2', '19838', '14554', '2', '9474551', '1291854926', '0', '0', '8148113', '0');
INSERT INTO `auction` VALUES ('19405', '7', '20319', '44700', '2', '4050', '1291844126', '0', '0', '3888', '0');
INSERT INTO `auction` VALUES ('20605', '7', '21519', '24665', '2', '907227', '1291869446', '0', '0', '762070', '0');
INSERT INTO `auction` VALUES ('19720', '6', '20634', '7729', '2', '348798', '1291844186', '0', '0', '279038', '0');
INSERT INTO `auction` VALUES ('18923', '2', '19837', '9719', '2', '390500', '1291876526', '0', '0', '386595', '0');
INSERT INTO `auction` VALUES ('19216', '6', '20130', '30458', '2', '80304', '1291872926', '0', '0', '73879', '0');
INSERT INTO `auction` VALUES ('19920', '7', '20834', '3164', '2', '238', '1291840586', '0', '0', '183', '0');
INSERT INTO `auction` VALUES ('19170', '6', '20084', '9719', '2', '435250', '1291858526', '0', '0', '352552', '0');
INSERT INTO `auction` VALUES ('19414', '7', '20328', '41119', '2', '31500', '1291865726', '0', '0', '24885', '0');
INSERT INTO `auction` VALUES ('19721', '6', '20635', '9378', '2', '883119', '1291865786', '0', '0', '750651', '0');
INSERT INTO `auction` VALUES ('19354', '7', '20268', '36288', '2', '4475544', '1291851326', '0', '0', '3669946', '0');
INSERT INTO `auction` VALUES ('19301', '7', '20215', '9397', '2', '244241', '1291854926', '0', '0', '214932', '0');
INSERT INTO `auction` VALUES ('20069', '7', '20983', '20692', '2', '533975', '1291847786', '0', '0', '443199', '0');
INSERT INTO `auction` VALUES ('19868', '6', '20782', '13757', '2', '23136', '1291858586', '0', '0', '21053', '0');
INSERT INTO `auction` VALUES ('19065', '2', '19979', '27513', '2', '191', '1291883726', '0', '0', '164', '0');
INSERT INTO `auction` VALUES ('19950', '7', '20864', '4434', '2', '34229', '1291880186', '0', '0', '31490', '0');
INSERT INTO `auction` VALUES ('19951', '7', '20865', '6359', '2', '571', '1291869386', '0', '0', '542', '0');
INSERT INTO `auction` VALUES ('19952', '7', '20866', '6309', '2', '704', '1291836986', '0', '0', '549', '0');
INSERT INTO `auction` VALUES ('19601', '2', '20515', '2013', '2', '203550', '1291876586', '0', '0', '175053', '0');
INSERT INTO `auction` VALUES ('19953', '7', '20867', '25271', '2', '2524544', '1291876586', '0', '0', '2145862', '0');
INSERT INTO `auction` VALUES ('19954', '7', '20868', '2620', '2', '193158', '1291876586', '0', '0', '193158', '0');
INSERT INTO `auction` VALUES ('19022', '2', '19936', '5624', '2', '125129', '1291854926', '0', '0', '123877', '0');
INSERT INTO `auction` VALUES ('19450', '7', '20364', '9719', '2', '381250', '1291851326', '0', '0', '346937', '0');
INSERT INTO `auction` VALUES ('19676', '6', '20590', '31155', '2', '3887541', '1291872986', '0', '0', '3187783', '0');
INSERT INTO `auction` VALUES ('19675', '6', '20589', '6307', '2', '6', '1291862186', '0', '0', '4', '0');
INSERT INTO `auction` VALUES ('19002', '2', '19916', '3323', '2', '168', '1291883726', '0', '0', '131', '0');
INSERT INTO `auction` VALUES ('19955', '7', '20869', '3058', '2', '43596', '1291829786', '0', '0', '40544', '0');
INSERT INTO `auction` VALUES ('19956', '7', '20870', '12607', '2', '559549', '1291872986', '0', '0', '436448', '0');
INSERT INTO `auction` VALUES ('19957', '7', '20871', '28533', '2', '1406746', '1291872986', '0', '0', '1252003', '0');
INSERT INTO `auction` VALUES ('19650', '2', '20564', '24942', '2', '1489987', '1291844186', '0', '0', '1475087', '0');
INSERT INTO `auction` VALUES ('19038', '2', '19952', '25004', '2', '2340511', '1291865726', '0', '0', '1895813', '0');
INSERT INTO `auction` VALUES ('19732', '6', '20646', '9719', '2', '349000', '1291854986', '0', '0', '265240', '0');
INSERT INTO `auction` VALUES ('18976', '2', '19890', '37147', '2', '14300', '1291883726', '0', '0', '11011', '0');
INSERT INTO `auction` VALUES ('19039', '2', '19953', '9384', '2', '739589', '1291836926', '0', '0', '621254', '0');
INSERT INTO `auction` VALUES ('19958', '7', '20872', '24476', '2', '11816', '1291872986', '0', '0', '11816', '0');
INSERT INTO `auction` VALUES ('19959', '7', '20873', '3336', '2', '192353', '1291858586', '0', '0', '157729', '0');
INSERT INTO `auction` VALUES ('19960', '7', '20874', '7072', '2', '1272', '1291880186', '0', '0', '1119', '0');
INSERT INTO `auction` VALUES ('20953', '7', '21903', '36640', '2', '3726190', '1291856191', '0', '0', '3055475', '0');
INSERT INTO `auction` VALUES ('20891', '7', '21841', '5637', '2', '3465', '1291841791', '0', '0', '3361', '0');
INSERT INTO `auction` VALUES ('19961', '7', '20875', '9719', '2', '398000', '1291883786', '0', '0', '346260', '0');
INSERT INTO `auction` VALUES ('19003', '2', '19917', '1993', '2', '83412', '1291869326', '0', '0', '76739', '0');
INSERT INTO `auction` VALUES ('19962', '7', '20876', '5637', '2', '2625', '1291836986', '0', '0', '1916', '0');
INSERT INTO `auction` VALUES ('20563', '7', '21477', '25312', '2', '2563713', '1291829846', '0', '0', '2461164', '0');
INSERT INTO `auction` VALUES ('20482', '7', '21396', '36457', '2', '3608926', '1291833446', '0', '0', '3464568', '0');
INSERT INTO `auction` VALUES ('19771', '6', '20685', '37147', '2', '16200', '1291847786', '0', '0', '13122', '0');
INSERT INTO `auction` VALUES ('19772', '6', '20686', '9719', '2', '413250', '1291865786', '0', '0', '334732', '0');
INSERT INTO `auction` VALUES ('18977', '2', '19891', '9719', '2', '339250', '1291847726', '0', '0', '325680', '0');
INSERT INTO `auction` VALUES ('19773', '6', '20687', '9719', '2', '379500', '1291851386', '0', '0', '326370', '0');
INSERT INTO `auction` VALUES ('19774', '6', '20688', '899', '2', '51371', '1291836986', '0', '0', '43665', '0');
INSERT INTO `auction` VALUES ('19004', '2', '19918', '9719', '2', '410500', '1291865726', '0', '0', '398185', '0');
INSERT INTO `auction` VALUES ('19775', '6', '20689', '24999', '2', '2167849', '1291887386', '0', '0', '2146170', '0');
INSERT INTO `auction` VALUES ('19651', '2', '20565', '9719', '2', '389250', '1291887386', '0', '0', '385357', '0');
INSERT INTO `auction` VALUES ('20062', '7', '20976', '36175', '2', '2469811', '1291854986', '0', '0', '2000546', '0');
INSERT INTO `auction` VALUES ('19612', '2', '20526', '4444', '2', '69285', '1291862186', '0', '0', '59585', '0');
INSERT INTO `auction` VALUES ('19613', '2', '20527', '37145', '2', '18300', '1291865786', '0', '0', '12810', '0');
INSERT INTO `auction` VALUES ('19040', '2', '19954', '19441', '2', '27180', '1291862126', '0', '0', '25821', '0');
INSERT INTO `auction` VALUES ('19614', '2', '20528', '9719', '2', '371500', '1291829786', '0', '0', '367785', '0');
INSERT INTO `auction` VALUES ('19615', '2', '20529', '37159', '2', '15570', '1291844186', '0', '0', '14947', '0');
INSERT INTO `auction` VALUES ('19616', '2', '20530', '34826', '2', '1332000', '1291880186', '0', '0', '932400', '0');
INSERT INTO `auction` VALUES ('19776', '6', '20690', '2057', '2', '149', '1291851386', '0', '0', '141', '0');
INSERT INTO `auction` VALUES ('19617', '2', '20531', '1928', '2', '49650', '1291865786', '0', '0', '48160', '0');
INSERT INTO `auction` VALUES ('20650', '7', '21564', '36011', '2', '940358', '1291833446', '0', '0', '799304', '0');
INSERT INTO `auction` VALUES ('19618', '2', '20532', '27513', '2', '158', '1291833386', '0', '0', '158', '0');
INSERT INTO `auction` VALUES ('19777', '6', '20691', '6332', '2', '67517', '1291872986', '0', '0', '64816', '0');
INSERT INTO `auction` VALUES ('19778', '6', '20692', '45909', '2', '2816', '1291887386', '0', '0', '2618', '0');
INSERT INTO `auction` VALUES ('19185', '6', '20099', '40195', '2', '68310', '1291833326', '0', '0', '65577', '0');
INSERT INTO `auction` VALUES ('19005', '2', '19919', '9719', '2', '316750', '1291880126', '0', '0', '304080', '0');
INSERT INTO `auction` VALUES ('19779', '6', '20693', '18612', '2', '272', '1291865786', '0', '0', '236', '0');
INSERT INTO `auction` VALUES ('20651', '7', '21565', '27511', '2', '165', '1291865846', '0', '0', '151', '0');
INSERT INTO `auction` VALUES ('19764', '6', '20678', '9719', '2', '431500', '1291858586', '0', '0', '427185', '0');
INSERT INTO `auction` VALUES ('19780', '6', '20694', '44722', '2', '40128', '1291829786', '0', '0', '37720', '0');
INSERT INTO `auction` VALUES ('20652', '7', '21566', '24887', '2', '1744088', '1291840646', '0', '0', '1534797', '0');
INSERT INTO `auction` VALUES ('19781', '6', '20695', '36164', '2', '2386348', '1291880186', '0', '0', '2076122', '0');
INSERT INTO `auction` VALUES ('20892', '7', '21842', '4611', '2', '4810', '1291841791', '0', '0', '4761', '0');
INSERT INTO `auction` VALUES ('20893', '7', '21843', '13422', '2', '931', '1291866991', '0', '0', '837', '0');
INSERT INTO `auction` VALUES ('20385', '6', '21299', '9249', '2', '85642', '1291862246', '0', '0', '75364', '0');
INSERT INTO `auction` VALUES ('19782', '6', '20696', '35652', '2', '7105227', '1291887386', '0', '0', '5613129', '0');
INSERT INTO `auction` VALUES ('18978', '2', '19892', '3844', '2', '402906', '1291876526', '0', '0', '398876', '0');
INSERT INTO `auction` VALUES ('19783', '6', '20697', '9719', '2', '375250', '1291836986', '0', '0', '303952', '0');
INSERT INTO `auction` VALUES ('19023', '2', '19937', '9719', '2', '359250', '1291887326', '0', '0', '352065', '0');
INSERT INTO `auction` VALUES ('19784', '6', '20698', '40195', '2', '9120', '1291887386', '0', '0', '6748', '0');
INSERT INTO `auction` VALUES ('19785', '6', '20699', '27513', '2', '178', '1291876586', '0', '0', '176', '0');
INSERT INTO `auction` VALUES ('20931', '7', '21881', '9060', '2', '142120', '1291881391', '0', '0', '103747', '0');
INSERT INTO `auction` VALUES ('19786', '6', '20700', '44683', '2', '2806452', '1291840586', '0', '0', '2638064', '0');
INSERT INTO `auction` VALUES ('20894', '7', '21844', '2204', '2', '63221', '1291859791', '0', '0', '55634', '0');
INSERT INTO `auction` VALUES ('19787', '6', '20701', '36170', '2', '1794361', '1291833386', '0', '0', '1650812', '0');
INSERT INTO `auction` VALUES ('20895', '7', '21845', '1679', '2', '570897', '1291856191', '0', '0', '565188', '0');
INSERT INTO `auction` VALUES ('20061', '7', '20975', '9719', '2', '326500', '1291844186', '0', '0', '313440', '0');
INSERT INTO `auction` VALUES ('19059', '2', '19973', '4589', '2', '28810', '1291883726', '0', '0', '25352', '0');
INSERT INTO `auction` VALUES ('20450', '6', '21364', '36265', '2', '2333331', '1291876646', '0', '0', '2123331', '0');
INSERT INTO `auction` VALUES ('19788', '6', '20702', '25463', '2', '9360', '1291829786', '0', '0', '8143', '0');
INSERT INTO `auction` VALUES ('19789', '6', '20703', '2227', '2', '195725', '1291876586', '0', '0', '166366', '0');
INSERT INTO `auction` VALUES ('20475', '7', '21389', '20406', '2', '90277', '1291847846', '0', '0', '80346', '0');
INSERT INTO `auction` VALUES ('20896', '7', '21846', '4388', '2', '9760', '1291845391', '0', '0', '6832', '0');
INSERT INTO `auction` VALUES ('19790', '6', '20704', '39681', '2', '379904', '1291833386', '0', '0', '277329', '0');
INSERT INTO `auction` VALUES ('19742', '6', '20656', '4394', '2', '36720', '1291862186', '0', '0', '36720', '0');
INSERT INTO `auction` VALUES ('20897', '7', '21847', '36042', '2', '832325', '1291838191', '0', '0', '774062', '0');
INSERT INTO `auction` VALUES ('19619', '2', '20533', '2066', '2', '942', '1291865786', '0', '0', '772', '0');
INSERT INTO `auction` VALUES ('19791', '6', '20705', '7754', '2', '125721', '1291854986', '0', '0', '125721', '0');
INSERT INTO `auction` VALUES ('19792', '6', '20706', '10562', '2', '87780', '1291851386', '0', '0', '81635', '0');
INSERT INTO `auction` VALUES ('19793', '6', '20707', '9060', '2', '152800', '1291862186', '0', '0', '134464', '0');
INSERT INTO `auction` VALUES ('19743', '6', '20657', '8303', '2', '1736357', '1291883786', '0', '0', '1562721', '0');
INSERT INTO `auction` VALUES ('20481', '7', '21395', '27516', '2', '14580', '1291829846', '0', '0', '12393', '0');
INSERT INTO `auction` VALUES ('20653', '7', '21567', '6358', '2', '293', '1291887446', '0', '0', '219', '0');
INSERT INTO `auction` VALUES ('19794', '6', '20708', '9719', '2', '422000', '1291869386', '0', '0', '400900', '0');
INSERT INTO `auction` VALUES ('19060', '2', '19974', '25243', '2', '2553187', '1291883726', '0', '0', '2093613', '0');
INSERT INTO `auction` VALUES ('20898', '7', '21848', '832', '2', '10992', '1291830991', '0', '0', '10662', '0');
INSERT INTO `auction` VALUES ('19795', '6', '20709', '37157', '2', '7875', '1291869386', '0', '0', '5670', '0');
INSERT INTO `auction` VALUES ('19006', '2', '19920', '44475', '2', '158', '1291869326', '0', '0', '110', '0');
INSERT INTO `auction` VALUES ('19796', '6', '20710', '11937', '2', '1512', '1291869386', '0', '0', '1103', '0');
INSERT INTO `auction` VALUES ('19007', '2', '19921', '5111', '2', '13989', '1291829726', '0', '0', '12170', '0');
INSERT INTO `auction` VALUES ('19182', '6', '20096', '9719', '2', '383000', '1291847726', '0', '0', '333210', '0');
INSERT INTO `auction` VALUES ('19797', '6', '20711', '22641', '2', '5733', '1291880186', '0', '0', '4586', '0');
INSERT INTO `auction` VALUES ('19798', '6', '20712', '9719', '2', '396250', '1291876586', '0', '0', '352662', '0');
INSERT INTO `auction` VALUES ('19181', '6', '20095', '13001', '2', '635928', '1291847726', '0', '0', '578694', '0');
INSERT INTO `auction` VALUES ('19799', '6', '20713', '36150', '2', '1732617', '1291833386', '0', '0', '1645986', '0');
INSERT INTO `auction` VALUES ('19800', '6', '20714', '9719', '2', '377000', '1291862186', '0', '0', '358150', '0');
INSERT INTO `auction` VALUES ('19041', '2', '19955', '9719', '2', '327250', '1291887326', '0', '0', '284707', '0');
INSERT INTO `auction` VALUES ('19061', '2', '19975', '9719', '2', '426000', '1291854926', '0', '0', '357840', '0');
INSERT INTO `auction` VALUES ('20930', '7', '21880', '5523', '2', '246', '1291877791', '0', '0', '184', '0');
INSERT INTO `auction` VALUES ('20899', '7', '21849', '27513', '2', '152', '1291830991', '0', '0', '124', '0');
INSERT INTO `auction` VALUES ('20712', '2', '21662', '5637', '2', '2670', '1291884991', '0', '0', '2109', '0');
INSERT INTO `auction` VALUES ('20449', '6', '21363', '39681', '2', '99904', '1291855046', '0', '0', '98904', '0');
INSERT INTO `auction` VALUES ('19801', '6', '20715', '5134', '2', '669', '1291865786', '0', '0', '488', '0');
INSERT INTO `auction` VALUES ('19620', '2', '20534', '36584', '2', '6448339', '1291847786', '0', '0', '6319372', '0');
INSERT INTO `auction` VALUES ('19802', '6', '20716', '21595', '2', '1056', '1291872986', '0', '0', '834', '0');
INSERT INTO `auction` VALUES ('20397', '6', '21311', '10561', '2', '94400', '1291876646', '0', '0', '73632', '0');
INSERT INTO `auction` VALUES ('19066', '2', '19980', '31229', '2', '1343818', '1291844126', '0', '0', '1316941', '0');
INSERT INTO `auction` VALUES ('19803', '6', '20717', '5637', '2', '1584', '1291833386', '0', '0', '1124', '0');
INSERT INTO `auction` VALUES ('18979', '2', '19893', '935', '2', '119978', '1291865726', '0', '0', '110379', '0');
INSERT INTO `auction` VALUES ('19804', '6', '20718', '31155', '2', '3910802', '1291854986', '0', '0', '3910802', '0');
INSERT INTO `auction` VALUES ('19805', '6', '20719', '10562', '2', '97740', '1291865786', '0', '0', '86011', '0');
INSERT INTO `auction` VALUES ('20876', '7', '21826', '6358', '2', '440', '1291856191', '0', '0', '356', '0');
INSERT INTO `auction` VALUES ('19806', '6', '20720', '24832', '2', '1967102', '1291844186', '0', '0', '1613023', '0');
INSERT INTO `auction` VALUES ('20409', '6', '21323', '7072', '2', '9552', '1291876646', '0', '0', '7546', '0');
INSERT INTO `auction` VALUES ('20419', '6', '21333', '4359', '2', '85', '1291858646', '0', '0', '79', '0');
INSERT INTO `auction` VALUES ('19807', '6', '20721', '814', '2', '483', '1291872986', '0', '0', '357', '0');
INSERT INTO `auction` VALUES ('19808', '6', '20722', '920', '2', '124423', '1291836986', '0', '0', '107003', '0');
INSERT INTO `auction` VALUES ('19809', '6', '20723', '23909', '2', '56', '1291844186', '0', '0', '42', '0');
INSERT INTO `auction` VALUES ('19810', '6', '20724', '10561', '2', '58560', '1291840586', '0', '0', '49190', '0');
INSERT INTO `auction` VALUES ('19547', '2', '20461', '44505', '2', '11484262', '1291862186', '0', '0', '10450678', '0');
INSERT INTO `auction` VALUES ('20374', '6', '21288', '4589', '2', '10515', '1291876646', '0', '0', '9148', '0');
INSERT INTO `auction` VALUES ('20448', '6', '21362', '4477', '2', '185941', '1291847846', '0', '0', '171065', '0');
INSERT INTO `auction` VALUES ('19811', '6', '20725', '43622', '2', '27420', '1291851386', '0', '0', '23581', '0');
INSERT INTO `auction` VALUES ('20131', '2', '21045', '24936', '2', '2127642', '1291844246', '0', '0', '2042536', '0');
INSERT INTO `auction` VALUES ('19008', '2', '19922', '36609', '2', '5267395', '1291840526', '0', '0', '5214721', '0');
INSERT INTO `auction` VALUES ('19812', '6', '20726', '13912', '2', '738', '1291883786', '0', '0', '723', '0');
INSERT INTO `auction` VALUES ('20900', '7', '21850', '27513', '2', '200', '1291866991', '0', '0', '144', '0');
INSERT INTO `auction` VALUES ('20932', '7', '21882', '14900', '2', '513349', '1291874191', '0', '0', '497948', '0');
INSERT INTO `auction` VALUES ('20614', '7', '21528', '25061', '2', '1181306', '1291887446', '0', '0', '1063175', '0');
INSERT INTO `auction` VALUES ('20725', '2', '21675', '8151', '2', '25300', '1291884991', '0', '0', '19228', '0');
INSERT INTO `auction` VALUES ('20384', '6', '21298', '5523', '2', '405', '1291829846', '0', '0', '400', '0');
INSERT INTO `auction` VALUES ('19217', '6', '20131', '9719', '2', '375500', '1291872926', '0', '0', '330440', '0');
INSERT INTO `auction` VALUES ('20491', '7', '21405', '6292', '2', '77', '1291855046', '0', '0', '66', '0');
INSERT INTO `auction` VALUES ('19009', '2', '19923', '37147', '2', '7455', '1291865726', '0', '0', '5218', '0');
INSERT INTO `auction` VALUES ('20447', '6', '21361', '2823', '2', '105681', '1291837046', '0', '0', '88772', '0');
INSERT INTO `auction` VALUES ('20638', '7', '21552', '4439', '2', '101067', '1291851446', '0', '0', '96013', '0');
INSERT INTO `auction` VALUES ('20003', '7', '20917', '36038', '2', '998226', '1291829786', '0', '0', '928350', '0');
INSERT INTO `auction` VALUES ('20669', '7', '21583', '20653', '2', '1018989', '1291865846', '0', '0', '855950', '0');
INSERT INTO `auction` VALUES ('19964', '7', '20878', '35666', '2', '2449569', '1291883786', '0', '0', '2449569', '0');
INSERT INTO `auction` VALUES ('20004', '7', '20918', '9719', '2', '321000', '1291869386', '0', '0', '253590', '0');
INSERT INTO `auction` VALUES ('20263', '2', '21177', '24780', '2', '992782', '1291876646', '0', '0', '953070', '0');
INSERT INTO `auction` VALUES ('20005', '7', '20919', '5751', '2', '47781', '1291836986', '0', '0', '41569', '0');
INSERT INTO `auction` VALUES ('20264', '2', '21178', '37147', '2', '20070', '1291876646', '0', '0', '14450', '0');
INSERT INTO `auction` VALUES ('20514', '7', '21428', '6180', '2', '24580', '1291844246', '0', '0', '20647', '0');
INSERT INTO `auction` VALUES ('20201', '2', '21115', '36281', '2', '3320289', '1291858646', '0', '0', '3154274', '0');
INSERT INTO `auction` VALUES ('20245', '2', '21159', '5637', '2', '1116', '1291855046', '0', '0', '837', '0');
INSERT INTO `auction` VALUES ('19339', '7', '20253', '1982', '2', '4618878', '1291858526', '0', '0', '3787479', '0');
INSERT INTO `auction` VALUES ('20202', '2', '21116', '36511', '2', '5794277', '1291833446', '0', '0', '5330734', '0');
INSERT INTO `auction` VALUES ('19433', '7', '20347', '13422', '2', '864', '1291880126', '0', '0', '864', '0');
INSERT INTO `auction` VALUES ('19463', '7', '20377', '4402', '2', '4500', '1291872926', '0', '0', '4095', '0');
INSERT INTO `auction` VALUES ('20006', '7', '20920', '756', '2', '339027', '1291833386', '0', '0', '328856', '0');
INSERT INTO `auction` VALUES ('19434', '7', '20348', '1288', '2', '3996', '1291883726', '0', '0', '3676', '0');
INSERT INTO `auction` VALUES ('20639', '7', '21553', '10505', '2', '23850', '1291869446', '0', '0', '19318', '0');
INSERT INTO `auction` VALUES ('20007', '7', '20921', '36164', '2', '2384221', '1291854986', '0', '0', '2336536', '0');
INSERT INTO `auction` VALUES ('20265', '2', '21179', '6359', '2', '523', '1291862246', '0', '0', '444', '0');
INSERT INTO `auction` VALUES ('18936', '2', '19850', '2246', '2', '3616800', '1291887326', '0', '0', '3255120', '0');
INSERT INTO `auction` VALUES ('19464', '7', '20378', '4377', '2', '2424', '1291847726', '0', '0', '1793', '0');
INSERT INTO `auction` VALUES ('20008', '7', '20922', '37158', '2', '1980', '1291872986', '0', '0', '1900', '0');
INSERT INTO `auction` VALUES ('20009', '7', '20923', '9719', '2', '338250', '1291869386', '0', '0', '280747', '0');
INSERT INTO `auction` VALUES ('19435', '7', '20349', '24888', '2', '2342363', '1291829726', '0', '0', '2201821', '0');
INSERT INTO `auction` VALUES ('20266', '2', '21180', '40195', '2', '59760', '1291876646', '0', '0', '44222', '0');
INSERT INTO `auction` VALUES ('19465', '7', '20379', '36158', '2', '1093864', '1291844126', '0', '0', '1028232', '0');
INSERT INTO `auction` VALUES ('20430', '6', '21344', '36372', '2', '3643232', '1291844246', '0', '0', '3388205', '0');
INSERT INTO `auction` VALUES ('20429', '6', '21343', '4611', '2', '3888', '1291858646', '0', '0', '3382', '0');
INSERT INTO `auction` VALUES ('20533', '7', '21447', '36275', '2', '1481094', '1291858646', '0', '0', '1303362', '0');
INSERT INTO `auction` VALUES ('20249', '2', '21163', '13422', '2', '382', '1291865846', '0', '0', '339', '0');
INSERT INTO `auction` VALUES ('19436', '7', '20350', '37749', '2', '8070620', '1291883726', '0', '0', '6052965', '0');
INSERT INTO `auction` VALUES ('20955', '7', '21905', '2254', '2', '27139', '1291859791', '0', '0', '25782', '0');
INSERT INTO `auction` VALUES ('20010', '7', '20924', '9719', '2', '382750', '1291865786', '0', '0', '329165', '0');
INSERT INTO `auction` VALUES ('19599', '2', '20513', '16649', '2', '515', '1291862186', '0', '0', '406', '0');
INSERT INTO `auction` VALUES ('20203', '2', '21117', '4402', '2', '11500', '1291869446', '0', '0', '10810', '0');
INSERT INTO `auction` VALUES ('19725', '6', '20639', '1288', '2', '7918', '1291858586', '0', '0', '7363', '0');
INSERT INTO `auction` VALUES ('18935', '2', '19849', '24724', '2', '732140', '1291869326', '0', '0', '585712', '0');
INSERT INTO `auction` VALUES ('19366', '7', '20280', '1935', '2', '245718', '1291836926', '0', '0', '233432', '0');
INSERT INTO `auction` VALUES ('19437', '7', '20351', '1945', '2', '16136', '1291829726', '0', '0', '13231', '0');
INSERT INTO `auction` VALUES ('19466', '7', '20380', '18612', '2', '392', '1291883726', '0', '0', '321', '0');
INSERT INTO `auction` VALUES ('19340', '7', '20254', '11018', '2', '5779', '1291847726', '0', '0', '5316', '0');
INSERT INTO `auction` VALUES ('19467', '7', '20381', '23334', '2', '172', '1291883726', '0', '0', '120', '0');
INSERT INTO `auction` VALUES ('20011', '7', '20925', '20552', '2', '3660', '1291829786', '0', '0', '3074', '0');
INSERT INTO `auction` VALUES ('20513', '7', '21427', '6887', '2', '3820', '1291862246', '0', '0', '2750', '0');
INSERT INTO `auction` VALUES ('19600', '2', '20514', '9719', '2', '345750', '1291869386', '0', '0', '300802', '0');
INSERT INTO `auction` VALUES ('19438', '7', '20352', '39682', '2', '358560', '1291847726', '0', '0', '322704', '0');
INSERT INTO `auction` VALUES ('20012', '7', '20926', '10560', '2', '24960', '1291865786', '0', '0', '22214', '0');
INSERT INTO `auction` VALUES ('20013', '7', '20927', '31212', '2', '2256671', '1291854986', '0', '0', '2256671', '0');
INSERT INTO `auction` VALUES ('20014', '7', '20928', '10623', '2', '2081323', '1291844186', '0', '0', '2039696', '0');
INSERT INTO `auction` VALUES ('18955', '2', '19869', '1204', '2', '2844333', '1291869326', '0', '0', '2815889', '0');
INSERT INTO `auction` VALUES ('19963', '7', '20877', '36039', '2', '1834106', '1291872986', '0', '0', '1797423', '0');
INSERT INTO `auction` VALUES ('19117', '6', '20031', '4632', '2', '1680', '1291844126', '0', '0', '1680', '0');
INSERT INTO `auction` VALUES ('19468', '7', '20382', '8364', '2', '56762', '1291880126', '0', '0', '50518', '0');
INSERT INTO `auction` VALUES ('20015', '7', '20929', '6555', '2', '1299', '1291887386', '0', '0', '961', '0');
INSERT INTO `auction` VALUES ('18948', '2', '19862', '24476', '2', '9744', '1291887326', '0', '0', '8379', '0');
INSERT INTO `auction` VALUES ('20532', '7', '21446', '20655', '2', '443775', '1291883846', '0', '0', '434899', '0');
INSERT INTO `auction` VALUES ('19118', '6', '20032', '45909', '2', '12672', '1291844126', '0', '0', '10264', '0');
INSERT INTO `auction` VALUES ('20016', '7', '20930', '753', '2', '209795', '1291840586', '0', '0', '167836', '0');
INSERT INTO `auction` VALUES ('20956', '7', '21906', '36458', '2', '4766401', '1291845391', '0', '0', '4051440', '0');
INSERT INTO `auction` VALUES ('20542', '7', '21456', '6359', '2', '288', '1291873046', '0', '0', '201', '0');
INSERT INTO `auction` VALUES ('20204', '2', '21118', '24948', '2', '2007470', '1291862246', '0', '0', '1706349', '0');
INSERT INTO `auction` VALUES ('20670', '7', '21584', '25088', '2', '1019663', '1291847846', '0', '0', '978876', '0');
INSERT INTO `auction` VALUES ('20017', '7', '20931', '9060', '2', '67200', '1291833386', '0', '0', '49728', '0');
INSERT INTO `auction` VALUES ('19439', '7', '20353', '25110', '2', '4707686', '1291887326', '0', '0', '3907379', '0');
INSERT INTO `auction` VALUES ('20606', '7', '21520', '18588', '2', '15752', '1291844246', '0', '0', '15436', '0');
INSERT INTO `auction` VALUES ('20248', '2', '21162', '36063', '2', '1542974', '1291837046', '0', '0', '1357817', '0');
INSERT INTO `auction` VALUES ('20018', '7', '20932', '19441', '2', '39420', '1291844186', '0', '0', '30747', '0');
INSERT INTO `auction` VALUES ('20531', '7', '21445', '31256', '2', '46116', '1291855046', '0', '0', '41504', '0');
INSERT INTO `auction` VALUES ('19322', '7', '20236', '1522', '2', '415613', '1291847726', '0', '0', '386520', '0');
INSERT INTO `auction` VALUES ('20019', '7', '20933', '10560', '2', '23880', '1291840586', '0', '0', '21014', '0');
INSERT INTO `auction` VALUES ('19887', '7', '20801', '39682', '2', '349440', '1291847786', '0', '0', '297024', '0');
INSERT INTO `auction` VALUES ('20607', '7', '21521', '36514', '2', '9085332', '1291883846', '0', '0', '8358505', '0');
INSERT INTO `auction` VALUES ('20608', '7', '21522', '1475', '2', '2389', '1291855046', '0', '0', '2126', '0');
INSERT INTO `auction` VALUES ('19341', '7', '20255', '1169', '2', '2401760', '1291887326', '0', '0', '1993460', '0');
INSERT INTO `auction` VALUES ('18917', '2', '19831', '36159', '2', '2302162', '1291844126', '0', '0', '2071945', '0');
INSERT INTO `auction` VALUES ('19275', '7', '20189', '24291', '2', '793760', '1291829726', '0', '0', '706446', '0');
INSERT INTO `auction` VALUES ('19735', '6', '20649', '36978', '2', '2260367', '1291854986', '0', '0', '2011726', '0');
INSERT INTO `auction` VALUES ('19150', '6', '20064', '36003', '2', '857620', '1291836926', '0', '0', '720400', '0');
INSERT INTO `auction` VALUES ('20020', '7', '20934', '766', '2', '614', '1291876586', '0', '0', '583', '0');
INSERT INTO `auction` VALUES ('20497', '7', '21411', '1461', '2', '230329', '1291880246', '0', '0', '211902', '0');
INSERT INTO `auction` VALUES ('19276', '7', '20190', '36471', '2', '1425156', '1291833326', '0', '0', '1197131', '0');
INSERT INTO `auction` VALUES ('20021', '7', '20935', '6364', '2', '2610', '1291829786', '0', '0', '2166', '0');
INSERT INTO `auction` VALUES ('20554', '7', '21468', '36372', '2', '2405539', '1291876646', '0', '0', '2189040', '0');
INSERT INTO `auction` VALUES ('19440', '7', '20354', '10562', '2', '100800', '1291829726', '0', '0', '94752', '0');
INSERT INTO `auction` VALUES ('19323', '7', '20237', '10629', '2', '577943', '1291887326', '0', '0', '497030', '0');
INSERT INTO `auction` VALUES ('20022', '7', '20936', '44156', '2', '20500', '1291854986', '0', '0', '15375', '0');
INSERT INTO `auction` VALUES ('20023', '7', '20937', '36471', '2', '1844883', '1291858586', '0', '0', '1807985', '0');
INSERT INTO `auction` VALUES ('19441', '7', '20355', '24658', '2', '1399846', '1291883726', '0', '0', '1399846', '0');
INSERT INTO `auction` VALUES ('19302', '7', '20216', '1728', '2', '14649356', '1291851326', '0', '0', '14356368', '0');
INSERT INTO `auction` VALUES ('19736', '6', '20650', '7734', '2', '932799', '1291872986', '0', '0', '746239', '0');
INSERT INTO `auction` VALUES ('20024', '7', '20938', '21562', '2', '346', '1291876586', '0', '0', '273', '0');
INSERT INTO `auction` VALUES ('19737', '6', '20651', '36624', '2', '3522132', '1291851386', '0', '0', '3486910', '0');
INSERT INTO `auction` VALUES ('18947', '2', '19861', '45909', '2', '48096', '1291858526', '0', '0', '41843', '0');
INSERT INTO `auction` VALUES ('19303', '7', '20217', '9719', '2', '337750', '1291833326', '0', '0', '283710', '0');
INSERT INTO `auction` VALUES ('19277', '7', '20191', '32540', '2', '5913710', '1291887326', '0', '0', '5322339', '0');
INSERT INTO `auction` VALUES ('20025', '7', '20939', '17963', '2', '7088', '1291829786', '0', '0', '6804', '0');
INSERT INTO `auction` VALUES ('19119', '6', '20033', '31882', '2', '1435000', '1291883726', '0', '0', '1377600', '0');
INSERT INTO `auction` VALUES ('19738', '6', '20652', '3018', '2', '43656', '1291862186', '0', '0', '35797', '0');
INSERT INTO `auction` VALUES ('19442', '7', '20356', '37145', '2', '4160', '1291872926', '0', '0', '4076', '0');
INSERT INTO `auction` VALUES ('20609', '7', '21523', '31264', '2', '22963', '1291855046', '0', '0', '21355', '0');
INSERT INTO `auction` VALUES ('20512', '7', '21426', '36038', '2', '1186780', '1291837046', '0', '0', '1115573', '0');
INSERT INTO `auction` VALUES ('20026', '7', '20940', '9719', '2', '358250', '1291869386', '0', '0', '322425', '0');
INSERT INTO `auction` VALUES ('20027', '7', '20941', '37771', '2', '2588218', '1291844186', '0', '0', '2199985', '0');
INSERT INTO `auction` VALUES ('20028', '7', '20942', '31268', '2', '62437', '1291844186', '0', '0', '54944', '0');
INSERT INTO `auction` VALUES ('19965', '7', '20879', '9719', '2', '429000', '1291865786', '0', '0', '330330', '0');
INSERT INTO `auction` VALUES ('19443', '7', '20357', '12535', '2', '2371475', '1291833326', '0', '0', '2134327', '0');
INSERT INTO `auction` VALUES ('20029', '7', '20943', '27513', '2', '188', '1291872986', '0', '0', '135', '0');
INSERT INTO `auction` VALUES ('19739', '6', '20653', '9719', '2', '412250', '1291844186', '0', '0', '325677', '0');
INSERT INTO `auction` VALUES ('19469', '7', '20383', '9719', '2', '344500', '1291876526', '0', '0', '279045', '0');
INSERT INTO `auction` VALUES ('20030', '7', '20944', '9719', '2', '383250', '1291869386', '0', '0', '295102', '0');
INSERT INTO `auction` VALUES ('19120', '6', '20034', '31227', '2', '2039853', '1291869326', '0', '0', '1937860', '0');
INSERT INTO `auction` VALUES ('20031', '7', '20945', '2822', '2', '69779', '1291836986', '0', '0', '57218', '0');
INSERT INTO `auction` VALUES ('20032', '7', '20946', '5117', '2', '34650', '1291858586', '0', '0', '28413', '0');
INSERT INTO `auction` VALUES ('19870', '6', '20784', '4394', '2', '52110', '1291851386', '0', '0', '49504', '0');
INSERT INTO `auction` VALUES ('19723', '6', '20637', '36038', '2', '1080908', '1291854986', '0', '0', '951199', '0');
INSERT INTO `auction` VALUES ('20033', '7', '20947', '6579', '2', '7011', '1291836986', '0', '0', '6870', '0');
INSERT INTO `auction` VALUES ('20530', '7', '21444', '10514', '2', '99540', '1291851446', '0', '0', '95558', '0');
INSERT INTO `auction` VALUES ('20511', '7', '21425', '36285', '2', '3172250', '1291844246', '0', '0', '2632967', '0');
INSERT INTO `auction` VALUES ('19871', '6', '20785', '1288', '2', '6660', '1291862186', '0', '0', '6393', '0');
INSERT INTO `auction` VALUES ('19324', '7', '20238', '9719', '2', '403750', '1291887326', '0', '0', '363375', '0');
INSERT INTO `auction` VALUES ('20034', '7', '20948', '1218', '2', '93095', '1291851386', '0', '0', '89371', '0');
INSERT INTO `auction` VALUES ('19872', '6', '20786', '5180', '2', '95434', '1291865786', '0', '0', '95434', '0');
INSERT INTO `auction` VALUES ('20553', '7', '21467', '1314', '2', '18466', '1291844246', '0', '0', '16988', '0');
INSERT INTO `auction` VALUES ('19151', '6', '20065', '8226', '2', '367846', '1291887326', '0', '0', '342096', '0');
INSERT INTO `auction` VALUES ('20035', '7', '20949', '18744', '2', '953525', '1291865786', '0', '0', '896313', '0');
INSERT INTO `auction` VALUES ('20541', '7', '21455', '3076', '2', '39736', '1291887446', '0', '0', '36557', '0');
INSERT INTO `auction` VALUES ('19470', '7', '20384', '25201', '2', '3149769', '1291883726', '0', '0', '2866289', '0');
INSERT INTO `auction` VALUES ('19121', '6', '20035', '13905', '2', '153', '1291851326', '0', '0', '142', '0');
INSERT INTO `auction` VALUES ('19304', '7', '20218', '9719', '2', '420000', '1291887326', '0', '0', '327600', '0');
INSERT INTO `auction` VALUES ('19152', '6', '20066', '14552', '2', '5138471', '1291854926', '0', '0', '4984316', '0');
INSERT INTO `auction` VALUES ('18916', '2', '19830', '25002', '2', '2060709', '1291836926', '0', '0', '2040101', '0');
INSERT INTO `auction` VALUES ('19444', '7', '20358', '5066', '2', '363', '1291854926', '0', '0', '272', '0');
INSERT INTO `auction` VALUES ('19668', '2', '20582', '9249', '2', '81602', '1291844186', '0', '0', '80785', '0');
INSERT INTO `auction` VALUES ('19471', '7', '20385', '3295', '2', '92', '1291862126', '0', '0', '75', '0');
INSERT INTO `auction` VALUES ('20036', '7', '20950', '4611', '2', '4368', '1291847786', '0', '0', '4062', '0');
INSERT INTO `auction` VALUES ('19740', '6', '20654', '45986', '2', '25420', '1291829786', '0', '0', '23640', '0');
INSERT INTO `auction` VALUES ('19445', '7', '20359', '36036', '2', '1601513', '1291876526', '0', '0', '1425346', '0');
INSERT INTO `auction` VALUES ('19472', '7', '20386', '767', '2', '766', '1291836926', '0', '0', '651', '0');
INSERT INTO `auction` VALUES ('20037', '7', '20951', '3280', '2', '297', '1291840586', '0', '0', '237', '0');
INSERT INTO `auction` VALUES ('19873', '6', '20787', '4611', '2', '1336', '1291858586', '0', '0', '1122', '0');
INSERT INTO `auction` VALUES ('19122', '6', '20036', '25088', '2', '1337094', '1291862126', '0', '0', '1083046', '0');
INSERT INTO `auction` VALUES ('19153', '6', '20067', '1315', '2', '1990560', '1291872926', '0', '0', '1652164', '0');
INSERT INTO `auction` VALUES ('20038', '7', '20952', '16646', '2', '495', '1291851386', '0', '0', '440', '0');
INSERT INTO `auction` VALUES ('19367', '7', '20281', '10367', '2', '1210596', '1291844126', '0', '0', '1029006', '0');
INSERT INTO `auction` VALUES ('19368', '7', '20282', '6332', '2', '67471', '1291880126', '0', '0', '62748', '0');
INSERT INTO `auction` VALUES ('20039', '7', '20953', '9719', '2', '417750', '1291840586', '0', '0', '392685', '0');
INSERT INTO `auction` VALUES ('19473', '7', '20387', '5267', '2', '3827420', '1291851326', '0', '0', '3176758', '0');
INSERT INTO `auction` VALUES ('19369', '7', '20283', '31192', '2', '1005013', '1291836926', '0', '0', '924611', '0');
INSERT INTO `auction` VALUES ('20040', '7', '20954', '15313', '2', '5426', '1291876586', '0', '0', '4178', '0');
INSERT INTO `auction` VALUES ('19474', '7', '20388', '24711', '2', '2039804', '1291872926', '0', '0', '1999007', '0');
INSERT INTO `auction` VALUES ('20247', '2', '21161', '40199', '2', '4224', '1291869446', '0', '0', '3590', '0');
INSERT INTO `auction` VALUES ('20041', '7', '20955', '10571', '2', '757787', '1291862186', '0', '0', '575918', '0');
INSERT INTO `auction` VALUES ('20042', '7', '20956', '24665', '2', '947896', '1291883786', '0', '0', '796232', '0');
INSERT INTO `auction` VALUES ('19874', '6', '20788', '36553', '2', '7449165', '1291847786', '0', '0', '6406281', '0');
INSERT INTO `auction` VALUES ('20043', '7', '20957', '9719', '2', '340250', '1291887386', '0', '0', '261992', '0');
INSERT INTO `auction` VALUES ('20044', '7', '20958', '9397', '2', '318799', '1291880186', '0', '0', '309235', '0');
INSERT INTO `auction` VALUES ('19154', '6', '20068', '11415', '2', '53760', '1291851326', '0', '0', '44620', '0');
INSERT INTO `auction` VALUES ('20045', '7', '20959', '9719', '2', '316750', '1291836986', '0', '0', '262902', '0');
INSERT INTO `auction` VALUES ('19278', '7', '20192', '9719', '2', '362250', '1291833326', '0', '0', '340515', '0');
INSERT INTO `auction` VALUES ('20046', '7', '20960', '9719', '2', '392000', '1291844186', '0', '0', '333200', '0');
INSERT INTO `auction` VALUES ('19741', '6', '20655', '10559', '2', '112860', '1291844186', '0', '0', '111731', '0');
INSERT INTO `auction` VALUES ('19155', '6', '20069', '8151', '2', '21000', '1291854926', '0', '0', '15120', '0');
INSERT INTO `auction` VALUES ('20047', '7', '20961', '14982', '2', '1834766', '1291865786', '0', '0', '1761375', '0');
INSERT INTO `auction` VALUES ('20048', '7', '20962', '10562', '2', '37380', '1291844186', '0', '0', '28408', '0');
INSERT INTO `auction` VALUES ('19279', '7', '20193', '25144', '2', '3520677', '1291854926', '0', '0', '3309436', '0');
INSERT INTO `auction` VALUES ('20049', '7', '20963', '5425', '2', '34095', '1291854986', '0', '0', '31367', '0');
INSERT INTO `auction` VALUES ('20082', '2', '20996', '24603', '2', '869637', '1291880246', '0', '0', '739191', '0');
INSERT INTO `auction` VALUES ('19179', '6', '20093', '4377', '2', '10692', '1291858526', '0', '0', '8553', '0');
INSERT INTO `auction` VALUES ('20552', '7', '21466', '7072', '2', '5160', '1291858646', '0', '0', '4231', '0');
INSERT INTO `auction` VALUES ('20551', '7', '21465', '10141', '2', '827827', '1291844246', '0', '0', '811270', '0');
INSERT INTO `auction` VALUES ('20105', '2', '21019', '36267', '2', '1305547', '1291833446', '0', '0', '1122770', '0');
INSERT INTO `auction` VALUES ('19180', '6', '20094', '44165', '2', '81700', '1291862126', '0', '0', '62909', '0');
INSERT INTO `auction` VALUES ('20104', '2', '21018', '36036', '2', '1637536', '1291873046', '0', '0', '1555659', '0');
INSERT INTO `auction` VALUES ('20050', '7', '20964', '9719', '2', '411500', '1291840586', '0', '0', '320970', '0');
INSERT INTO `auction` VALUES ('19886', '7', '20800', '44687', '2', '2623549', '1291833386', '0', '0', '2387429', '0');
INSERT INTO `auction` VALUES ('19370', '7', '20284', '13422', '2', '152', '1291865726', '0', '0', '110', '0');
INSERT INTO `auction` VALUES ('19722', '6', '20636', '13901', '2', '157', '1291847786', '0', '0', '139', '0');
INSERT INTO `auction` VALUES ('19524', '2', '20438', '22279', '2', '17', '1291880186', '0', '0', '17', '0');
INSERT INTO `auction` VALUES ('19030', '2', '19944', '8366', '2', '628', '1291844126', '0', '0', '590', '0');
INSERT INTO `auction` VALUES ('20051', '7', '20965', '9719', '2', '350750', '1291887386', '0', '0', '298137', '0');
INSERT INTO `auction` VALUES ('20919', '7', '21869', '3164', '2', '2224', '1291859791', '0', '0', '1645', '0');
INSERT INTO `auction` VALUES ('19632', '2', '20546', '10402', '2', '18239', '1291829786', '0', '0', '16050', '0');
INSERT INTO `auction` VALUES ('19269', '6', '20183', '36055', '2', '2296920', '1291872926', '0', '0', '1975351', '0');
INSERT INTO `auction` VALUES ('20468', '6', '21382', '1936', '2', '68845', '1291829846', '0', '0', '62648', '0');
INSERT INTO `auction` VALUES ('19270', '6', '20184', '27513', '2', '145', '1291869326', '0', '0', '143', '0');
INSERT INTO `auction` VALUES ('19271', '6', '20185', '24368', '2', '539280', '1291854926', '0', '0', '452995', '0');
INSERT INTO `auction` VALUES ('18988', '2', '19902', '36272', '2', '2679753', '1291880126', '0', '0', '2572562', '0');
INSERT INTO `auction` VALUES ('19633', '2', '20547', '27516', '2', '17500', '1291840586', '0', '0', '12775', '0');
INSERT INTO `auction` VALUES ('19070', '2', '19984', '35664', '2', '8330869', '1291836926', '0', '0', '8330869', '0');
INSERT INTO `auction` VALUES ('19393', '7', '20307', '9719', '2', '407500', '1291854926', '0', '0', '374900', '0');
INSERT INTO `auction` VALUES ('19272', '6', '20186', '9719', '2', '429250', '1291836926', '0', '0', '377740', '0');
INSERT INTO `auction` VALUES ('20382', '6', '21296', '2015', '2', '289957', '1291840646', '0', '0', '260961', '0');
INSERT INTO `auction` VALUES ('19273', '6', '20187', '9719', '2', '380250', '1291829726', '0', '0', '292792', '0');
INSERT INTO `auction` VALUES ('19274', '6', '20188', '9719', '2', '391250', '1291829726', '0', '0', '301262', '0');
INSERT INTO `auction` VALUES ('20267', '2', '21181', '21882', '2', '20400', '1291873046', '0', '0', '14892', '0');
INSERT INTO `auction` VALUES ('20920', '7', '21870', '36781', '2', '18840', '1291866991', '0', '0', '17898', '0');
INSERT INTO `auction` VALUES ('19014', '2', '19928', '45909', '2', '40704', '1291858526', '0', '0', '39889', '0');
INSERT INTO `auction` VALUES ('20469', '6', '21383', '36470', '2', '2113710', '1291829846', '0', '0', '2029161', '0');
INSERT INTO `auction` VALUES ('20470', '6', '21384', '15687', '2', '1130418', '1291883846', '0', '0', '972159', '0');
INSERT INTO `auction` VALUES ('20268', '2', '21182', '24939', '2', '2078128', '1291887446', '0', '0', '1911877', '0');
INSERT INTO `auction` VALUES ('19634', '2', '20548', '25144', '2', '3005527', '1291862186', '0', '0', '2524642', '0');
INSERT INTO `auction` VALUES ('20269', '2', '21183', '4377', '2', '8526', '1291858646', '0', '0', '8355', '0');
INSERT INTO `auction` VALUES ('18989', '2', '19903', '36609', '2', '6131325', '1291833326', '0', '0', '5150313', '0');
INSERT INTO `auction` VALUES ('19586', '2', '20500', '6355', '2', '6', '1291858586', '0', '0', '5', '0');
INSERT INTO `auction` VALUES ('19459', '7', '20373', '9719', '2', '343250', '1291836926', '0', '0', '343250', '0');
INSERT INTO `auction` VALUES ('20270', '2', '21184', '24710', '2', '1054313', '1291862246', '0', '0', '853993', '0');
INSERT INTO `auction` VALUES ('20271', '2', '21185', '4402', '2', '3680', '1291840646', '0', '0', '3164', '0');
INSERT INTO `auction` VALUES ('20272', '2', '21186', '8152', '2', '60000', '1291851446', '0', '0', '44400', '0');
INSERT INTO `auction` VALUES ('20176', '2', '21090', '10559', '2', '44640', '1291880246', '0', '0', '37051', '0');
INSERT INTO `auction` VALUES ('20273', '2', '21187', '36429', '2', '1429944', '1291858646', '0', '0', '1201152', '0');
INSERT INTO `auction` VALUES ('20274', '2', '21188', '865', '2', '251742', '1291855046', '0', '0', '211463', '0');
INSERT INTO `auction` VALUES ('18990', '2', '19904', '2039', '2', '50130', '1291858526', '0', '0', '46119', '0');
INSERT INTO `auction` VALUES ('20275', '6', '21189', '39682', '2', '199680', '1291862246', '0', '0', '143769', '0');
INSERT INTO `auction` VALUES ('20276', '6', '21190', '36387', '2', '2606694', '1291855046', '0', '0', '2398158', '0');
INSERT INTO `auction` VALUES ('20471', '6', '21385', '4634', '2', '3255', '1291876646', '0', '0', '2701', '0');
INSERT INTO `auction` VALUES ('19635', '2', '20549', '814', '2', '2728', '1291854986', '0', '0', '2509', '0');
INSERT INTO `auction` VALUES ('19015', '2', '19929', '2725', '2', '8865', '1291840526', '0', '0', '7535', '0');
INSERT INTO `auction` VALUES ('19016', '2', '19930', '20545', '2', '9320', '1291844126', '0', '0', '7362', '0');
INSERT INTO `auction` VALUES ('20277', '6', '21191', '44475', '2', '143', '1291869446', '0', '0', '115', '0');
INSERT INTO `auction` VALUES ('19483', '2', '20397', '8224', '2', '359822', '1291862186', '0', '0', '356223', '0');
INSERT INTO `auction` VALUES ('19050', '2', '19964', '16671', '2', '943350', '1291840526', '0', '0', '792414', '0');
INSERT INTO `auction` VALUES ('20921', '7', '21871', '44475', '2', '120', '1291845391', '0', '0', '120', '0');
INSERT INTO `auction` VALUES ('19392', '7', '20306', '25068', '2', '1407140', '1291847726', '0', '0', '1238283', '0');
INSERT INTO `auction` VALUES ('19710', '6', '20624', '3263', '2', '49', '1291840586', '0', '0', '38', '0');
INSERT INTO `auction` VALUES ('19484', '2', '20398', '20541', '2', '75960', '1291854986', '0', '0', '53172', '0');
INSERT INTO `auction` VALUES ('19458', '7', '20372', '4611', '2', '5038', '1291880126', '0', '0', '4634', '0');
INSERT INTO `auction` VALUES ('19485', '2', '20399', '4402', '2', '1870', '1291858586', '0', '0', '1626', '0');
INSERT INTO `auction` VALUES ('19766', '6', '20680', '25327', '2', '3377090', '1291844186', '0', '0', '3174464', '0');
INSERT INTO `auction` VALUES ('18991', '2', '19905', '1489', '2', '121879', '1291865726', '0', '0', '93846', '0');
INSERT INTO `auction` VALUES ('19071', '2', '19985', '24666', '2', '1948118', '1291876526', '0', '0', '1597456', '0');
INSERT INTO `auction` VALUES ('20922', '7', '21872', '18674', '2', '918866', '1291863391', '0', '0', '762658', '0');
INSERT INTO `auction` VALUES ('19486', '2', '20400', '18712', '2', '790914', '1291829786', '0', '0', '593185', '0');
INSERT INTO `auction` VALUES ('19031', '2', '19945', '36527', '2', '7631948', '1291869326', '0', '0', '6410836', '0');
INSERT INTO `auction` VALUES ('19487', '2', '20401', '31940', '2', '1372116', '1291833386', '0', '0', '1358394', '0');
INSERT INTO `auction` VALUES ('20052', '7', '20966', '25214', '2', '3759703', '1291844186', '0', '0', '3571717', '0');
INSERT INTO `auction` VALUES ('19051', '2', '19965', '5759', '2', '12960', '1291872926', '0', '0', '10627', '0');
INSERT INTO `auction` VALUES ('19636', '2', '20550', '6458', '2', '94', '1291840586', '0', '0', '73', '0');
INSERT INTO `auction` VALUES ('19765', '6', '20679', '9719', '2', '362000', '1291862186', '0', '0', '318560', '0');
INSERT INTO `auction` VALUES ('19488', '2', '20402', '31183', '2', '2489044', '1291869386', '0', '0', '2389482', '0');
INSERT INTO `auction` VALUES ('19661', '2', '20575', '9719', '2', '411000', '1291887386', '0', '0', '312360', '0');
INSERT INTO `auction` VALUES ('19637', '2', '20551', '10505', '2', '32850', '1291829786', '0', '0', '23652', '0');
INSERT INTO `auction` VALUES ('19638', '2', '20552', '9719', '2', '437500', '1291844186', '0', '0', '376250', '0');
INSERT INTO `auction` VALUES ('19395', '7', '20309', '9719', '2', '383750', '1291858526', '0', '0', '379912', '0');
INSERT INTO `auction` VALUES ('19457', '7', '20371', '31183', '2', '2196495', '1291854926', '0', '0', '2174530', '0');
INSERT INTO `auction` VALUES ('19639', '2', '20553', '30809', '2', '86376', '1291851386', '0', '0', '78602', '0');
INSERT INTO `auction` VALUES ('20472', '6', '21386', '45909', '2', '2928', '1291855046', '0', '0', '2723', '0');
INSERT INTO `auction` VALUES ('19052', '2', '19966', '31224', '2', '1332984', '1291872926', '0', '0', '1173025', '0');
INSERT INTO `auction` VALUES ('20923', '7', '21873', '18672', '2', '737054', '1291863391', '0', '0', '626495', '0');
INSERT INTO `auction` VALUES ('19489', '2', '20403', '39681', '2', '287056', '1291847786', '0', '0', '212421', '0');
INSERT INTO `auction` VALUES ('18992', '2', '19906', '31191', '2', '1399744', '1291876526', '0', '0', '1231774', '0');
INSERT INTO `auction` VALUES ('20066', '7', '20980', '9719', '2', '340750', '1291854986', '0', '0', '293045', '0');
INSERT INTO `auction` VALUES ('19490', '2', '20404', '1486', '2', '90014', '1291836986', '0', '0', '72011', '0');
INSERT INTO `auction` VALUES ('20924', '7', '21874', '7973', '2', '3683', '1291888591', '0', '0', '2983', '0');
INSERT INTO `auction` VALUES ('19491', '2', '20405', '9061', '2', '10640', '1291854986', '0', '0', '7980', '0');
INSERT INTO `auction` VALUES ('18993', '2', '19907', '12238', '2', '121', '1291847726', '0', '0', '107', '0');
INSERT INTO `auction` VALUES ('19724', '6', '20638', '9719', '2', '368250', '1291876586', '0', '0', '283552', '0');
INSERT INTO `auction` VALUES ('20065', '7', '20979', '27513', '2', '193', '1291880186', '0', '0', '148', '0');
INSERT INTO `auction` VALUES ('19587', '2', '20501', '9719', '2', '418000', '1291865786', '0', '0', '363660', '0');
INSERT INTO `auction` VALUES ('20064', '7', '20978', '1475', '2', '801', '1291869386', '0', '0', '688', '0');
INSERT INTO `auction` VALUES ('20925', '7', '21875', '6359', '2', '680', '1291884991', '0', '0', '496', '0');
INSERT INTO `auction` VALUES ('19588', '2', '20502', '2546', '2', '531', '1291833386', '0', '0', '440', '0');
INSERT INTO `auction` VALUES ('19662', '2', '20576', '13884', '2', '528', '1291865786', '0', '0', '464', '0');
INSERT INTO `auction` VALUES ('19072', '2', '19986', '4723', '2', '79217', '1291880126', '0', '0', '74463', '0');
INSERT INTO `auction` VALUES ('20063', '7', '20977', '2274', '2', '12574', '1291880186', '0', '0', '10813', '0');
INSERT INTO `auction` VALUES ('19053', '2', '19967', '4611', '2', '5738', '1291854926', '0', '0', '4131', '0');
INSERT INTO `auction` VALUES ('19492', '2', '20406', '6299', '2', '897', '1291865786', '0', '0', '888', '0');
INSERT INTO `auction` VALUES ('19493', '2', '20407', '31219', '2', '1922896', '1291847786', '0', '0', '1538316', '0');
INSERT INTO `auction` VALUES ('19494', '2', '20408', '44700', '2', '4375', '1291880186', '0', '0', '3806', '0');
INSERT INTO `auction` VALUES ('19495', '2', '20409', '10574', '2', '251279', '1291836986', '0', '0', '211074', '0');
INSERT INTO `auction` VALUES ('19496', '2', '20410', '37755', '2', '3691231', '1291840586', '0', '0', '3395932', '0');
INSERT INTO `auction` VALUES ('20106', '2', '21020', '9719', '2', '432000', '1291869446', '0', '0', '414720', '0');
INSERT INTO `auction` VALUES ('19497', '2', '20411', '9719', '2', '314750', '1291880186', '0', '0', '245505', '0');
INSERT INTO `auction` VALUES ('19498', '2', '20412', '25152', '2', '3931257', '1291880186', '0', '0', '3656069', '0');
INSERT INTO `auction` VALUES ('19499', '2', '20413', '2327', '2', '278', '1291844186', '0', '0', '211', '0');
INSERT INTO `auction` VALUES ('19500', '2', '20414', '1288', '2', '5712', '1291829786', '0', '0', '4398', '0');
INSERT INTO `auction` VALUES ('20174', '2', '21088', '40195', '2', '49950', '1291862246', '0', '0', '45954', '0');
INSERT INTO `auction` VALUES ('20172', '2', '21086', '37159', '2', '20900', '1291869446', '0', '0', '19855', '0');
INSERT INTO `auction` VALUES ('19869', '6', '20783', '4611', '2', '6084', '1291854986', '0', '0', '5962', '0');
INSERT INTO `auction` VALUES ('19394', '7', '20308', '20677', '2', '32000', '1291865726', '0', '0', '29440', '0');
INSERT INTO `auction` VALUES ('20926', '7', '21876', '24717', '2', '759431', '1291874191', '0', '0', '706270', '0');
INSERT INTO `auction` VALUES ('19589', '2', '20503', '10628', '2', '2288436', '1291883786', '0', '0', '2013823', '0');
INSERT INTO `auction` VALUES ('19501', '2', '20415', '18512', '2', '144000', '1291876586', '0', '0', '119520', '0');
INSERT INTO `auction` VALUES ('20107', '2', '21021', '37145', '2', '2790', '1291865846', '0', '0', '2008', '0');
INSERT INTO `auction` VALUES ('19502', '2', '20416', '10505', '2', '22960', '1291880186', '0', '0', '22271', '0');
INSERT INTO `auction` VALUES ('19663', '2', '20577', '36043', '2', '1400049', '1291887386', '0', '0', '1400049', '0');
INSERT INTO `auction` VALUES ('20927', '7', '21877', '36044', '2', '1273043', '1291888591', '0', '0', '1273043', '0');
INSERT INTO `auction` VALUES ('20108', '2', '21022', '1288', '2', '3596', '1291833446', '0', '0', '2625', '0');
INSERT INTO `auction` VALUES ('19590', '2', '20504', '9406', '2', '262168', '1291883786', '0', '0', '222842', '0');
INSERT INTO `auction` VALUES ('19054', '2', '19968', '36456', '2', '3360902', '1291883726', '0', '0', '2957593', '0');
INSERT INTO `auction` VALUES ('19664', '2', '20578', '10562', '2', '59730', '1291865786', '0', '0', '56146', '0');
INSERT INTO `auction` VALUES ('20719', '2', '21669', '24712', '2', '799868', '1291841791', '0', '0', '711882', '0');
INSERT INTO `auction` VALUES ('19503', '2', '20417', '18612', '2', '421', '1291862186', '0', '0', '324', '0');
INSERT INTO `auction` VALUES ('19504', '2', '20418', '24611', '2', '958115', '1291844186', '0', '0', '891046', '0');
INSERT INTO `auction` VALUES ('20473', '6', '21387', '35971', '2', '1175163', '1291887446', '0', '0', '1163411', '0');
INSERT INTO `auction` VALUES ('20109', '2', '21023', '1659', '2', '88668', '1291851446', '0', '0', '79801', '0');
INSERT INTO `auction` VALUES ('20474', '6', '21388', '1933', '2', '57563', '1291862246', '0', '0', '54684', '0');
INSERT INTO `auction` VALUES ('20928', '7', '21878', '1925', '2', '36199', '1291881391', '0', '0', '34389', '0');
INSERT INTO `auction` VALUES ('18994', '2', '19908', '8106', '2', '436863', '1291876526', '0', '0', '384439', '0');
INSERT INTO `auction` VALUES ('19505', '2', '20419', '9719', '2', '377500', '1291844186', '0', '0', '286900', '0');
INSERT INTO `auction` VALUES ('19506', '2', '20420', '23386', '2', '259', '1291872986', '0', '0', '240', '0');
INSERT INTO `auction` VALUES ('19665', '2', '20579', '4785', '2', '27459', '1291851386', '0', '0', '22241', '0');
INSERT INTO `auction` VALUES ('18995', '2', '19909', '5524', '2', '1938', '1291880126', '0', '0', '1860', '0');
INSERT INTO `auction` VALUES ('19507', '2', '20421', '31164', '2', '1683914', '1291880186', '0', '0', '1448166', '0');
INSERT INTO `auction` VALUES ('20110', '2', '21024', '20693', '2', '784431', '1291829846', '0', '0', '705987', '0');
INSERT INTO `auction` VALUES ('19553', '2', '20467', '9719', '2', '381750', '1291854986', '0', '0', '377932', '0');
INSERT INTO `auction` VALUES ('20867', '7', '21817', '37147', '2', '23370', '1291859791', '0', '0', '17994', '0');
INSERT INTO `auction` VALUES ('20111', '2', '21025', '9719', '2', '397250', '1291844246', '0', '0', '329717', '0');
INSERT INTO `auction` VALUES ('19508', '2', '20422', '1401', '2', '249', '1291887386', '0', '0', '174', '0');
INSERT INTO `auction` VALUES ('20112', '2', '21026', '25001', '2', '1481845', '1291876646', '0', '0', '1333660', '0');
INSERT INTO `auction` VALUES ('19509', '2', '20423', '16714', '2', '887967', '1291847786', '0', '0', '683734', '0');
INSERT INTO `auction` VALUES ('20868', '7', '21818', '1624', '2', '258932', '1291856191', '0', '0', '212324', '0');
INSERT INTO `auction` VALUES ('20175', '2', '21089', '1215', '2', '23164', '1291880246', '0', '0', '22237', '0');
INSERT INTO `auction` VALUES ('19510', '2', '20424', '4481', '2', '11449', '1291862186', '0', '0', '9273', '0');
INSERT INTO `auction` VALUES ('19511', '2', '20425', '9719', '2', '406000', '1291851386', '0', '0', '316680', '0');
INSERT INTO `auction` VALUES ('19770', '6', '20684', '37158', '2', '15675', '1291851386', '0', '0', '14577', '0');
INSERT INTO `auction` VALUES ('19512', '2', '20426', '36458', '2', '4425944', '1291883786', '0', '0', '3939090', '0');
INSERT INTO `auction` VALUES ('20631', '7', '21545', '27516', '2', '16100', '1291887446', '0', '0', '12236', '0');
INSERT INTO `auction` VALUES ('19513', '2', '20427', '6292', '2', '60', '1291836986', '0', '0', '46', '0');
INSERT INTO `auction` VALUES ('19514', '2', '20428', '9719', '2', '340000', '1291833386', '0', '0', '340000', '0');
INSERT INTO `auction` VALUES ('20720', '2', '21670', '8350', '2', '42171', '1291834591', '0', '0', '41749', '0');
INSERT INTO `auction` VALUES ('20869', '7', '21819', '36385', '2', '2988705', '1291830991', '0', '0', '2988705', '0');
INSERT INTO `auction` VALUES ('20632', '7', '21546', '36273', '2', '2002211', '1291887446', '0', '0', '1681857', '0');
INSERT INTO `auction` VALUES ('19515', '2', '20429', '1355', '2', '8537', '1291847786', '0', '0', '7427', '0');
INSERT INTO `auction` VALUES ('20690', '2', '21640', '5635', '2', '273', '1291866991', '0', '0', '226', '0');
INSERT INTO `auction` VALUES ('20455', '6', '21369', '19943', '2', '222880', '1291829846', '0', '0', '205049', '0');
INSERT INTO `auction` VALUES ('19516', '2', '20430', '36166', '2', '1872016', '1291887386', '0', '0', '1684814', '0');
INSERT INTO `auction` VALUES ('20870', '7', '21820', '20659', '2', '830259', '1291848991', '0', '0', '730627', '0');
INSERT INTO `auction` VALUES ('19517', '2', '20431', '30809', '2', '109440', '1291880186', '0', '0', '100684', '0');
INSERT INTO `auction` VALUES ('19518', '2', '20432', '9755', '2', '695', '1291829786', '0', '0', '653', '0');
INSERT INTO `auction` VALUES ('20113', '2', '21027', '19441', '2', '11940', '1291858646', '0', '0', '10746', '0');
INSERT INTO `auction` VALUES ('19456', '7', '20370', '44156', '2', '11250', '1291840526', '0', '0', '8325', '0');
INSERT INTO `auction` VALUES ('20441', '6', '21355', '10562', '2', '49680', '1291844246', '0', '0', '47692', '0');
INSERT INTO `auction` VALUES ('19519', '2', '20433', '36486', '2', '6796006', '1291836986', '0', '0', '6184365', '0');
INSERT INTO `auction` VALUES ('20173', '2', '21087', '35963', '2', '782722', '1291880246', '0', '0', '673140', '0');
INSERT INTO `auction` VALUES ('19520', '2', '20434', '814', '2', '1936', '1291876586', '0', '0', '1877', '0');
INSERT INTO `auction` VALUES ('19544', '2', '20458', '2898', '2', '353', '1291829786', '0', '0', '303', '0');
INSERT INTO `auction` VALUES ('19521', '2', '20435', '9719', '2', '321750', '1291836986', '0', '0', '308880', '0');
INSERT INTO `auction` VALUES ('20414', '6', '21328', '9061', '2', '4040', '1291883846', '0', '0', '3353', '0');
INSERT INTO `auction` VALUES ('19522', '2', '20436', '9719', '2', '378750', '1291836986', '0', '0', '378750', '0');
INSERT INTO `auction` VALUES ('19523', '2', '20437', '31200', '2', '3533781', '1291869386', '0', '0', '3074389', '0');
INSERT INTO `auction` VALUES ('19674', '2', '20588', '9719', '2', '378500', '1291869386', '0', '0', '306585', '0');
INSERT INTO `auction` VALUES ('20114', '2', '21028', '13422', '2', '1368', '1291833446', '0', '0', '1231', '0');
INSERT INTO `auction` VALUES ('19949', '7', '20863', '25201', '2', '3431748', '1291883786', '0', '0', '2814033', '0');
INSERT INTO `auction` VALUES ('19024', '2', '19938', '18588', '2', '11232', '1291833326', '0', '0', '10895', '0');
INSERT INTO `auction` VALUES ('19198', '6', '20112', '9719', '2', '414250', '1291887326', '0', '0', '323115', '0');
INSERT INTO `auction` VALUES ('19652', '2', '20566', '5637', '2', '2355', '1291858586', '0', '0', '1907', '0');
INSERT INTO `auction` VALUES ('19062', '2', '19976', '45909', '2', '14464', '1291833326', '0', '0', '12005', '0');
INSERT INTO `auction` VALUES ('19042', '2', '19956', '13003', '2', '3132334', '1291844126', '0', '0', '2411897', '0');
INSERT INTO `auction` VALUES ('19693', '6', '20607', '39970', '2', '60000', '1291858586', '0', '0', '51000', '0');
INSERT INTO `auction` VALUES ('19043', '2', '19957', '816', '2', '13049', '1291851326', '0', '0', '12266', '0');
INSERT INTO `auction` VALUES ('19010', '2', '19924', '35652', '2', '6649827', '1291844126', '0', '0', '6117840', '0');
INSERT INTO `auction` VALUES ('19621', '2', '20535', '24606', '2', '966666', '1291836986', '0', '0', '860332', '0');
INSERT INTO `auction` VALUES ('19653', '2', '20567', '36414', '2', '1616344', '1291854986', '0', '0', '1309238', '0');
INSERT INTO `auction` VALUES ('20903', '7', '21853', '25334', '2', '6359896', '1291856191', '0', '0', '6232698', '0');
INSERT INTO `auction` VALUES ('20904', '7', '21854', '6359', '2', '704', '1291834591', '0', '0', '563', '0');
INSERT INTO `auction` VALUES ('19044', '2', '19958', '31168', '2', '2898779', '1291872926', '0', '0', '2434974', '0');
INSERT INTO `auction` VALUES ('19622', '2', '20536', '9719', '2', '398500', '1291844186', '0', '0', '398500', '0');
INSERT INTO `auction` VALUES ('19045', '2', '19959', '9393', '2', '475472', '1291829726', '0', '0', '385132', '0');
INSERT INTO `auction` VALUES ('19654', '2', '20568', '36062', '2', '1040037', '1291880186', '0', '0', '832029', '0');
INSERT INTO `auction` VALUES ('20905', '7', '21855', '12804', '2', '59200', '1291874191', '0', '0', '42624', '0');
INSERT INTO `auction` VALUES ('20906', '7', '21856', '44700', '2', '5675', '1291874191', '0', '0', '3972', '0');
INSERT INTO `auction` VALUES ('19623', '2', '20537', '9719', '2', '328500', '1291833386', '0', '0', '262800', '0');
INSERT INTO `auction` VALUES ('19454', '7', '20368', '1944', '2', '14876', '1291872926', '0', '0', '14429', '0');
INSERT INTO `auction` VALUES ('19011', '2', '19925', '31177', '2', '1723749', '1291862126', '0', '0', '1499661', '0');
INSERT INTO `auction` VALUES ('19624', '2', '20538', '13755', '2', '3998', '1291836986', '0', '0', '2838', '0');
INSERT INTO `auction` VALUES ('19196', '6', '20110', '2284', '2', '11235', '1291880126', '0', '0', '11010', '0');
INSERT INTO `auction` VALUES ('19449', '7', '20363', '24604', '2', '814898', '1291840526', '0', '0', '676365', '0');
INSERT INTO `auction` VALUES ('19063', '2', '19977', '9719', '2', '329750', '1291883726', '0', '0', '260502', '0');
INSERT INTO `auction` VALUES ('20060', '7', '20974', '44732', '2', '3202666', '1291880186', '0', '0', '3106586', '0');
INSERT INTO `auction` VALUES ('20907', '7', '21857', '39682', '2', '87840', '1291888591', '0', '0', '79056', '0');
INSERT INTO `auction` VALUES ('19064', '2', '19978', '9060', '2', '183160', '1291862126', '0', '0', '177665', '0');
INSERT INTO `auction` VALUES ('18983', '2', '19897', '36152', '2', '3008776', '1291829726', '0', '0', '2948600', '0');
INSERT INTO `auction` VALUES ('19625', '2', '20539', '13883', '2', '597', '1291869386', '0', '0', '585', '0');
INSERT INTO `auction` VALUES ('19046', '2', '19960', '1440', '2', '77146', '1291836926', '0', '0', '65574', '0');
INSERT INTO `auction` VALUES ('20908', '7', '21858', '27515', '2', '4980', '1291845391', '0', '0', '3585', '0');
INSERT INTO `auction` VALUES ('19012', '2', '19926', '28493', '2', '2747541', '1291880126', '0', '0', '2747541', '0');
INSERT INTO `auction` VALUES ('19195', '6', '20109', '5971', '2', '46813', '1291847726', '0', '0', '39791', '0');
INSERT INTO `auction` VALUES ('20059', '7', '20973', '31238', '2', '2120624', '1291887386', '0', '0', '2014592', '0');
INSERT INTO `auction` VALUES ('18984', '2', '19898', '9719', '2', '381000', '1291840526', '0', '0', '342900', '0');
INSERT INTO `auction` VALUES ('19655', '2', '20569', '6299', '2', '481', '1291858586', '0', '0', '442', '0');
INSERT INTO `auction` VALUES ('19025', '2', '19939', '25032', '2', '729408', '1291854926', '0', '0', '692937', '0');
INSERT INTO `auction` VALUES ('19626', '2', '20540', '36383', '2', '2773268', '1291883786', '0', '0', '2329545', '0');
INSERT INTO `auction` VALUES ('19013', '2', '19927', '4481', '2', '5393', '1291883726', '0', '0', '5123', '0');
INSERT INTO `auction` VALUES ('19627', '2', '20541', '9719', '2', '383000', '1291887386', '0', '0', '363850', '0');
INSERT INTO `auction` VALUES ('19695', '6', '20609', '8246', '2', '360232', '1291858586', '0', '0', '309799', '0');
INSERT INTO `auction` VALUES ('20909', '7', '21859', '4394', '2', '18480', '1291838191', '0', '0', '18110', '0');
INSERT INTO `auction` VALUES ('19656', '2', '20570', '16654', '2', '597', '1291876586', '0', '0', '423', '0');
INSERT INTO `auction` VALUES ('19758', '6', '20672', '14157', '2', '5338', '1291833386', '0', '0', '4750', '0');
INSERT INTO `auction` VALUES ('19026', '2', '19940', '44700', '2', '4525', '1291865726', '0', '0', '4072', '0');
INSERT INTO `auction` VALUES ('19075', '6', '19989', '9719', '2', '412750', '1291858526', '0', '0', '317817', '0');
INSERT INTO `auction` VALUES ('19076', '6', '19990', '13880', '2', '364', '1291854926', '0', '0', '291', '0');
INSERT INTO `auction` VALUES ('19077', '6', '19991', '20676', '2', '8520', '1291869326', '0', '0', '8434', '0');
INSERT INTO `auction` VALUES ('19078', '6', '19992', '9719', '2', '316000', '1291844126', '0', '0', '306520', '0');
INSERT INTO `auction` VALUES ('20057', '7', '20971', '2735', '2', '2865', '1291865786', '0', '0', '2320', '0');
INSERT INTO `auction` VALUES ('19079', '6', '19993', '10561', '2', '67680', '1291836926', '0', '0', '67680', '0');
INSERT INTO `auction` VALUES ('19080', '6', '19994', '10403', '2', '38316', '1291833326', '0', '0', '29886', '0');
INSERT INTO `auction` VALUES ('20910', '7', '21860', '24602', '2', '1208968', '1291877791', '0', '0', '1051802', '0');
INSERT INTO `auction` VALUES ('19081', '6', '19995', '5524', '2', '260', '1291876526', '0', '0', '197', '0');
INSERT INTO `auction` VALUES ('20911', '7', '21861', '10560', '2', '17360', '1291874191', '0', '0', '17012', '0');
INSERT INTO `auction` VALUES ('19027', '2', '19941', '9719', '2', '335250', '1291869326', '0', '0', '288315', '0');
INSERT INTO `auction` VALUES ('19082', '6', '19996', '12804', '2', '234000', '1291880126', '0', '0', '226980', '0');
INSERT INTO `auction` VALUES ('19047', '2', '19961', '28492', '2', '1830265', '1291865726', '0', '0', '1427606', '0');
INSERT INTO `auction` VALUES ('19475', '2', '20389', '5066', '2', '836', '1291854986', '0', '0', '802', '0');
INSERT INTO `auction` VALUES ('20233', '2', '21147', '14901', '2', '330226', '1291847846', '0', '0', '300505', '0');
INSERT INTO `auction` VALUES ('19628', '2', '20542', '10407', '2', '4924', '1291876586', '0', '0', '4382', '0');
INSERT INTO `auction` VALUES ('18985', '2', '19899', '9719', '2', '396250', '1291851326', '0', '0', '348700', '0');
INSERT INTO `auction` VALUES ('19867', '6', '20781', '10514', '2', '117120', '1291862186', '0', '0', '113606', '0');
INSERT INTO `auction` VALUES ('18986', '2', '19900', '23320', '2', '5888000', '1291836926', '0', '0', '5534720', '0');
INSERT INTO `auction` VALUES ('19476', '2', '20390', '31195', '2', '2208414', '1291829786', '0', '0', '2053825', '0');
INSERT INTO `auction` VALUES ('19657', '2', '20571', '13884', '2', '564', '1291887386', '0', '0', '558', '0');
INSERT INTO `auction` VALUES ('19477', '2', '20391', '24368', '2', '640200', '1291833386', '0', '0', '640200', '0');
INSERT INTO `auction` VALUES ('19658', '2', '20572', '18512', '2', '101760', '1291829786', '0', '0', '73267', '0');
INSERT INTO `auction` VALUES ('20234', '2', '21148', '25306', '2', '3329396', '1291883846', '0', '0', '2863280', '0');
INSERT INTO `auction` VALUES ('19694', '6', '20608', '24401', '2', '688200', '1291854986', '0', '0', '660672', '0');
INSERT INTO `auction` VALUES ('19629', '2', '20543', '10560', '2', '19080', '1291865786', '0', '0', '17172', '0');
INSERT INTO `auction` VALUES ('20058', '7', '20972', '3335', '2', '368', '1291858586', '0', '0', '320', '0');
INSERT INTO `auction` VALUES ('19909', '7', '20823', '10514', '2', '109440', '1291880186', '0', '0', '96307', '0');
INSERT INTO `auction` VALUES ('19048', '2', '19962', '2282', '2', '1505', '1291887326', '0', '0', '1113', '0');
INSERT INTO `auction` VALUES ('20395', '6', '21309', '14899', '2', '452293', '1291858646', '0', '0', '393494', '0');
INSERT INTO `auction` VALUES ('19478', '2', '20392', '36395', '2', '1999143', '1291862186', '0', '0', '1719262', '0');
INSERT INTO `auction` VALUES ('19908', '7', '20822', '9719', '2', '331000', '1291829786', '0', '0', '297900', '0');
INSERT INTO `auction` VALUES ('19659', '2', '20573', '19441', '2', '39240', '1291829786', '0', '0', '29822', '0');
INSERT INTO `auction` VALUES ('20087', '2', '21001', '19441', '2', '28980', '1291876646', '0', '0', '20286', '0');
INSERT INTO `auction` VALUES ('19479', '2', '20393', '2277', '2', '264861', '1291829786', '0', '0', '233077', '0');
INSERT INTO `auction` VALUES ('20235', '2', '21149', '36708', '2', '7667570', '1291880246', '0', '0', '6517434', '0');
INSERT INTO `auction` VALUES ('19028', '2', '19942', '36266', '2', '1932609', '1291851326', '0', '0', '1893956', '0');
INSERT INTO `auction` VALUES ('19049', '2', '19963', '9719', '2', '384250', '1291854926', '0', '0', '376565', '0');
INSERT INTO `auction` VALUES ('19630', '2', '20544', '1077', '2', '1339', '1291865786', '0', '0', '1272', '0');
INSERT INTO `auction` VALUES ('19480', '2', '20394', '31185', '2', '1547043', '1291869386', '0', '0', '1407809', '0');
INSERT INTO `auction` VALUES ('19481', '2', '20395', '24778', '2', '1430357', '1291887386', '0', '0', '1287321', '0');
INSERT INTO `auction` VALUES ('19660', '2', '20574', '9719', '2', '426000', '1291872986', '0', '0', '379140', '0');
INSERT INTO `auction` VALUES ('20088', '2', '21002', '35963', '2', '1086669', '1291833446', '0', '0', '1086669', '0');
INSERT INTO `auction` VALUES ('19029', '2', '19943', '5635', '2', '1328', '1291851326', '0', '0', '1075', '0');
INSERT INTO `auction` VALUES ('19482', '2', '20396', '9061', '2', '39710', '1291836986', '0', '0', '31370', '0');
INSERT INTO `auction` VALUES ('20656', '7', '21570', '4394', '2', '28350', '1291887446', '0', '0', '28350', '0');
INSERT INTO `auction` VALUES ('19032', '2', '19946', '10505', '2', '24440', '1291829726', '0', '0', '21751', '0');
INSERT INTO `auction` VALUES ('19218', '6', '20132', '20528', '2', '58200', '1291876526', '0', '0', '41904', '0');
INSERT INTO `auction` VALUES ('18996', '2', '19910', '9719', '2', '326000', '1291869326', '0', '0', '299920', '0');
INSERT INTO `auction` VALUES ('19768', '6', '20682', '9719', '2', '399000', '1291840586', '0', '0', '331170', '0');
INSERT INTO `auction` VALUES ('19219', '6', '20133', '41427', '2', '180', '1291851326', '0', '0', '147', '0');
INSERT INTO `auction` VALUES ('19220', '6', '20134', '36553', '2', '6814219', '1291851326', '0', '0', '5723943', '0');
INSERT INTO `auction` VALUES ('19462', '7', '20376', '3164', '2', '1532', '1291858526', '0', '0', '1470', '0');
INSERT INTO `auction` VALUES ('18997', '2', '19911', '9719', '2', '410750', '1291876526', '0', '0', '390212', '0');
INSERT INTO `auction` VALUES ('19969', '7', '20883', '13757', '2', '41040', '1291840586', '0', '0', '29959', '0');
INSERT INTO `auction` VALUES ('19712', '6', '20626', '35653', '2', '3247467', '1291851386', '0', '0', '3020144', '0');
INSERT INTO `auction` VALUES ('19221', '6', '20135', '13757', '2', '24288', '1291876526', '0', '0', '22344', '0');
INSERT INTO `auction` VALUES ('20467', '6', '21381', '39681', '2', '262080', '1291851446', '0', '0', '220147', '0');
INSERT INTO `auction` VALUES ('20879', '7', '21829', '7517', '2', '478012', '1291863391', '0', '0', '387189', '0');
INSERT INTO `auction` VALUES ('20880', '7', '21830', '5637', '2', '468', '1291874191', '0', '0', '383', '0');
INSERT INTO `auction` VALUES ('19055', '2', '19969', '31180', '2', '2048399', '1291851326', '0', '0', '1986947', '0');
INSERT INTO `auction` VALUES ('19222', '6', '20136', '10562', '2', '53760', '1291851326', '0', '0', '39244', '0');
INSERT INTO `auction` VALUES ('20881', '7', '21831', '6333', '2', '95581', '1291838191', '0', '0', '81243', '0');
INSERT INTO `auction` VALUES ('20056', '7', '20970', '3327', '2', '1545', '1291854986', '0', '0', '1344', '0');
INSERT INTO `auction` VALUES ('19223', '6', '20137', '37159', '2', '10640', '1291833326', '0', '0', '9895', '0');
INSERT INTO `auction` VALUES ('19224', '6', '20138', '3042', '2', '218122', '1291872926', '0', '0', '218122', '0');
INSERT INTO `auction` VALUES ('20882', '7', '21832', '6200', '2', '63015', '1291863391', '0', '0', '57973', '0');
INSERT INTO `auction` VALUES ('19225', '6', '20139', '36525', '2', '4644165', '1291858526', '0', '0', '4040423', '0');
INSERT INTO `auction` VALUES ('19033', '2', '19947', '31232', '2', '3046450', '1291833326', '0', '0', '2528553', '0');
INSERT INTO `auction` VALUES ('19226', '6', '20140', '9719', '2', '385000', '1291840526', '0', '0', '385000', '0');
INSERT INTO `auction` VALUES ('19227', '6', '20141', '9719', '2', '385000', '1291847726', '0', '0', '361900', '0');
INSERT INTO `auction` VALUES ('19017', '2', '19931', '36567', '2', '6907487', '1291829726', '0', '0', '6493037', '0');
INSERT INTO `auction` VALUES ('19228', '6', '20142', '6458', '2', '45', '1291840526', '0', '0', '38', '0');
INSERT INTO `auction` VALUES ('19034', '2', '19948', '31554', '2', '2531243', '1291883726', '0', '0', '2100931', '0');
INSERT INTO `auction` VALUES ('19229', '6', '20143', '14169', '2', '3312', '1291836926', '0', '0', '3245', '0');
INSERT INTO `auction` VALUES ('19602', '2', '20516', '36528', '2', '7219785', '1291829786', '0', '0', '6642202', '0');
INSERT INTO `auction` VALUES ('19970', '7', '20884', '31231', '2', '1121287', '1291847786', '0', '0', '1054009', '0');
INSERT INTO `auction` VALUES ('19018', '2', '19932', '9719', '2', '398250', '1291872926', '0', '0', '318600', '0');
INSERT INTO `auction` VALUES ('19056', '2', '19970', '5020', '2', '36', '1291836926', '0', '0', '35', '0');
INSERT INTO `auction` VALUES ('20883', '7', '21833', '27511', '2', '237', '1291834591', '0', '0', '184', '0');
INSERT INTO `auction` VALUES ('19230', '6', '20144', '9719', '2', '326000', '1291872926', '0', '0', '322740', '0');
INSERT INTO `auction` VALUES ('19231', '6', '20145', '9719', '2', '419750', '1291847726', '0', '0', '419750', '0');
INSERT INTO `auction` VALUES ('19232', '6', '20146', '16656', '2', '442', '1291865726', '0', '0', '309', '0');
INSERT INTO `auction` VALUES ('19603', '2', '20517', '36289', '2', '3055112', '1291836986', '0', '0', '2902356', '0');
INSERT INTO `auction` VALUES ('19233', '6', '20147', '28531', '2', '1127050', '1291829726', '0', '0', '1036886', '0');
INSERT INTO `auction` VALUES ('19234', '6', '20148', '36514', '2', '7168681', '1291865726', '0', '0', '7025307', '0');
INSERT INTO `auction` VALUES ('19067', '2', '19981', '3331', '2', '763', '1291865726', '0', '0', '732', '0');
INSERT INTO `auction` VALUES ('19235', '6', '20149', '13024', '2', '413179', '1291887326', '0', '0', '384256', '0');
INSERT INTO `auction` VALUES ('20884', '7', '21834', '6197', '2', '61884', '1291838191', '0', '0', '58170', '0');
INSERT INTO `auction` VALUES ('20885', '7', '21835', '865', '2', '240786', '1291874191', '0', '0', '238378', '0');
INSERT INTO `auction` VALUES ('19604', '2', '20518', '1475', '2', '3432', '1291844186', '0', '0', '2436', '0');
INSERT INTO `auction` VALUES ('19236', '6', '20150', '21882', '2', '329800', '1291862126', '0', '0', '306714', '0');
INSERT INTO `auction` VALUES ('19237', '6', '20151', '9719', '2', '386750', '1291844126', '0', '0', '293930', '0');
INSERT INTO `auction` VALUES ('18998', '2', '19912', '29426', '2', '117040', '1291872926', '0', '0', '108847', '0');
INSERT INTO `auction` VALUES ('19605', '2', '20519', '36175', '2', '2531198', '1291833386', '0', '0', '2480574', '0');
INSERT INTO `auction` VALUES ('19446', '7', '20360', '4377', '2', '16128', '1291854926', '0', '0', '12418', '0');
INSERT INTO `auction` VALUES ('19451', '7', '20365', '40199', '2', '2590', '1291865726', '0', '0', '2434', '0');
INSERT INTO `auction` VALUES ('19448', '7', '20362', '29426', '2', '117576', '1291847726', '0', '0', '114048', '0');
INSERT INTO `auction` VALUES ('20886', '7', '21836', '7973', '2', '5975', '1291841791', '0', '0', '5019', '0');
INSERT INTO `auction` VALUES ('19453', '7', '20367', '18588', '2', '14256', '1291862126', '0', '0', '12402', '0');
INSERT INTO `auction` VALUES ('19057', '2', '19971', '44666', '2', '4919504', '1291869326', '0', '0', '4427553', '0');
INSERT INTO `auction` VALUES ('19447', '7', '20361', '36384', '2', '4273885', '1291869326', '0', '0', '4017451', '0');
INSERT INTO `auction` VALUES ('20887', '7', '21837', '24936', '2', '1939427', '1291888591', '0', '0', '1784272', '0');
INSERT INTO `auction` VALUES ('19019', '2', '19933', '9392', '2', '822944', '1291872926', '0', '0', '781796', '0');
INSERT INTO `auction` VALUES ('18999', '2', '19913', '31184', '2', '1670915', '1291858526', '0', '0', '1503823', '0');
INSERT INTO `auction` VALUES ('19666', '2', '20580', '19943', '2', '181280', '1291862186', '0', '0', '145024', '0');
INSERT INTO `auction` VALUES ('19733', '6', '20647', '9719', '2', '373000', '1291858586', '0', '0', '373000', '0');
INSERT INTO `auction` VALUES ('19238', '6', '20152', '9719', '2', '405250', '1291862126', '0', '0', '380935', '0');
INSERT INTO `auction` VALUES ('19035', '2', '19949', '27515', '2', '7920', '1291880126', '0', '0', '7524', '0');
INSERT INTO `auction` VALUES ('19239', '6', '20153', '4481', '2', '12118', '1291851326', '0', '0', '9573', '0');
INSERT INTO `auction` VALUES ('20055', '7', '20969', '9719', '2', '417750', '1291833386', '0', '0', '359265', '0');
INSERT INTO `auction` VALUES ('19240', '6', '20154', '2241', '2', '26477', '1291836926', '0', '0', '23829', '0');
INSERT INTO `auction` VALUES ('20888', '7', '21838', '5523', '2', '1732', '1291856191', '0', '0', '1610', '0');
INSERT INTO `auction` VALUES ('19000', '2', '19914', '21228', '2', '20', '1291883726', '0', '0', '16', '0');
INSERT INTO `auction` VALUES ('18971', '2', '19885', '9719', '2', '317250', '1291887326', '0', '0', '272835', '0');
INSERT INTO `auction` VALUES ('20934', '7', '21884', '10505', '2', '30880', '1291877791', '0', '0', '26556', '0');
INSERT INTO `auction` VALUES ('19640', '2', '20554', '4951', '2', '108', '1291872986', '0', '0', '97', '0');
INSERT INTO `auction` VALUES ('19641', '2', '20555', '13757', '2', '42120', '1291829786', '0', '0', '29484', '0');
INSERT INTO `auction` VALUES ('19642', '2', '20556', '4402', '2', '8760', '1291880186', '0', '0', '6482', '0');
INSERT INTO `auction` VALUES ('18972', '2', '19886', '9719', '2', '316750', '1291840526', '0', '0', '243897', '0');
INSERT INTO `auction` VALUES ('19767', '6', '20681', '9719', '2', '348750', '1291851386', '0', '0', '268537', '0');
INSERT INTO `auction` VALUES ('19241', '6', '20155', '31901', '2', '2734000', '1291880126', '0', '0', '2269220', '0');
INSERT INTO `auction` VALUES ('18973', '2', '19887', '2734', '2', '9135', '1291883726', '0', '0', '8038', '0');
INSERT INTO `auction` VALUES ('19711', '6', '20625', '36048', '2', '1986077', '1291872986', '0', '0', '1747747', '0');
INSERT INTO `auction` VALUES ('19242', '6', '20156', '20677', '2', '27720', '1291854926', '0', '0', '21621', '0');
INSERT INTO `auction` VALUES ('19643', '2', '20557', '22281', '2', '13', '1291847786', '0', '0', '11', '0');
INSERT INTO `auction` VALUES ('19243', '6', '20157', '2283', '2', '5671', '1291880126', '0', '0', '4820', '0');
INSERT INTO `auction` VALUES ('19058', '2', '19972', '44475', '2', '140', '1291854926', '0', '0', '103', '0');
INSERT INTO `auction` VALUES ('19244', '6', '20158', '2982', '2', '25951', '1291883726', '0', '0', '21539', '0');
INSERT INTO `auction` VALUES ('19001', '2', '19915', '20708', '2', '25', '1291869326', '0', '0', '19', '0');
INSERT INTO `auction` VALUES ('20054', '7', '20968', '4377', '2', '21690', '1291876586', '0', '0', '16918', '0');
INSERT INTO `auction` VALUES ('19461', '7', '20375', '25000', '2', '2739370', '1291858526', '0', '0', '2218889', '0');
INSERT INTO `auction` VALUES ('20185', '2', '21099', '44700', '2', '4675', '1291829846', '0', '0', '3880', '0');
INSERT INTO `auction` VALUES ('19245', '6', '20159', '44683', '2', '2521849', '1291862126', '0', '0', '2496630', '0');
INSERT INTO `auction` VALUES ('19068', '2', '19982', '24828', '2', '1397060', '1291876526', '0', '0', '1397060', '0');
INSERT INTO `auction` VALUES ('19606', '2', '20520', '24664', '2', '885091', '1291836986', '0', '0', '805432', '0');
INSERT INTO `auction` VALUES ('19246', '6', '20160', '18678', '2', '1395687', '1291869326', '0', '0', '1102592', '0');
INSERT INTO `auction` VALUES ('20889', '7', '21839', '36263', '2', '2531144', '1291863391', '0', '0', '2278029', '0');
INSERT INTO `auction` VALUES ('20935', '7', '21885', '36058', '2', '1152629', '1291856191', '0', '0', '1083471', '0');
INSERT INTO `auction` VALUES ('19460', '7', '20374', '10514', '2', '61050', '1291872926', '0', '0', '56776', '0');
INSERT INTO `auction` VALUES ('19247', '6', '20161', '18678', '2', '1797346', '1291829726', '0', '0', '1473823', '0');
INSERT INTO `auction` VALUES ('19036', '2', '19950', '45861', '2', '354', '1291833326', '0', '0', '318', '0');
INSERT INTO `auction` VALUES ('20890', '7', '21840', '2046', '2', '113347', '1291859791', '0', '0', '106546', '0');
INSERT INTO `auction` VALUES ('19968', '7', '20882', '6660', '2', '2552740', '1291876586', '0', '0', '2246411', '0');
INSERT INTO `auction` VALUES ('19037', '2', '19951', '37770', '2', '4418958', '1291862126', '0', '0', '3535166', '0');
INSERT INTO `auction` VALUES ('19731', '6', '20645', '9719', '2', '430250', '1291836986', '0', '0', '408737', '0');
INSERT INTO `auction` VALUES ('20365', '6', '21279', '36396', '2', '2303093', '1291833446', '0', '0', '2280062', '0');
INSERT INTO `auction` VALUES ('20740', '2', '21690', '37159', '2', '16875', '1291881391', '0', '0', '13331', '0');
INSERT INTO `auction` VALUES ('19248', '6', '20162', '9719', '2', '324000', '1291847726', '0', '0', '294840', '0');
INSERT INTO `auction` VALUES ('20741', '2', '21691', '1944', '2', '14331', '1291848991', '0', '0', '12754', '0');
INSERT INTO `auction` VALUES ('20428', '6', '21342', '4377', '2', '14472', '1291833446', '0', '0', '11577', '0');
INSERT INTO `auction` VALUES ('19249', '6', '20163', '21561', '2', '1205', '1291876526', '0', '0', '939', '0');
INSERT INTO `auction` VALUES ('19250', '6', '20164', '24601', '2', '747951', '1291883726', '0', '0', '665676', '0');
INSERT INTO `auction` VALUES ('20412', '6', '21326', '9262', '2', '84240', '1291840646', '0', '0', '74131', '0');
INSERT INTO `auction` VALUES ('20693', '2', '21643', '36278', '2', '1453022', '1291838191', '0', '0', '1409431', '0');
INSERT INTO `auction` VALUES ('19020', '2', '19934', '10561', '2', '86000', '1291865726', '0', '0', '67080', '0');
INSERT INTO `auction` VALUES ('20366', '6', '21280', '9249', '2', '51833', '1291887446', '0', '0', '51833', '0');
INSERT INTO `auction` VALUES ('19251', '6', '20165', '5524', '2', '3005', '1291887326', '0', '0', '2223', '0');
INSERT INTO `auction` VALUES ('19252', '6', '20166', '5426', '2', '122333', '1291887326', '0', '0', '111323', '0');
INSERT INTO `auction` VALUES ('20936', '7', '21886', '10331', '2', '146820', '1291881391', '0', '0', '127733', '0');
INSERT INTO `auction` VALUES ('20205', '2', '21119', '9327', '2', '20075', '1291865846', '0', '0', '20075', '0');
INSERT INTO `auction` VALUES ('19021', '2', '19935', '35654', '2', '2220175', '1291876526', '0', '0', '1887148', '0');
INSERT INTO `auction` VALUES ('19253', '6', '20167', '37159', '2', '20790', '1291836926', '0', '0', '17255', '0');
INSERT INTO `auction` VALUES ('19254', '6', '20168', '9719', '2', '423000', '1291836926', '0', '0', '342630', '0');
INSERT INTO `auction` VALUES ('18974', '2', '19888', '30810', '2', '92008', '1291854926', '0', '0', '78206', '0');
INSERT INTO `auction` VALUES ('19644', '2', '20558', '23354', '2', '303', '1291829786', '0', '0', '290', '0');
INSERT INTO `auction` VALUES ('19255', '6', '20169', '9719', '2', '353000', '1291847726', '0', '0', '335350', '0');
INSERT INTO `auction` VALUES ('19256', '6', '20170', '24653', '2', '851593', '1291869326', '0', '0', '698306', '0');
INSERT INTO `auction` VALUES ('19257', '6', '20171', '4634', '2', '4389', '1291869326', '0', '0', '3862', '0');
INSERT INTO `auction` VALUES ('19607', '2', '20521', '9719', '2', '313250', '1291844186', '0', '0', '272527', '0');
INSERT INTO `auction` VALUES ('19258', '6', '20172', '37160', '2', '24000', '1291833326', '0', '0', '18480', '0');
INSERT INTO `auction` VALUES ('19259', '6', '20173', '13875', '2', '9', '1291872926', '0', '0', '8', '0');
INSERT INTO `auction` VALUES ('19645', '2', '20559', '25158', '2', '4522567', '1291862186', '0', '0', '4205987', '0');
INSERT INTO `auction` VALUES ('20742', '2', '21692', '25172', '2', '2863028', '1291845391', '0', '0', '2519464', '0');
INSERT INTO `auction` VALUES ('20937', '7', '21887', '7072', '2', '2352', '1291877791', '0', '0', '1975', '0');
INSERT INTO `auction` VALUES ('19646', '2', '20560', '22642', '2', '11817', '1291862186', '0', '0', '9335', '0');
INSERT INTO `auction` VALUES ('20383', '6', '21297', '4394', '2', '27720', '1291847846', '0', '0', '22176', '0');
INSERT INTO `auction` VALUES ('20206', '2', '21120', '9061', '2', '31140', '1291865846', '0', '0', '30828', '0');
INSERT INTO `auction` VALUES ('20207', '2', '21121', '2623', '2', '217896', '1291880246', '0', '0', '185211', '0');
INSERT INTO `auction` VALUES ('19260', '6', '20174', '17414', '2', '768770', '1291880126', '0', '0', '684205', '0');
INSERT INTO `auction` VALUES ('19261', '6', '20175', '4402', '2', '12500', '1291840526', '0', '0', '11375', '0');
INSERT INTO `auction` VALUES ('19734', '6', '20648', '6333', '2', '114679', '1291865786', '0', '0', '100917', '0');
INSERT INTO `auction` VALUES ('19262', '6', '20176', '4387', '2', '19200', '1291829726', '0', '0', '15744', '0');
INSERT INTO `auction` VALUES ('19455', '7', '20369', '814', '2', '2160', '1291862126', '0', '0', '1576', '0');
INSERT INTO `auction` VALUES ('19263', '6', '20177', '45984', '2', '128800', '1291847726', '0', '0', '124936', '0');
INSERT INTO `auction` VALUES ('19647', '2', '20561', '897', '2', '64781', '1291887386', '0', '0', '63485', '0');
INSERT INTO `auction` VALUES ('20427', '6', '21341', '25116', '2', '2620402', '1291855046', '0', '0', '2463177', '0');
INSERT INTO `auction` VALUES ('19069', '2', '19983', '4388', '2', '8120', '1291876526', '0', '0', '6820', '0');
INSERT INTO `auction` VALUES ('19264', '6', '20178', '9719', '2', '331250', '1291862126', '0', '0', '318000', '0');
INSERT INTO `auction` VALUES ('20938', '7', '21888', '2167', '2', '15213', '1291830991', '0', '0', '12778', '0');
INSERT INTO `auction` VALUES ('20053', '7', '20967', '41119', '2', '3700', '1291872986', '0', '0', '3182', '0');
INSERT INTO `auction` VALUES ('20939', '7', '21889', '24775', '2', '2321396', '1291841791', '0', '0', '2135684', '0');
INSERT INTO `auction` VALUES ('19265', '6', '20179', '13757', '2', '11712', '1291869326', '0', '0', '9252', '0');
INSERT INTO `auction` VALUES ('19266', '6', '20180', '18611', '2', '333', '1291887326', '0', '0', '296', '0');
INSERT INTO `auction` VALUES ('19267', '6', '20181', '9719', '2', '336250', '1291883726', '0', '0', '305987', '0');
INSERT INTO `auction` VALUES ('19268', '6', '20182', '1457', '2', '125443', '1291869326', '0', '0', '114153', '0');
INSERT INTO `auction` VALUES ('19608', '2', '20522', '3072', '2', '79748', '1291858586', '0', '0', '78950', '0');
INSERT INTO `auction` VALUES ('19648', '2', '20562', '9719', '2', '429250', '1291854986', '0', '0', '382032', '0');
INSERT INTO `auction` VALUES ('18975', '2', '19889', '21882', '2', '265600', '1291869326', '0', '0', '225760', '0');
INSERT INTO `auction` VALUES ('20002', '7', '20916', '2807', '2', '191441', '1291836986', '0', '0', '160810', '0');
INSERT INTO `auction` VALUES ('20943', '7', '21893', '5750', '2', '39695', '1291856191', '0', '0', '39695', '0');
INSERT INTO `auction` VALUES ('20445', '6', '21359', '5758', '2', '12310', '1291847846', '0', '0', '12063', '0');
INSERT INTO `auction` VALUES ('20208', '2', '21122', '1460', '2', '109375', '1291829846', '0', '0', '108281', '0');

-- ----------------------------
-- Table structure for `auctionhousebot`
-- ----------------------------
DROP TABLE IF EXISTS `auctionhousebot`;
CREATE TABLE `auctionhousebot` (
  `auctionhouse` int(11) NOT NULL default '0' COMMENT 'mapID of the auctionhouse.',
  `name` char(25) default NULL COMMENT 'Text name of the auctionhouse.',
  `minitems` int(11) default '0' COMMENT 'This is the minimum number of items you want to keep in the auction house. a 0 here will make it the same as the maximum.',
  `maxitems` int(11) default '0' COMMENT 'This is the number of items you want to keep in the auction house.',
  `mintime` int(11) default '8' COMMENT 'Sets the minimum number of hours for an auction.',
  `maxtime` int(11) default '24' COMMENT 'Sets the maximum number of hours for an auction.',
  `percentgreytradegoods` int(11) default '0' COMMENT 'Sets the percentage of the Grey Trade Goods auction items',
  `percentwhitetradegoods` int(11) default '27' COMMENT 'Sets the percentage of the White Trade Goods auction items',
  `percentgreentradegoods` int(11) default '12' COMMENT 'Sets the percentage of the Green Trade Goods auction items',
  `percentbluetradegoods` int(11) default '10' COMMENT 'Sets the percentage of the Blue Trade Goods auction items',
  `percentpurpletradegoods` int(11) default '1' COMMENT 'Sets the percentage of the Purple Trade Goods auction items',
  `percentorangetradegoods` int(11) default '0' COMMENT 'Sets the percentage of the Orange Trade Goods auction items',
  `percentyellowtradegoods` int(11) default '0' COMMENT 'Sets the percentage of the Yellow Trade Goods auction items',
  `percentgreyitems` int(11) default '0' COMMENT 'Sets the percentage of the non trade Grey auction items',
  `percentwhiteitems` int(11) default '10' COMMENT 'Sets the percentage of the non trade White auction items',
  `percentgreenitems` int(11) default '30' COMMENT 'Sets the percentage of the non trade Green auction items',
  `percentblueitems` int(11) default '8' COMMENT 'Sets the percentage of the non trade Blue auction items',
  `percentpurpleitems` int(11) default '2' COMMENT 'Sets the percentage of the non trade Purple auction items',
  `percentorangeitems` int(11) default '0' COMMENT 'Sets the percentage of the non trade Orange auction items',
  `percentyellowitems` int(11) default '0' COMMENT 'Sets the percentage of the non trade Yellow auction items',
  `minpricegrey` int(11) default '100' COMMENT 'Minimum price of Grey items (percentage).',
  `maxpricegrey` int(11) default '150' COMMENT 'Maximum price of Grey items (percentage).',
  `minpricewhite` int(11) default '150' COMMENT 'Minimum price of White items (percentage).',
  `maxpricewhite` int(11) default '250' COMMENT 'Maximum price of White items (percentage).',
  `minpricegreen` int(11) default '800' COMMENT 'Minimum price of Green items (percentage).',
  `maxpricegreen` int(11) default '1400' COMMENT 'Maximum price of Green items (percentage).',
  `minpriceblue` int(11) default '1250' COMMENT 'Minimum price of Blue items (percentage).',
  `maxpriceblue` int(11) default '1750' COMMENT 'Maximum price of Blue items (percentage).',
  `minpricepurple` int(11) default '2250' COMMENT 'Minimum price of Purple items (percentage).',
  `maxpricepurple` int(11) default '4550' COMMENT 'Maximum price of Purple items (percentage).',
  `minpriceorange` int(11) default '3250' COMMENT 'Minimum price of Orange items (percentage).',
  `maxpriceorange` int(11) default '5550' COMMENT 'Maximum price of Orange items (percentage).',
  `minpriceyellow` int(11) default '5250' COMMENT 'Minimum price of Yellow items (percentage).',
  `maxpriceyellow` int(11) default '6550' COMMENT 'Maximum price of Yellow items (percentage).',
  `minbidpricegrey` int(11) default '70' COMMENT 'Starting bid price of Grey items as a percentage of the randomly chosen buyout price. Default: 70',
  `maxbidpricegrey` int(11) default '100' COMMENT 'Starting bid price of Grey items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpricewhite` int(11) default '70' COMMENT 'Starting bid price of White items as a percentage of the randomly chosen buyout price. Default: 70',
  `maxbidpricewhite` int(11) default '100' COMMENT 'Starting bid price of White items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpricegreen` int(11) default '80' COMMENT 'Starting bid price of Green items as a percentage of the randomly chosen buyout price. Default: 80',
  `maxbidpricegreen` int(11) default '100' COMMENT 'Starting bid price of Green items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpriceblue` int(11) default '75' COMMENT 'Starting bid price of Blue items as a percentage of the randomly chosen buyout price. Default: 75',
  `maxbidpriceblue` int(11) default '100' COMMENT 'Starting bid price of Blue items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpricepurple` int(11) default '80' COMMENT 'Starting bid price of Purple items as a percentage of the randomly chosen buyout price. Default: 80',
  `maxbidpricepurple` int(11) default '100' COMMENT 'Starting bid price of Purple items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpriceorange` int(11) default '80' COMMENT 'Starting bid price of Orange items as a percentage of the randomly chosen buyout price. Default: 80',
  `maxbidpriceorange` int(11) default '100' COMMENT 'Starting bid price of Orange items as a percentage of the randomly chosen buyout price. Default: 100',
  `minbidpriceyellow` int(11) default '80' COMMENT 'Starting bid price of Yellow items as a percentage of the randomly chosen buyout price. Default: 80',
  `maxbidpriceyellow` int(11) default '100' COMMENT 'Starting bid price of Yellow items as a percentage of the randomly chosen buyout price. Default: 100',
  `maxstackgrey` int(11) default '0' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackwhite` int(11) default '0' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackgreen` int(11) default '3' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackblue` int(11) default '2' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackpurple` int(11) default '1' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackorange` int(11) default '1' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `maxstackyellow` int(11) default '1' COMMENT 'Stack size limits for item qualities - a value of 0 will disable a maximum stack size for that quality, which will allow the bot to create items in stack as large as the item allows.',
  `buyerpricegrey` int(11) default '1' COMMENT 'Multiplier to vendorprice when buying grey items from auctionhouse',
  `buyerpricewhite` int(11) default '1' COMMENT 'Multiplier to vendorprice when buying white items from auctionhouse',
  `buyerpricegreen` int(11) default '5' COMMENT 'Multiplier to vendorprice when buying green items from auctionhouse',
  `buyerpriceblue` int(11) default '12' COMMENT 'Multiplier to vendorprice when buying blue items from auctionhouse',
  `buyerpricepurple` int(11) default '15' COMMENT 'Multiplier to vendorprice when buying purple items from auctionhouse',
  `buyerpriceorange` int(11) default '20' COMMENT 'Multiplier to vendorprice when buying orange items from auctionhouse',
  `buyerpriceyellow` int(11) default '22' COMMENT 'Multiplier to vendorprice when buying yellow items from auctionhouse',
  `buyerbiddinginterval` int(11) default '1' COMMENT 'Interval how frequently AHB bids on each AH. Time in minutes',
  `buyerbidsperinterval` int(11) default '1' COMMENT 'number of bids to put in per bidding interval',
  PRIMARY KEY  (`auctionhouse`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of auctionhousebot
-- ----------------------------
INSERT INTO `auctionhousebot` VALUES ('2', 'Alliance', '800', '800', '8', '24', '0', '27', '12', '10', '1', '0', '0', '0', '10', '30', '8', '2', '0', '0', '100', '150', '150', '250', '800', '1400', '1250', '1750', '2250', '4550', '3250', '5550', '5250', '6550', '70', '100', '70', '100', '80', '100', '75', '100', '80', '100', '80', '100', '80', '100', '0', '0', '3', '2', '1', '1', '1', '1', '1', '5', '12', '15', '20', '22', '1', '1');
INSERT INTO `auctionhousebot` VALUES ('6', 'Horde', '800', '800', '8', '24', '0', '27', '12', '10', '1', '0', '0', '0', '10', '30', '8', '2', '0', '0', '100', '150', '150', '250', '800', '1400', '1250', '1750', '2250', '4550', '3250', '5550', '5250', '6550', '70', '100', '70', '100', '80', '100', '75', '100', '80', '100', '80', '100', '80', '100', '0', '0', '3', '2', '1', '1', '1', '1', '1', '5', '12', '15', '20', '22', '1', '1');
INSERT INTO `auctionhousebot` VALUES ('7', 'Neutral', '800', '800', '8', '24', '0', '27', '12', '10', '1', '0', '0', '0', '10', '30', '8', '2', '0', '0', '100', '150', '150', '250', '800', '1400', '1250', '1750', '2250', '4550', '3250', '5550', '5250', '6550', '70', '100', '70', '100', '80', '100', '75', '100', '80', '100', '80', '100', '80', '100', '0', '0', '3', '2', '1', '1', '1', '1', '1', '5', '12', '15', '20', '22', '1', '1');

-- ----------------------------
-- Table structure for `autobroadcast`
-- ----------------------------
DROP TABLE IF EXISTS `autobroadcast`;
CREATE TABLE `autobroadcast` (
  `id` int(11) NOT NULL auto_increment,
  `text` longtext NOT NULL,
  `next` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of autobroadcast
-- ----------------------------
INSERT INTO `autobroadcast` VALUES ('1', 'Hello', '0');

-- ----------------------------
-- Table structure for `bugreport`
-- ----------------------------
DROP TABLE IF EXISTS `bugreport`;
CREATE TABLE `bugreport` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Identifier',
  `type` longtext NOT NULL,
  `content` longtext NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Debug System';

-- ----------------------------
-- Records of bugreport
-- ----------------------------

-- ----------------------------
-- Table structure for `character_account_data`
-- ----------------------------
DROP TABLE IF EXISTS `character_account_data`;
CREATE TABLE `character_account_data` (
  `guid` int(11) unsigned NOT NULL default '0',
  `type` int(11) unsigned NOT NULL default '0',
  `time` bigint(11) unsigned NOT NULL default '0',
  `data` longblob NOT NULL,
  PRIMARY KEY  (`guid`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_account_data
-- ----------------------------
INSERT INTO `character_account_data` VALUES ('6', '3', '1290957658', 0x42494E44494E474D4F444520300D0A62696E6420494E534552542053435245454E53484F540D0A62696E642050414745555020464C495043414D4552415941570D0A62696E64205052494E5453435245454E2053435245454E53484F540D0A62696E642053484946542D4C205147545F544F47474C455F545241434B45525F4B420D0A);
INSERT INTO `character_account_data` VALUES ('6', '7', '1290769026', 0x56455253494F4E20350A0A414444454456455253494F4E2031330A0A4F5054494F4E5F4755494C445F524543525549544D454E545F4348414E4E454C204155544F0A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C532035323432383830330A0A434F4C4F52530A53595354454D20323535203235352030204E0A534159203235352032353520323535204E0A5041525459203137302031373020323535204E0A5241494420323535203132372030204E0A4755494C4420363420323535203634204E0A4F46464943455220363420313932203634204E0A59454C4C20323535203634203634204E0A57484953504552203235352031323820323535204E0A574849535045525F464F524549474E203235352031323820323535204E0A574849535045525F494E464F524D203235352031323820323535204E0A454D4F54452032353520313238203634204E0A544558545F454D4F54452032353520313238203634204E0A4D4F4E535445525F534159203235352032353520313539204E0A4D4F4E535445525F5041525459203137302031373020323535204E0A4D4F4E535445525F59454C4C20323535203634203634204E0A4D4F4E535445525F57484953504552203235352031383120323335204E0A4D4F4E535445525F454D4F54452032353520313238203634204E0A4348414E4E454C203235352031393220313932204E0A4348414E4E454C5F4A4F494E203139322031323820313238204E0A4348414E4E454C5F4C45415645203139322031323820313238204E0A4348414E4E454C5F4C495354203139322031323820313238204E0A4348414E4E454C5F4E4F54494345203139322031393220313932204E0A4348414E4E454C5F4E4F544943455F55534552203139322031393220313932204E0A41464B203235352031323820323535204E0A444E44203235352031323820323535204E0A49474E4F5245442032353520302030204E0A534B494C4C20383520383520323535204E0A4C4F4F542030203137302030204E0A4D4F4E455920323535203235352030204E0A4F50454E494E47203132382031323820323535204E0A5452414445534B494C4C53203235352032353520323535204E0A5045545F494E464F203132382031323820323535204E0A434F4D4241545F4D4953435F494E464F203132382031323820323535204E0A434F4D4241545F58505F4741494E203131312031313120323535204E0A434F4D4241545F484F4E4F525F4741494E2032323420323032203130204E0A434F4D4241545F46414354494F4E5F4348414E4745203132382031323820323535204E0A42475F53595354454D5F4E45555452414C2032353520313230203130204E0A42475F53595354454D5F414C4C49414E434520302031373420323339204E0A42475F53595354454D5F484F5244452032353520302030204E0A524149445F4C4541444552203235352037322039204E0A524149445F5741524E494E47203235352037322030204E0A524149445F424F53535F454D4F544520323535203232312030204E0A524149445F424F53535F5748495350455220323535203232312030204E0A46494C54455245442032353520302030204E0A424154544C4547524F554E4420323535203132372030204E0A424154544C4547524F554E445F4C4541444552203235352032313920313833204E0A524553545249435445442032353520302030204E0A424154544C454E4554203235352032353520323535204E0A414348494556454D454E5420323535203235352030204E0A4755494C445F414348494556454D454E5420363420323535203634204E0A4152454E415F504F494E5453203235352032353520323535204E0A50415254595F4C4541444552203131382032303020323535204E0A54415247455449434F4E5320323535203235352030204E0A424E5F5748495350455220302032353520323436204E0A424E5F574849535045525F494E464F524D20302032353520323436204E0A424E5F434F4E564552534154494F4E20302031373720323430204E0A424E5F434F4E564552534154494F4E5F4E4F5449434520302031373720323430204E0A424E5F434F4E564552534154494F4E5F4C49535420302031373720323430204E0A424E5F494E4C494E455F544F4153545F414C455254203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F414443415354203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F4144434153545F494E464F524D203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F434F4E564552534154494F4E203133302031393720323535204E0A4348414E4E454C31203235352031393220313932204E0A4348414E4E454C32203235352031393220313932204E0A4348414E4E454C33203235352031393220313932204E0A4348414E4E454C34203235352031393220313932204E0A4348414E4E454C35203235352031393220313932204E0A4348414E4E454C36203235352031393220313932204E0A4348414E4E454C37203235352031393220313932204E0A4348414E4E454C38203235352031393220313932204E0A4348414E4E454C39203235352031393220313932204E0A4348414E4E454C3130203235352031393220313932204E0A454E440A0A57494E444F5720310A4E414D452047656E6572616C0A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420310A53484F574E20310A4D455353414745530A53595354454D0A53595354454D5F4E4F4D454E550A5341590A454D4F54450A59454C4C0A574849535045520A50415254590A50415254595F4C45414445520A524149440A524149445F4C45414445520A524149445F5741524E494E470A424154544C4547524F554E440A424154544C4547524F554E445F4C45414445520A4755494C440A4F4646494345520A4D4F4E535445525F5341590A4D4F4E535445525F59454C4C0A4D4F4E535445525F454D4F54450A4D4F4E535445525F574849535045520A4D4F4E535445525F424F53535F454D4F54450A4D4F4E535445525F424F53535F574849535045520A4552524F52530A41464B0A444E440A49474E4F5245440A42475F484F5244450A42475F414C4C49414E43450A42475F4E45555452414C0A434F4D4241545F46414354494F4E5F4348414E47450A534B494C4C0A4C4F4F540A4D4F4E45590A4348414E4E454C0A414348494556454D454E540A4755494C445F414348494556454D454E540A54415247455449434F4E530A424E5F574849535045520A424E5F574849535045525F494E464F524D0A424E5F434F4E564552534154494F4E0A424E5F494E4C494E455F544F4153545F414C4552540A454E440A0A4348414E4E454C530A5472697669610A454E440A0A5A4F4E454348414E4E454C532035323432383830330A0A454E440A0A57494E444F5720320A4E414D4520436F6D626174204C6F670A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420320A53484F574E20300A4D455353414745530A4F50454E494E470A5452414445534B494C4C530A5045545F494E464F0A434F4D4241545F58505F4741494E0A434F4D4241545F484F4E4F525F4741494E0A434F4D4241545F4D4953435F494E464F0A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720330A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720340A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720350A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720360A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720370A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720380A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720390A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F572031300A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A);
INSERT INTO `character_account_data` VALUES ('7', '1', '1290337080', 0x5345542071756573744C6F67436F6C6C6170736546696C74657220222D31220A53455420747261636B656451756573747320227601220A53455420747261636B6564416368696576656D656E747320227601220A5345542063616D657261536176656444697374616E63652022332E353530383030220A5345542063616D65726153617665645069746368202231322E343530303037220A53455420706C61796572537461744C65667444726F70646F776E2022504C41594552535441545F424153455F5354415453220A53455420706C6179657253746174526967687444726F70646F776E2022504C41594552535441545F4D454C45455F434F4D424154220A);
INSERT INTO `character_account_data` VALUES ('7', '7', '1290337079', 0x56455253494F4E20350A0A414444454456455253494F4E2031330A0A4F5054494F4E5F4755494C445F524543525549544D454E545F4348414E4E454C204155544F0A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C532035323432383830330A0A434F4C4F52530A53595354454D20323535203235352030204E0A534159203235352032353520323535204E0A5041525459203137302031373020323535204E0A5241494420323535203132372030204E0A4755494C4420363420323535203634204E0A4F46464943455220363420313932203634204E0A59454C4C20323535203634203634204E0A57484953504552203235352031323820323535204E0A574849535045525F464F524549474E203235352031323820323535204E0A574849535045525F494E464F524D203235352031323820323535204E0A454D4F54452032353520313238203634204E0A544558545F454D4F54452032353520313238203634204E0A4D4F4E535445525F534159203235352032353520313539204E0A4D4F4E535445525F5041525459203137302031373020323535204E0A4D4F4E535445525F59454C4C20323535203634203634204E0A4D4F4E535445525F57484953504552203235352031383120323335204E0A4D4F4E535445525F454D4F54452032353520313238203634204E0A4348414E4E454C203235352031393220313932204E0A4348414E4E454C5F4A4F494E203139322031323820313238204E0A4348414E4E454C5F4C45415645203139322031323820313238204E0A4348414E4E454C5F4C495354203139322031323820313238204E0A4348414E4E454C5F4E4F54494345203139322031393220313932204E0A4348414E4E454C5F4E4F544943455F55534552203139322031393220313932204E0A41464B203235352031323820323535204E0A444E44203235352031323820323535204E0A49474E4F5245442032353520302030204E0A534B494C4C20383520383520323535204E0A4C4F4F542030203137302030204E0A4D4F4E455920323535203235352030204E0A4F50454E494E47203132382031323820323535204E0A5452414445534B494C4C53203235352032353520323535204E0A5045545F494E464F203132382031323820323535204E0A434F4D4241545F4D4953435F494E464F203132382031323820323535204E0A434F4D4241545F58505F4741494E203131312031313120323535204E0A434F4D4241545F484F4E4F525F4741494E2032323420323032203130204E0A434F4D4241545F46414354494F4E5F4348414E4745203132382031323820323535204E0A42475F53595354454D5F4E45555452414C2032353520313230203130204E0A42475F53595354454D5F414C4C49414E434520302031373420323339204E0A42475F53595354454D5F484F5244452032353520302030204E0A524149445F4C4541444552203235352037322039204E0A524149445F5741524E494E47203235352037322030204E0A524149445F424F53535F454D4F544520323535203232312030204E0A524149445F424F53535F5748495350455220323535203232312030204E0A46494C54455245442032353520302030204E0A424154544C4547524F554E4420323535203132372030204E0A424154544C4547524F554E445F4C4541444552203235352032313920313833204E0A524553545249435445442032353520302030204E0A424154544C454E4554203235352032353520323535204E0A414348494556454D454E5420323535203235352030204E0A4755494C445F414348494556454D454E5420363420323535203634204E0A4152454E415F504F494E5453203235352032353520323535204E0A50415254595F4C4541444552203131382032303020323535204E0A54415247455449434F4E5320323535203235352030204E0A424E5F5748495350455220302032353520323436204E0A424E5F574849535045525F494E464F524D20302032353520323436204E0A424E5F434F4E564552534154494F4E20302031373720323430204E0A424E5F434F4E564552534154494F4E5F4E4F5449434520302031373720323430204E0A424E5F434F4E564552534154494F4E5F4C49535420302031373720323430204E0A424E5F494E4C494E455F544F4153545F414C455254203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F414443415354203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F4144434153545F494E464F524D203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F434F4E564552534154494F4E203133302031393720323535204E0A4348414E4E454C31203235352031393220313932204E0A4348414E4E454C32203235352031393220313932204E0A4348414E4E454C33203235352031393220313932204E0A4348414E4E454C34203235352031393220313932204E0A4348414E4E454C35203235352031393220313932204E0A4348414E4E454C36203235352031393220313932204E0A4348414E4E454C37203235352031393220313932204E0A4348414E4E454C38203235352031393220313932204E0A4348414E4E454C39203235352031393220313932204E0A4348414E4E454C3130203235352031393220313932204E0A454E440A0A57494E444F5720310A4E414D452047656E6572616C0A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420310A53484F574E20300A4D455353414745530A53595354454D0A53595354454D5F4E4F4D454E550A5341590A454D4F54450A59454C4C0A574849535045520A50415254590A50415254595F4C45414445520A524149440A524149445F4C45414445520A524149445F5741524E494E470A424154544C4547524F554E440A424154544C4547524F554E445F4C45414445520A4755494C440A4F4646494345520A4D4F4E535445525F5341590A4D4F4E535445525F59454C4C0A4D4F4E535445525F454D4F54450A4D4F4E535445525F574849535045520A4D4F4E535445525F424F53535F454D4F54450A4D4F4E535445525F424F53535F574849535045520A4552524F52530A41464B0A444E440A49474E4F5245440A42475F484F5244450A42475F414C4C49414E43450A42475F4E45555452414C0A434F4D4241545F46414354494F4E5F4348414E47450A534B494C4C0A4C4F4F540A4D4F4E45590A4348414E4E454C0A414348494556454D454E540A4755494C445F414348494556454D454E540A54415247455449434F4E530A424E5F574849535045520A424E5F574849535045525F494E464F524D0A424E5F434F4E564552534154494F4E0A424E5F494E4C494E455F544F4153545F414C4552540A454E440A0A4348414E4E454C530A4C6F6F6B696E67466F7247726F75700A454E440A0A5A4F4E454348414E4E454C532031383837343337310A0A454E440A0A57494E444F5720320A4E414D4520436F6D626174204C6F670A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420320A53484F574E20300A4D455353414745530A4F50454E494E470A5452414445534B494C4C530A5045545F494E464F0A434F4D4241545F58505F4741494E0A434F4D4241545F484F4E4F525F4741494E0A434F4D4241545F4D4953435F494E464F0A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720330A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720340A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720350A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720360A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720370A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720380A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720390A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F572031300A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A);
INSERT INTO `character_account_data` VALUES ('2', '7', '1290821039', 0x56455253494F4E20350A0A414444454456455253494F4E2031330A0A4F5054494F4E5F4755494C445F524543525549544D454E545F4348414E4E454C204155544F0A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C532035323432383830330A0A434F4C4F52530A53595354454D20323535203235352030204E0A534159203235352032353520323535204E0A5041525459203137302031373020323535204E0A5241494420323535203132372030204E0A4755494C4420363420323535203634204E0A4F46464943455220363420313932203634204E0A59454C4C20323535203634203634204E0A57484953504552203235352031323820323535204E0A574849535045525F464F524549474E203235352031323820323535204E0A574849535045525F494E464F524D203235352031323820323535204E0A454D4F54452032353520313238203634204E0A544558545F454D4F54452032353520313238203634204E0A4D4F4E535445525F534159203235352032353520313539204E0A4D4F4E535445525F5041525459203137302031373020323535204E0A4D4F4E535445525F59454C4C20323535203634203634204E0A4D4F4E535445525F57484953504552203235352031383120323335204E0A4D4F4E535445525F454D4F54452032353520313238203634204E0A4348414E4E454C203235352031393220313932204E0A4348414E4E454C5F4A4F494E203139322031323820313238204E0A4348414E4E454C5F4C45415645203139322031323820313238204E0A4348414E4E454C5F4C495354203139322031323820313238204E0A4348414E4E454C5F4E4F54494345203139322031393220313932204E0A4348414E4E454C5F4E4F544943455F55534552203139322031393220313932204E0A41464B203235352031323820323535204E0A444E44203235352031323820323535204E0A49474E4F5245442032353520302030204E0A534B494C4C20383520383520323535204E0A4C4F4F542030203137302030204E0A4D4F4E455920323535203235352030204E0A4F50454E494E47203132382031323820323535204E0A5452414445534B494C4C53203235352032353520323535204E0A5045545F494E464F203132382031323820323535204E0A434F4D4241545F4D4953435F494E464F203132382031323820323535204E0A434F4D4241545F58505F4741494E203131312031313120323535204E0A434F4D4241545F484F4E4F525F4741494E2032323420323032203130204E0A434F4D4241545F46414354494F4E5F4348414E4745203132382031323820323535204E0A42475F53595354454D5F4E45555452414C2032353520313230203130204E0A42475F53595354454D5F414C4C49414E434520302031373420323339204E0A42475F53595354454D5F484F5244452032353520302030204E0A524149445F4C4541444552203235352037322039204E0A524149445F5741524E494E47203235352037322030204E0A524149445F424F53535F454D4F544520323535203232312030204E0A524149445F424F53535F5748495350455220323535203232312030204E0A46494C54455245442032353520302030204E0A424154544C4547524F554E4420323535203132372030204E0A424154544C4547524F554E445F4C4541444552203235352032313920313833204E0A524553545249435445442032353520302030204E0A424154544C454E4554203235352032353520323535204E0A414348494556454D454E5420323535203235352030204E0A4755494C445F414348494556454D454E5420363420323535203634204E0A4152454E415F504F494E5453203235352032353520323535204E0A50415254595F4C4541444552203131382032303020323535204E0A54415247455449434F4E5320323535203235352030204E0A424E5F5748495350455220302032353520323436204E0A424E5F574849535045525F494E464F524D20302032353520323436204E0A424E5F434F4E564552534154494F4E20302031373720323430204E0A424E5F434F4E564552534154494F4E5F4E4F5449434520302031373720323430204E0A424E5F434F4E564552534154494F4E5F4C49535420302031373720323430204E0A424E5F494E4C494E455F544F4153545F414C455254203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F414443415354203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F4144434153545F494E464F524D203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F434F4E564552534154494F4E203133302031393720323535204E0A4348414E4E454C31203235352031393220313932204E0A4348414E4E454C32203235352031393220313932204E0A4348414E4E454C33203235352031393220313932204E0A4348414E4E454C34203235352031393220313932204E0A4348414E4E454C35203235352031393220313932204E0A4348414E4E454C36203235352031393220313932204E0A4348414E4E454C37203235352031393220313932204E0A4348414E4E454C38203235352031393220313932204E0A4348414E4E454C39203235352031393220313932204E0A4348414E4E454C3130203235352031393220313932204E0A454E440A0A57494E444F5720310A4E414D452047656E6572616C0A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420310A53484F574E20310A4D455353414745530A53595354454D0A53595354454D5F4E4F4D454E550A5341590A454D4F54450A59454C4C0A574849535045520A50415254590A50415254595F4C45414445520A524149440A524149445F4C45414445520A524149445F5741524E494E470A424154544C4547524F554E440A424154544C4547524F554E445F4C45414445520A4755494C440A4F4646494345520A4D4F4E535445525F5341590A4D4F4E535445525F59454C4C0A4D4F4E535445525F454D4F54450A4D4F4E535445525F574849535045520A4D4F4E535445525F424F53535F454D4F54450A4D4F4E535445525F424F53535F574849535045520A4552524F52530A41464B0A444E440A49474E4F5245440A42475F484F5244450A42475F414C4C49414E43450A42475F4E45555452414C0A434F4D4241545F46414354494F4E5F4348414E47450A534B494C4C0A4C4F4F540A4D4F4E45590A4348414E4E454C0A414348494556454D454E540A4755494C445F414348494556454D454E540A54415247455449434F4E530A424E5F574849535045520A424E5F574849535045525F494E464F524D0A424E5F434F4E564552534154494F4E0A424E5F494E4C494E455F544F4153545F414C4552540A454E440A0A4348414E4E454C530A4C6F6F6B696E67466F7247726F75700A5472697669610A454E440A0A5A4F4E454348414E4E454C532031383837343337310A0A454E440A0A57494E444F5720320A4E414D4520436F6D626174204C6F670A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420320A53484F574E20300A4D455353414745530A4F50454E494E470A5452414445534B494C4C530A5045545F494E464F0A434F4D4241545F58505F4741494E0A434F4D4241545F484F4E4F525F4741494E0A434F4D4241545F4D4953435F494E464F0A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720330A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720340A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720350A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720360A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720370A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720380A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720390A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F572031300A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A);
INSERT INTO `character_account_data` VALUES ('6', '1', '1291467748', 0x534554206D696E696D61705A6F6F6D202230220A534554206D696E696D6170496E736964655A6F6F6D202230220A5345542071756573744C6F67436F6C6C6170736546696C74657220222D31220A53455420747261636B656451756573747320227601220A53455420747261636B6564416368696576656D656E747320227601220A5345542063616D657261536176656444697374616E63652022322E393938383030220A5345542063616D65726153617665645069746368202231352E313530303030220A53455420706C61796572537461744C65667444726F70646F776E2022504C41594552535441545F424153455F5354415453220A53455420706C6179657253746174526967687444726F70646F776E2022504C41594552535441545F4D454C45455F434F4D424154220A);
INSERT INTO `character_account_data` VALUES ('9', '1', '1291802653', 0x534554206D696E696D61705A6F6F6D202230220A534554206D696E696D6170496E736964655A6F6F6D202230220A5345542071756573744C6F67436F6C6C6170736546696C74657220222D31220A53455420747261636B656451756573747320227601220A53455420747261636B6564416368696576656D656E747320227601220A5345542063616D657261536176656444697374616E6365202231372E393134393039220A5345542063616D657261536176656456656869636C6544697374616E6365202231392E383839313134220A5345542063616D65726153617665645069746368202232302E323530303033220A53455420706C61796572537461744C65667444726F70646F776E2022504C41594552535441545F424153455F5354415453220A53455420706C6179657253746174526967687444726F70646F776E2022504C41594552535441545F52414E4745445F434F4D424154220A);
INSERT INTO `character_account_data` VALUES ('9', '3', '1290847749', 0x42494E44494E474D4F444520300D0A62696E6420494E534552542053435245454E53484F540D0A62696E642050414745555020464C495043414D4552415941570D0A62696E64205052494E5453435245454E2053435245454E53484F540D0A62696E642053484946542D4C205147545F544F47474C455F545241434B45525F4B420D0A);
INSERT INTO `character_account_data` VALUES ('9', '7', '1291802142', 0x56455253494F4E20350A0A414444454456455253494F4E2031330A0A4F5054494F4E5F4755494C445F524543525549544D454E545F4348414E4E454C204155544F0A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C532035323432383830330A0A434F4C4F52530A53595354454D20323535203235352030204E0A534159203235352032353520323535204E0A5041525459203137302031373020323535204E0A5241494420323535203132372030204E0A4755494C4420363420323535203634204E0A4F46464943455220363420313932203634204E0A59454C4C20323535203634203634204E0A57484953504552203235352031323820323535204E0A574849535045525F464F524549474E203235352031323820323535204E0A574849535045525F494E464F524D203235352031323820323535204E0A454D4F54452032353520313238203634204E0A544558545F454D4F54452032353520313238203634204E0A4D4F4E535445525F534159203235352032353520313539204E0A4D4F4E535445525F5041525459203137302031373020323535204E0A4D4F4E535445525F59454C4C20323535203634203634204E0A4D4F4E535445525F57484953504552203235352031383120323335204E0A4D4F4E535445525F454D4F54452032353520313238203634204E0A4348414E4E454C203235352031393220313932204E0A4348414E4E454C5F4A4F494E203139322031323820313238204E0A4348414E4E454C5F4C45415645203139322031323820313238204E0A4348414E4E454C5F4C495354203139322031323820313238204E0A4348414E4E454C5F4E4F54494345203139322031393220313932204E0A4348414E4E454C5F4E4F544943455F55534552203139322031393220313932204E0A41464B203235352031323820323535204E0A444E44203235352031323820323535204E0A49474E4F5245442032353520302030204E0A534B494C4C20383520383520323535204E0A4C4F4F542030203137302030204E0A4D4F4E455920323535203235352030204E0A4F50454E494E47203132382031323820323535204E0A5452414445534B494C4C53203235352032353520323535204E0A5045545F494E464F203132382031323820323535204E0A434F4D4241545F4D4953435F494E464F203132382031323820323535204E0A434F4D4241545F58505F4741494E203131312031313120323535204E0A434F4D4241545F484F4E4F525F4741494E2032323420323032203130204E0A434F4D4241545F46414354494F4E5F4348414E4745203132382031323820323535204E0A42475F53595354454D5F4E45555452414C2032353520313230203130204E0A42475F53595354454D5F414C4C49414E434520302031373420323339204E0A42475F53595354454D5F484F5244452032353520302030204E0A524149445F4C4541444552203235352037322039204E0A524149445F5741524E494E47203235352037322030204E0A524149445F424F53535F454D4F544520323535203232312030204E0A524149445F424F53535F5748495350455220323535203232312030204E0A46494C54455245442032353520302030204E0A424154544C4547524F554E4420323535203132372030204E0A424154544C4547524F554E445F4C4541444552203235352032313920313833204E0A524553545249435445442032353520302030204E0A424154544C454E4554203235352032353520323535204E0A414348494556454D454E5420323535203235352030204E0A4755494C445F414348494556454D454E5420363420323535203634204E0A4152454E415F504F494E5453203235352032353520323535204E0A50415254595F4C4541444552203131382032303020323535204E0A54415247455449434F4E5320323535203235352030204E0A424E5F5748495350455220302032353520323436204E0A424E5F574849535045525F494E464F524D20302032353520323436204E0A424E5F434F4E564552534154494F4E20302031373720323430204E0A424E5F434F4E564552534154494F4E5F4E4F5449434520302031373720323430204E0A424E5F434F4E564552534154494F4E5F4C49535420302031373720323430204E0A424E5F494E4C494E455F544F4153545F414C455254203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F414443415354203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F42524F4144434153545F494E464F524D203133302031393720323535204E0A424E5F494E4C494E455F544F4153545F434F4E564552534154494F4E203133302031393720323535204E0A4348414E4E454C31203235352031393220313932204E0A4348414E4E454C32203235352031393220313932204E0A4348414E4E454C33203235352031393220313932204E0A4348414E4E454C34203235352031393220313932204E0A4348414E4E454C35203235352031393220313932204E0A4348414E4E454C36203235352031393220313932204E0A4348414E4E454C37203235352031393220313932204E0A4348414E4E454C38203235352031393220313932204E0A4348414E4E454C39203235352031393220313932204E0A4348414E4E454C3130203235352031393220313932204E0A454E440A0A57494E444F5720310A4E414D452047656E6572616C0A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420310A53484F574E20310A4D455353414745530A53595354454D0A53595354454D5F4E4F4D454E550A5341590A454D4F54450A59454C4C0A574849535045520A50415254590A50415254595F4C45414445520A524149440A524149445F4C45414445520A524149445F5741524E494E470A424154544C4547524F554E440A424154544C4547524F554E445F4C45414445520A4755494C440A4F4646494345520A4D4F4E535445525F5341590A4D4F4E535445525F59454C4C0A4D4F4E535445525F454D4F54450A4D4F4E535445525F574849535045520A4D4F4E535445525F424F53535F454D4F54450A4D4F4E535445525F424F53535F574849535045520A4552524F52530A41464B0A444E440A49474E4F5245440A42475F484F5244450A42475F414C4C49414E43450A42475F4E45555452414C0A434F4D4241545F46414354494F4E5F4348414E47450A534B494C4C0A4C4F4F540A4D4F4E45590A4348414E4E454C0A414348494556454D454E540A4755494C445F414348494556454D454E540A54415247455449434F4E530A424E5F574849535045520A424E5F574849535045525F494E464F524D0A424E5F434F4E564552534154494F4E0A424E5F494E4C494E455F544F4153545F414C4552540A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C532031383837343337310A0A454E440A0A57494E444F5720320A4E414D4520436F6D626174204C6F670A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420320A53484F574E20300A4D455353414745530A4F50454E494E470A5452414445534B494C4C530A5045545F494E464F0A434F4D4241545F58505F4741494E0A434F4D4241545F484F4E4F525F4741494E0A434F4D4241545F4D4953435F494E464F0A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720330A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720340A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720350A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720360A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720370A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720380A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F5720390A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A57494E444F572031300A53495A4520300A434F4C4F522030203020302034300A4C4F434B454420310A554E494E54455241435441424C4520300A444F434B454420300A53484F574E20300A4D455353414745530A454E440A0A4348414E4E454C530A454E440A0A5A4F4E454348414E4E454C5320300A0A454E440A0A);
INSERT INTO `character_account_data` VALUES ('2', '1', '1290821038', 0x534554206D696E696D61705A6F6F6D202230220A5345542071756573744C6F67436F6C6C6170736546696C74657220222D31220A53455420747261636B656451756573747320227601220A53455420747261636B6564416368696576656D656E747320227601220A5345542063616D657261536176656444697374616E6365202232302E343639303238220A5345542063616D65726153617665645069746368202231332E343137353436220A53455420706C61796572537461744C65667444726F70646F776E2022504C41594552535441545F424153455F5354415453220A53455420706C6179657253746174526967687444726F70646F776E2022504C41594552535441545F4D454C45455F434F4D424154220A);
INSERT INTO `character_account_data` VALUES ('2', '3', '1290503503', 0x42494E44494E474D4F444520300D0A62696E642053484946542D4C205147545F544F47474C455F545241434B45525F4B420D0A);

-- ----------------------------
-- Table structure for `character_achievement`
-- ----------------------------
DROP TABLE IF EXISTS `character_achievement`;
CREATE TABLE `character_achievement` (
  `guid` int(11) unsigned NOT NULL,
  `achievement` int(11) unsigned NOT NULL,
  `date` bigint(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`achievement`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_achievement
-- ----------------------------

-- ----------------------------
-- Table structure for `character_achievement_progress`
-- ----------------------------
DROP TABLE IF EXISTS `character_achievement_progress`;
CREATE TABLE `character_achievement_progress` (
  `guid` int(11) unsigned NOT NULL,
  `criteria` int(11) unsigned NOT NULL,
  `counter` int(11) unsigned NOT NULL,
  `date` bigint(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`criteria`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_achievement_progress
-- ----------------------------
INSERT INTO `character_achievement_progress` VALUES ('10', '37', '1', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '9684', '500', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '8820', '500', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '5580', '1', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '5316', '3100', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '5212', '1', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '2020', '200', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '1884', '3500', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '996', '4000', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '756', '1', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '36', '1', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '9683', '500', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '8819', '500', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '5315', '500', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '4763', '3500', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '995', '500', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '35', '1', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '5313', '500', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '993', '500', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '657', '1', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '40', '1', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('6', '3355', '1365', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '5372', '1271', '1290610616');
INSERT INTO `character_achievement_progress` VALUES ('6', '233', '21', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '753', '30', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '841', '75', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '73', '21', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '41', '6', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '6752', '6', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '4224', '1605', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '992', '1391', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5701', '1', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '9687', '3991', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '613', '75', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '5375', '149', '1290753226');
INSERT INTO `character_achievement_progress` VALUES ('6', '7891', '15', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '756', '30', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '842', '75', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '5230', '6', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '6753', '6', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '5317', '7605', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5249', '1', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('10', '5586', '1', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '5314', '500', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '994', '3100', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '34', '1', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '41', '1', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '5216', '1', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '992', '500', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '9687', '3100', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '5591', '1', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '655', '1', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '167', '1', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '39', '1', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '9686', '500', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '9598', '1', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '8822', '500', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '5230', '1', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '38', '1', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '9685', '4000', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '8821', '500', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '5589', '1', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '5317', '4000', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '5301', '6', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('10', '757', '1', '1291800911');
INSERT INTO `character_achievement_progress` VALUES ('6', '37', '6', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5592', '1', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '6751', '6', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '4093', '264', '1290827749');
INSERT INTO `character_achievement_progress` VALUES ('6', '5212', '6', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '4092', '1365', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '7222', '2', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '9683', '1391', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '3507', '264', '1290827749');
INSERT INTO `character_achievement_progress` VALUES ('6', '4961', '1', '1290827988');
INSERT INTO `character_achievement_progress` VALUES ('6', '234', '21', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '5313', '1391', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '4959', '1', '1290827988');
INSERT INTO `character_achievement_progress` VALUES ('6', '3361', '1103', '1290752521');
INSERT INTO `character_achievement_progress` VALUES ('6', '614', '75', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '993', '1391', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '4943', '149', '1290753226');
INSERT INTO `character_achievement_progress` VALUES ('6', '111', '1', '1290827988');
INSERT INTO `character_achievement_progress` VALUES ('6', '5967', '5', '1290959143');
INSERT INTO `character_achievement_progress` VALUES ('6', '3354', '264', '1290827749');
INSERT INTO `character_achievement_progress` VALUES ('6', '5215', '6', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5373', '32', '1290610616');
INSERT INTO `character_achievement_progress` VALUES ('6', '3631', '21', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '5376', '3', '1290753226');
INSERT INTO `character_achievement_progress` VALUES ('6', '2239', '21', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '167', '30', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5371', '130', '1290610616');
INSERT INTO `character_achievement_progress` VALUES ('6', '612', '75', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '9686', '1391', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '162', '6782', '1290610616');
INSERT INTO `character_achievement_progress` VALUES ('6', '3512', '264', '1290827749');
INSERT INTO `character_achievement_progress` VALUES ('6', '5563', '1', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '843', '75', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '6754', '6', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '1510', '1', '1290959910');
INSERT INTO `character_achievement_progress` VALUES ('6', '38', '6', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '230', '21', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '6393', '6', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '615', '75', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '3510', '264', '1290827749');
INSERT INTO `character_achievement_progress` VALUES ('6', '9684', '1391', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5577', '30', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5593', '1', '1290827988');
INSERT INTO `character_achievement_progress` VALUES ('6', '4960', '1', '1290827988');
INSERT INTO `character_achievement_progress` VALUES ('6', '5316', '3991', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '36', '6', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '4091', '1103', '1290752521');
INSERT INTO `character_achievement_progress` VALUES ('6', '996', '7605', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5314', '1391', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '7221', '6', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '994', '3991', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5576', '30', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '3506', '264', '1290827749');
INSERT INTO `character_achievement_progress` VALUES ('6', '844', '75', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '34', '6', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5374', '3', '1290753226');
INSERT INTO `character_achievement_progress` VALUES ('6', '3513', '1365', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '8822', '500', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '231', '21', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '39', '6', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '9598', '6', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '8821', '500', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '6755', '6', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '9685', '7605', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5301', '6', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '236', '21', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '149', '1', '1290827988');
INSERT INTO `character_achievement_progress` VALUES ('6', '8820', '500', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5315', '1391', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '995', '1391', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '2020', '200', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '1884', '3500', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '1508', '1', '1290502447');
INSERT INTO `character_achievement_progress` VALUES ('6', '6394', '2', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '5562', '1', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '1509', '1', '1290828299');
INSERT INTO `character_achievement_progress` VALUES ('6', '5242', '1', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '8819', '500', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '755', '30', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '4763', '3500', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '35', '6', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '5589', '30', '1290502430');
INSERT INTO `character_achievement_progress` VALUES ('6', '3511', '264', '1290827749');
INSERT INTO `character_achievement_progress` VALUES ('6', '1512', '1', '1290959319');
INSERT INTO `character_achievement_progress` VALUES ('6', '840', '75', '1290831428');
INSERT INTO `character_achievement_progress` VALUES ('6', '232', '21', '1290611653');
INSERT INTO `character_achievement_progress` VALUES ('6', '168', '75', '1290831438');
INSERT INTO `character_achievement_progress` VALUES ('6', '40', '6', '1290502430');

-- ----------------------------
-- Table structure for `character_action`
-- ----------------------------
DROP TABLE IF EXISTS `character_action`;
CREATE TABLE `character_action` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `spec` tinyint(3) unsigned NOT NULL default '0',
  `button` tinyint(3) unsigned NOT NULL default '0',
  `action` int(11) unsigned NOT NULL default '0',
  `type` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`spec`,`button`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_action
-- ----------------------------
INSERT INTO `character_action` VALUES ('11', '0', '10', '26297', '0');
INSERT INTO `character_action` VALUES ('11', '0', '5', '47541', '0');
INSERT INTO `character_action` VALUES ('11', '0', '4', '45902', '0');
INSERT INTO `character_action` VALUES ('11', '0', '3', '45462', '0');
INSERT INTO `character_action` VALUES ('11', '0', '2', '45477', '0');
INSERT INTO `character_action` VALUES ('11', '0', '1', '49576', '0');
INSERT INTO `character_action` VALUES ('9', '0', '6', '1', '64');
INSERT INTO `character_action` VALUES ('9', '0', '4', '45902', '0');
INSERT INTO `character_action` VALUES ('9', '0', '5', '47541', '0');
INSERT INTO `character_action` VALUES ('9', '0', '10', '20577', '0');
INSERT INTO `character_action` VALUES ('6', '0', '5', '20271', '0');
INSERT INTO `character_action` VALUES ('6', '0', '4', '21084', '0');
INSERT INTO `character_action` VALUES ('11', '0', '0', '6603', '0');
INSERT INTO `character_action` VALUES ('6', '0', '3', '28730', '0');
INSERT INTO `character_action` VALUES ('6', '0', '1', '19740', '0');
INSERT INTO `character_action` VALUES ('9', '0', '3', '45462', '0');
INSERT INTO `character_action` VALUES ('6', '0', '2', '635', '0');
INSERT INTO `character_action` VALUES ('10', '0', '2', '2050', '0');
INSERT INTO `character_action` VALUES ('6', '0', '0', '6603', '0');
INSERT INTO `character_action` VALUES ('10', '0', '3', '28730', '0');
INSERT INTO `character_action` VALUES ('10', '0', '11', '20857', '128');
INSERT INTO `character_action` VALUES ('9', '0', '7', '2', '64');
INSERT INTO `character_action` VALUES ('9', '0', '8', '5', '64');
INSERT INTO `character_action` VALUES ('9', '0', '9', '4', '64');
INSERT INTO `character_action` VALUES ('9', '0', '11', '3', '64');
INSERT INTO `character_action` VALUES ('7', '0', '0', '6603', '0');
INSERT INTO `character_action` VALUES ('7', '0', '1', '49576', '0');
INSERT INTO `character_action` VALUES ('7', '0', '2', '45477', '0');
INSERT INTO `character_action` VALUES ('7', '0', '3', '45462', '0');
INSERT INTO `character_action` VALUES ('7', '0', '4', '45902', '0');
INSERT INTO `character_action` VALUES ('7', '0', '5', '47541', '0');
INSERT INTO `character_action` VALUES ('7', '0', '11', '59752', '0');
INSERT INTO `character_action` VALUES ('7', '0', '6', '2', '64');
INSERT INTO `character_action` VALUES ('7', '0', '7', '1', '64');
INSERT INTO `character_action` VALUES ('7', '0', '8', '5', '64');
INSERT INTO `character_action` VALUES ('7', '0', '9', '3', '64');
INSERT INTO `character_action` VALUES ('7', '0', '10', '4', '64');
INSERT INTO `character_action` VALUES ('10', '0', '1', '585', '0');
INSERT INTO `character_action` VALUES ('9', '0', '2', '45477', '0');
INSERT INTO `character_action` VALUES ('9', '0', '1', '49576', '0');
INSERT INTO `character_action` VALUES ('9', '0', '0', '6603', '0');
INSERT INTO `character_action` VALUES ('10', '0', '0', '6603', '0');

-- ----------------------------
-- Table structure for `character_aura`
-- ----------------------------
DROP TABLE IF EXISTS `character_aura`;
CREATE TABLE `character_aura` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `caster_guid` bigint(20) unsigned NOT NULL default '0' COMMENT 'Full Global Unique Identifier',
  `item_guid` int(11) unsigned NOT NULL default '0',
  `spell` int(11) unsigned NOT NULL default '0',
  `stackcount` int(11) NOT NULL default '1',
  `remaincharges` int(11) NOT NULL default '0',
  `basepoints0` int(11) NOT NULL default '0',
  `basepoints1` int(11) NOT NULL default '0',
  `basepoints2` int(11) NOT NULL default '0',
  `maxduration0` int(11) NOT NULL default '0',
  `maxduration1` int(11) NOT NULL default '0',
  `maxduration2` int(11) NOT NULL default '0',
  `remaintime0` int(11) NOT NULL default '0',
  `remaintime1` int(11) NOT NULL default '0',
  `remaintime2` int(11) NOT NULL default '0',
  `effIndexMask` int(11) NOT NULL default '0',
  PRIMARY KEY  (`guid`,`caster_guid`,`item_guid`,`spell`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_aura
-- ----------------------------
INSERT INTO `character_aura` VALUES ('7', '17379391045053226171', '0', '29584', '1', '0', '-300', '0', '0', '20000', '0', '0', '13600', '0', '0', '1');
INSERT INTO `character_aura` VALUES ('6', '6', '0', '63531', '0', '0', '0', '0', '0', '0', '-1', '-1', '0', '-1', '-1', '6');
INSERT INTO `character_aura` VALUES ('10', '10', '0', '51915', '1', '0', '0', '0', '0', '-1', '0', '0', '-1', '0', '0', '1');
INSERT INTO `character_aura` VALUES ('6', '6', '0', '63514', '0', '0', '0', '0', '0', '0', '-1', '0', '0', '-1', '0', '2');
INSERT INTO `character_aura` VALUES ('6', '6', '0', '63510', '0', '0', '0', '0', '0', '0', '-1', '-1', '0', '-1', '-1', '6');
INSERT INTO `character_aura` VALUES ('6', '6', '0', '21084', '1', '0', '0', '0', '20187', '1800000', '1800000', '1800000', '1487700', '1487700', '1487700', '7');
INSERT INTO `character_aura` VALUES ('6', '6', '0', '19740', '1', '0', '20', '20', '0', '600000', '600000', '0', '285800', '285800', '0', '3');
INSERT INTO `character_aura` VALUES ('6', '6', '0', '465', '0', '0', '55', '0', '0', '-1', '0', '0', '-1', '0', '0', '1');
INSERT INTO `character_aura` VALUES ('9', '9', '0', '63611', '0', '0', '0', '4', '0', '0', '-1', '0', '0', '-1', '0', '2');
INSERT INTO `character_aura` VALUES ('9', '9', '0', '48266', '0', '0', '15', '0', '-28', '-1', '-1', '-1', '-1', '-1', '-1', '7');
INSERT INTO `character_aura` VALUES ('9', '9', '0', '2479', '1', '0', '1', '0', '0', '30000', '0', '0', '21156', '0', '0', '1');

-- ----------------------------
-- Table structure for `character_battleground_data`
-- ----------------------------
DROP TABLE IF EXISTS `character_battleground_data`;
CREATE TABLE `character_battleground_data` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `instance_id` int(11) unsigned NOT NULL default '0',
  `team` int(11) unsigned NOT NULL default '0',
  `join_x` float NOT NULL default '0',
  `join_y` float NOT NULL default '0',
  `join_z` float NOT NULL default '0',
  `join_o` float NOT NULL default '0',
  `join_map` int(11) NOT NULL default '0',
  `taxi_start` int(11) NOT NULL default '0',
  `taxi_end` int(11) NOT NULL default '0',
  `mount_spell` int(11) NOT NULL default '0',
  PRIMARY KEY  (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_battleground_data
-- ----------------------------

-- ----------------------------
-- Table structure for `character_battleground_random`
-- ----------------------------
DROP TABLE IF EXISTS `character_battleground_random`;
CREATE TABLE `character_battleground_random` (
  `guid` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_battleground_random
-- ----------------------------

-- ----------------------------
-- Table structure for `character_db_version`
-- ----------------------------
DROP TABLE IF EXISTS `character_db_version`;
CREATE TABLE `character_db_version` (
  `required_10664_01_characters_arena_team_stats` bit(1) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='Last applied sql update to DB';

-- ----------------------------
-- Records of character_db_version
-- ----------------------------
INSERT INTO `character_db_version` VALUES (null);

-- ----------------------------
-- Table structure for `character_declinedname`
-- ----------------------------
DROP TABLE IF EXISTS `character_declinedname`;
CREATE TABLE `character_declinedname` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `genitive` varchar(15) NOT NULL default '',
  `dative` varchar(15) NOT NULL default '',
  `accusative` varchar(15) NOT NULL default '',
  `instrumental` varchar(15) NOT NULL default '',
  `prepositional` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of character_declinedname
-- ----------------------------

-- ----------------------------
-- Table structure for `character_equipmentsets`
-- ----------------------------
DROP TABLE IF EXISTS `character_equipmentsets`;
CREATE TABLE `character_equipmentsets` (
  `guid` int(11) NOT NULL default '0',
  `setguid` bigint(20) NOT NULL auto_increment,
  `setindex` tinyint(4) NOT NULL default '0',
  `name` varchar(100) NOT NULL,
  `iconname` varchar(100) NOT NULL,
  `item0` int(11) NOT NULL default '0',
  `item1` int(11) NOT NULL default '0',
  `item2` int(11) NOT NULL default '0',
  `item3` int(11) NOT NULL default '0',
  `item4` int(11) NOT NULL default '0',
  `item5` int(11) NOT NULL default '0',
  `item6` int(11) NOT NULL default '0',
  `item7` int(11) NOT NULL default '0',
  `item8` int(11) NOT NULL default '0',
  `item9` int(11) NOT NULL default '0',
  `item10` int(11) NOT NULL default '0',
  `item11` int(11) NOT NULL default '0',
  `item12` int(11) NOT NULL default '0',
  `item13` int(11) NOT NULL default '0',
  `item14` int(11) NOT NULL default '0',
  `item15` int(11) NOT NULL default '0',
  `item16` int(11) NOT NULL default '0',
  `item17` int(11) NOT NULL default '0',
  `item18` int(11) NOT NULL default '0',
  PRIMARY KEY  (`setguid`),
  UNIQUE KEY `idx_set` (`guid`,`setguid`,`setindex`),
  KEY `Idx_setindex` (`setindex`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_equipmentsets
-- ----------------------------

-- ----------------------------
-- Table structure for `character_feed_log`
-- ----------------------------
DROP TABLE IF EXISTS `character_feed_log`;
CREATE TABLE `character_feed_log` (
  `guid` int(11) NOT NULL,
  `type` smallint(1) NOT NULL,
  `data` int(11) NOT NULL,
  `date` int(11) default NULL,
  `counter` int(11) NOT NULL,
  `difficulty` smallint(6) default '-1',
  `item_guid` int(11) NOT NULL,
  PRIMARY KEY  (`guid`,`type`,`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_feed_log
-- ----------------------------

-- ----------------------------
-- Table structure for `character_gifts`
-- ----------------------------
DROP TABLE IF EXISTS `character_gifts`;
CREATE TABLE `character_gifts` (
  `guid` int(20) unsigned NOT NULL default '0',
  `item_guid` int(11) unsigned NOT NULL default '0',
  `entry` int(20) unsigned NOT NULL default '0',
  `flags` int(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (`item_guid`),
  KEY `idx_guid` (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_gifts
-- ----------------------------

-- ----------------------------
-- Table structure for `character_glyphs`
-- ----------------------------
DROP TABLE IF EXISTS `character_glyphs`;
CREATE TABLE `character_glyphs` (
  `guid` int(11) unsigned NOT NULL,
  `spec` tinyint(3) unsigned NOT NULL default '0',
  `slot` tinyint(3) unsigned NOT NULL default '0',
  `glyph` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`spec`,`slot`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_glyphs
-- ----------------------------

-- ----------------------------
-- Table structure for `character_homebind`
-- ----------------------------
DROP TABLE IF EXISTS `character_homebind`;
CREATE TABLE `character_homebind` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `map` int(11) unsigned NOT NULL default '0' COMMENT 'Map Identifier',
  `zone` int(11) unsigned NOT NULL default '0' COMMENT 'Zone Identifier',
  `position_x` float NOT NULL default '0',
  `position_y` float NOT NULL default '0',
  `position_z` float NOT NULL default '0',
  PRIMARY KEY  (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_homebind
-- ----------------------------
INSERT INTO `character_homebind` VALUES ('9', '609', '4298', '2356.21', '-5662.21', '426.026');
INSERT INTO `character_homebind` VALUES ('6', '530', '3665', '9478.2', '-6858.35', '17.372');
INSERT INTO `character_homebind` VALUES ('11', '609', '4298', '2355.05', '-5661.7', '426.026');
INSERT INTO `character_homebind` VALUES ('7', '609', '4298', '2355.84', '-5664.77', '426.028');
INSERT INTO `character_homebind` VALUES ('10', '530', '3431', '10349.6', '-6357.29', '33.4026');
INSERT INTO `character_homebind` VALUES ('2', '0', '1', '-6240', '331', '383');

-- ----------------------------
-- Table structure for `character_instance`
-- ----------------------------
DROP TABLE IF EXISTS `character_instance`;
CREATE TABLE `character_instance` (
  `guid` int(11) unsigned NOT NULL default '0',
  `instance` int(11) unsigned NOT NULL default '0',
  `permanent` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`instance`),
  KEY `instance` (`instance`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_instance
-- ----------------------------
INSERT INTO `character_instance` VALUES ('9', '1', '0');
INSERT INTO `character_instance` VALUES ('9', '2', '0');

-- ----------------------------
-- Table structure for `character_inventory`
-- ----------------------------
DROP TABLE IF EXISTS `character_inventory`;
CREATE TABLE `character_inventory` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `bag` int(11) unsigned NOT NULL default '0',
  `slot` tinyint(3) unsigned NOT NULL default '0',
  `item` int(11) unsigned NOT NULL default '0' COMMENT 'Item Global Unique Identifier',
  `item_template` int(11) unsigned NOT NULL default '0' COMMENT 'Item Identifier',
  PRIMARY KEY  (`item`),
  KEY `idx_guid` (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_inventory
-- ----------------------------
INSERT INTO `character_inventory` VALUES ('2', '0', '4', '36', '56');
INSERT INTO `character_inventory` VALUES ('11', '0', '22', '21618', '38145');
INSERT INTO `character_inventory` VALUES ('2', '0', '7', '42', '55');
INSERT INTO `character_inventory` VALUES ('2', '0', '15', '44', '35');
INSERT INTO `character_inventory` VALUES ('2', '0', '23', '46', '6948');
INSERT INTO `character_inventory` VALUES ('6', '0', '26', '17683', '23354');
INSERT INTO `character_inventory` VALUES ('6', '0', '21', '13504', '4496');
INSERT INTO `character_inventory` VALUES ('9', '0', '1', '11051', '34657');
INSERT INTO `character_inventory` VALUES ('11', '0', '21', '21616', '38145');
INSERT INTO `character_inventory` VALUES ('7', '0', '24', '9874', '40582');
INSERT INTO `character_inventory` VALUES ('9', '0', '9', '11043', '34649');
INSERT INTO `character_inventory` VALUES ('11', '0', '20', '21614', '38145');
INSERT INTO `character_inventory` VALUES ('11', '0', '19', '21612', '38145');
INSERT INTO `character_inventory` VALUES ('7', '0', '23', '9872', '41751');
INSERT INTO `character_inventory` VALUES ('7', '0', '11', '9870', '38147');
INSERT INTO `character_inventory` VALUES ('6', '0', '6', '5435', '21013');
INSERT INTO `character_inventory` VALUES ('7', '0', '8', '358', '34653');
INSERT INTO `character_inventory` VALUES ('7', '0', '9', '360', '34649');
INSERT INTO `character_inventory` VALUES ('6', '0', '23', '630', '6948');
INSERT INTO `character_inventory` VALUES ('11', '0', '10', '21610', '34658');
INSERT INTO `character_inventory` VALUES ('11', '0', '1', '21608', '34657');
INSERT INTO `character_inventory` VALUES ('7', '0', '23', '382', '41751');
INSERT INTO `character_inventory` VALUES ('7', '0', '0', '350', '34652');
INSERT INTO `character_inventory` VALUES ('6', '0', '3', '622', '24143');
INSERT INTO `character_inventory` VALUES ('9', '0', '23', '11065', '41751');
INSERT INTO `character_inventory` VALUES ('9', '0', '11', '11063', '38147');
INSERT INTO `character_inventory` VALUES ('9', '0', '22', '11061', '38145');
INSERT INTO `character_inventory` VALUES ('9', '0', '21', '11059', '38145');
INSERT INTO `character_inventory` VALUES ('9', '0', '20', '11057', '38145');
INSERT INTO `character_inventory` VALUES ('9', '0', '19', '11055', '38145');
INSERT INTO `character_inventory` VALUES ('11', '0', '7', '21606', '34648');
INSERT INTO `character_inventory` VALUES ('11', '0', '6', '21604', '34656');
INSERT INTO `character_inventory` VALUES ('7', '0', '14', '354', '34659');
INSERT INTO `character_inventory` VALUES ('11', '0', '5', '21602', '34651');
INSERT INTO `character_inventory` VALUES ('11', '0', '9', '21600', '34649');
INSERT INTO `character_inventory` VALUES ('7', '0', '20', '374', '38145');
INSERT INTO `character_inventory` VALUES ('6', '0', '16', '10296', '20841');
INSERT INTO `character_inventory` VALUES ('7', '0', '21', '376', '38145');
INSERT INTO `character_inventory` VALUES ('7', '0', '22', '378', '38145');
INSERT INTO `character_inventory` VALUES ('11', '0', '8', '21598', '34653');
INSERT INTO `character_inventory` VALUES ('7', '0', '11', '380', '38147');
INSERT INTO `character_inventory` VALUES ('11', '0', '4', '21596', '34650');
INSERT INTO `character_inventory` VALUES ('7', '0', '5', '362', '34651');
INSERT INTO `character_inventory` VALUES ('7', '0', '6', '364', '34656');
INSERT INTO `character_inventory` VALUES ('7', '0', '4', '356', '34650');
INSERT INTO `character_inventory` VALUES ('6', '0', '24', '10500', '159');
INSERT INTO `character_inventory` VALUES ('6', '0', '7', '10284', '21020');
INSERT INTO `character_inventory` VALUES ('11', '0', '14', '21594', '34659');
INSERT INTO `character_inventory` VALUES ('7', '0', '7', '366', '34648');
INSERT INTO `character_inventory` VALUES ('7', '0', '1', '368', '34657');
INSERT INTO `character_inventory` VALUES ('7', '0', '10', '370', '34658');
INSERT INTO `character_inventory` VALUES ('7', '0', '2', '352', '34655');
INSERT INTO `character_inventory` VALUES ('6', '0', '20', '10279', '4496');
INSERT INTO `character_inventory` VALUES ('7', '0', '19', '372', '38145');
INSERT INTO `character_inventory` VALUES ('9', '0', '7', '11049', '34648');
INSERT INTO `character_inventory` VALUES ('11', '0', '2', '21592', '34655');
INSERT INTO `character_inventory` VALUES ('11', '0', '0', '21590', '34652');
INSERT INTO `character_inventory` VALUES ('9', '0', '14', '11037', '34659');
INSERT INTO `character_inventory` VALUES ('10', '0', '23', '19788', '6948');
INSERT INTO `character_inventory` VALUES ('10', '0', '7', '19786', '51');
INSERT INTO `character_inventory` VALUES ('10', '0', '15', '19784', '20978');
INSERT INTO `character_inventory` VALUES ('9', '0', '10', '11053', '34658');
INSERT INTO `character_inventory` VALUES ('10', '0', '6', '19782', '52');
INSERT INTO `character_inventory` VALUES ('10', '0', '3', '19780', '53');
INSERT INTO `character_inventory` VALUES ('10', '0', '4', '19778', '20891');
INSERT INTO `character_inventory` VALUES ('9', '0', '5', '11045', '34651');
INSERT INTO `character_inventory` VALUES ('9', '0', '0', '11033', '34652');
INSERT INTO `character_inventory` VALUES ('9', '0', '2', '11035', '34655');
INSERT INTO `character_inventory` VALUES ('6', '0', '31', '17688', '1414');
INSERT INTO `character_inventory` VALUES ('6', '0', '30', '17687', '2589');
INSERT INTO `character_inventory` VALUES ('6', '0', '29', '17686', '20765');
INSERT INTO `character_inventory` VALUES ('6', '0', '28', '17685', '1377');
INSERT INTO `character_inventory` VALUES ('6', '0', '27', '17684', '2653');
INSERT INTO `character_inventory` VALUES ('6', '0', '25', '13505', '23353');
INSERT INTO `character_inventory` VALUES ('6', '0', '15', '13503', '2488');
INSERT INTO `character_inventory` VALUES ('9', '0', '6', '11047', '34656');
INSERT INTO `character_inventory` VALUES ('2', '0', '3', '500', '49');
INSERT INTO `character_inventory` VALUES ('2', '0', '6', '502', '48');
INSERT INTO `character_inventory` VALUES ('7', '0', '22', '9868', '38145');
INSERT INTO `character_inventory` VALUES ('7', '0', '21', '9866', '38145');
INSERT INTO `character_inventory` VALUES ('7', '0', '20', '9864', '38145');
INSERT INTO `character_inventory` VALUES ('2', '0', '17', '510', '28979');
INSERT INTO `character_inventory` VALUES ('7', '0', '19', '9862', '38145');
INSERT INTO `character_inventory` VALUES ('7', '0', '10', '9860', '34658');
INSERT INTO `character_inventory` VALUES ('7', '0', '1', '9858', '34657');
INSERT INTO `character_inventory` VALUES ('7', '0', '7', '9856', '34648');
INSERT INTO `character_inventory` VALUES ('7', '0', '6', '9854', '34656');
INSERT INTO `character_inventory` VALUES ('7', '0', '5', '9852', '34651');
INSERT INTO `character_inventory` VALUES ('7', '0', '9', '9850', '34649');
INSERT INTO `character_inventory` VALUES ('7', '0', '8', '9848', '34653');
INSERT INTO `character_inventory` VALUES ('7', '0', '4', '9846', '34650');
INSERT INTO `character_inventory` VALUES ('7', '0', '14', '9844', '34659');
INSERT INTO `character_inventory` VALUES ('7', '0', '2', '9842', '34655');
INSERT INTO `character_inventory` VALUES ('7', '0', '0', '9840', '34652');
INSERT INTO `character_inventory` VALUES ('6', '0', '4', '7885', '20994');
INSERT INTO `character_inventory` VALUES ('11', '0', '24', '21624', '40582');
INSERT INTO `character_inventory` VALUES ('11', '0', '23', '21622', '41751');
INSERT INTO `character_inventory` VALUES ('11', '0', '11', '21620', '38147');
INSERT INTO `character_inventory` VALUES ('6', '0', '19', '7855', '20474');
INSERT INTO `character_inventory` VALUES ('9', '0', '8', '11041', '34653');
INSERT INTO `character_inventory` VALUES ('6', '0', '5', '13501', '24241');
INSERT INTO `character_inventory` VALUES ('6', '0', '9', '7889', '20999');
INSERT INTO `character_inventory` VALUES ('6', '0', '14', '7912', '20991');
INSERT INTO `character_inventory` VALUES ('9', '0', '4', '11039', '34650');

-- ----------------------------
-- Table structure for `character_pet`
-- ----------------------------
DROP TABLE IF EXISTS `character_pet`;
CREATE TABLE `character_pet` (
  `id` int(11) unsigned NOT NULL default '0',
  `entry` int(11) unsigned NOT NULL default '0',
  `owner` int(11) unsigned NOT NULL default '0',
  `modelid` int(11) unsigned default '0',
  `CreatedBySpell` int(11) unsigned NOT NULL default '0',
  `PetType` tinyint(3) unsigned NOT NULL default '0',
  `level` int(11) unsigned NOT NULL default '1',
  `exp` int(11) unsigned NOT NULL default '0',
  `Reactstate` tinyint(1) unsigned NOT NULL default '0',
  `name` varchar(100) default 'Pet',
  `renamed` tinyint(1) unsigned NOT NULL default '0',
  `slot` int(11) unsigned NOT NULL default '0',
  `curhealth` int(11) unsigned NOT NULL default '1',
  `curmana` int(11) unsigned NOT NULL default '0',
  `curhappiness` int(11) unsigned NOT NULL default '0',
  `savetime` bigint(20) unsigned NOT NULL default '0',
  `resettalents_cost` int(11) unsigned NOT NULL default '0',
  `resettalents_time` bigint(20) unsigned NOT NULL default '0',
  `abdata` longtext,
  PRIMARY KEY  (`id`),
  KEY `owner` (`owner`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Pet System';

-- ----------------------------
-- Records of character_pet
-- ----------------------------

-- ----------------------------
-- Table structure for `character_pet_declinedname`
-- ----------------------------
DROP TABLE IF EXISTS `character_pet_declinedname`;
CREATE TABLE `character_pet_declinedname` (
  `id` int(11) unsigned NOT NULL default '0',
  `owner` int(11) unsigned NOT NULL default '0',
  `genitive` varchar(12) NOT NULL default '',
  `dative` varchar(12) NOT NULL default '',
  `accusative` varchar(12) NOT NULL default '',
  `instrumental` varchar(12) NOT NULL default '',
  `prepositional` varchar(12) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `owner_key` (`owner`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of character_pet_declinedname
-- ----------------------------

-- ----------------------------
-- Table structure for `character_queststatus`
-- ----------------------------
DROP TABLE IF EXISTS `character_queststatus`;
CREATE TABLE `character_queststatus` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `quest` int(11) unsigned NOT NULL default '0' COMMENT 'Quest Identifier',
  `status` int(11) unsigned NOT NULL default '0',
  `rewarded` tinyint(1) unsigned NOT NULL default '0',
  `explored` tinyint(1) unsigned NOT NULL default '0',
  `timer` bigint(20) unsigned NOT NULL default '0',
  `mobcount1` int(11) unsigned NOT NULL default '0',
  `mobcount2` int(11) unsigned NOT NULL default '0',
  `mobcount3` int(11) unsigned NOT NULL default '0',
  `mobcount4` int(11) unsigned NOT NULL default '0',
  `itemcount1` int(11) unsigned NOT NULL default '0',
  `itemcount2` int(11) unsigned NOT NULL default '0',
  `itemcount3` int(11) unsigned NOT NULL default '0',
  `itemcount4` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`quest`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_queststatus
-- ----------------------------
INSERT INTO `character_queststatus` VALUES ('6', '9705', '1', '1', '0', '1290828900', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9704', '1', '1', '0', '1290828900', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8350', '1', '1', '0', '1290832144', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8347', '1', '1', '0', '1290828900', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8338', '1', '1', '0', '1290828900', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8335', '1', '1', '0', '1290828900', '8', '2', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8334', '1', '1', '0', '1290827822', '7', '7', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8346', '1', '1', '0', '1290753393', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8345', '1', '1', '0', '1290753393', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8330', '1', '1', '0', '1290753393', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '10069', '1', '1', '0', '1290747446', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9676', '1', '1', '0', '1290612331', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8336', '1', '1', '0', '1290753616', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8327', '1', '1', '0', '1290753616', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8326', '1', '1', '0', '1290753393', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8325', '1', '1', '0', '1290612331', '8', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8463', '1', '1', '0', '1290959548', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('9', '12619', '3', '0', '0', '1291598745', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('9', '12593', '1', '1', '0', '1291598745', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8486', '3', '0', '0', '1291468091', '2', '2', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9352', '1', '0', '0', '1291468091', '1', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8895', '1', '1', '0', '1290959548', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '9119', '1', '1', '0', '1290960448', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8472', '1', '1', '0', '1290959548', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_queststatus` VALUES ('6', '8468', '1', '1', '0', '1290959548', '0', '0', '0', '0', '0', '0', '0', '0');

-- ----------------------------
-- Table structure for `character_queststatus_daily`
-- ----------------------------
DROP TABLE IF EXISTS `character_queststatus_daily`;
CREATE TABLE `character_queststatus_daily` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `quest` int(11) unsigned NOT NULL default '0' COMMENT 'Quest Identifier',
  PRIMARY KEY  (`guid`,`quest`),
  KEY `idx_guid` (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_queststatus_daily
-- ----------------------------

-- ----------------------------
-- Table structure for `character_queststatus_monthly`
-- ----------------------------
DROP TABLE IF EXISTS `character_queststatus_monthly`;
CREATE TABLE `character_queststatus_monthly` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `quest` int(11) unsigned NOT NULL default '0' COMMENT 'Quest Identifier',
  PRIMARY KEY  (`guid`,`quest`),
  KEY `idx_guid` (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_queststatus_monthly
-- ----------------------------

-- ----------------------------
-- Table structure for `character_queststatus_weekly`
-- ----------------------------
DROP TABLE IF EXISTS `character_queststatus_weekly`;
CREATE TABLE `character_queststatus_weekly` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `quest` int(11) unsigned NOT NULL default '0' COMMENT 'Quest Identifier',
  PRIMARY KEY  (`guid`,`quest`),
  KEY `idx_guid` (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_queststatus_weekly
-- ----------------------------

-- ----------------------------
-- Table structure for `character_reputation`
-- ----------------------------
DROP TABLE IF EXISTS `character_reputation`;
CREATE TABLE `character_reputation` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `faction` int(11) unsigned NOT NULL default '0',
  `standing` int(11) NOT NULL default '0',
  `flags` int(11) NOT NULL default '0',
  PRIMARY KEY  (`guid`,`faction`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_reputation
-- ----------------------------
INSERT INTO `character_reputation` VALUES ('9', '1156', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1155', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '1154', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '1137', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '1136', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '1126', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '1124', '25', '17');
INSERT INTO `character_reputation` VALUES ('9', '1119', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '1118', '0', '12');
INSERT INTO `character_reputation` VALUES ('9', '1117', '0', '12');
INSERT INTO `character_reputation` VALUES ('9', '1106', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1105', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1104', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1098', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1094', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '1097', '0', '12');
INSERT INTO `character_reputation` VALUES ('9', '1037', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '952', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '948', '0', '8');
INSERT INTO `character_reputation` VALUES ('9', '949', '0', '24');
INSERT INTO `character_reputation` VALUES ('9', '1090', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1091', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1082', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '1085', '25', '17');
INSERT INTO `character_reputation` VALUES ('9', '1077', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1073', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1068', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '1067', '25', '17');
INSERT INTO `character_reputation` VALUES ('9', '1064', '25', '17');
INSERT INTO `character_reputation` VALUES ('9', '1052', '50', '152');
INSERT INTO `character_reputation` VALUES ('9', '1050', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '1038', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1031', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1015', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '1012', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1011', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '1005', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '989', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '978', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '970', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '942', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '967', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '934', '0', '80');
INSERT INTO `character_reputation` VALUES ('9', '941', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '933', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '936', '0', '28');
INSERT INTO `character_reputation` VALUES ('9', '932', '0', '80');
INSERT INTO `character_reputation` VALUES ('9', '990', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '922', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '911', '0', '17');
INSERT INTO `character_reputation` VALUES ('9', '910', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '509', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '510', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '270', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '909', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '930', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '892', '0', '24');
INSERT INTO `character_reputation` VALUES ('9', '891', '0', '14');
INSERT INTO `character_reputation` VALUES ('9', '889', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '890', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '809', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '980', '0', '24');
INSERT INTO `character_reputation` VALUES ('9', '749', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '729', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '730', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '935', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '946', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '947', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '609', '0', '1');
INSERT INTO `character_reputation` VALUES ('9', '576', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '574', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '569', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '571', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '570', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '289', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '46', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '577', '0', '64');
INSERT INTO `character_reputation` VALUES ('9', '589', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '550', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '551', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '549', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '83', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '86', '0', '4');
INSERT INTO `character_reputation` VALUES ('9', '69', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '47', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '72', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '54', '0', '6');
INSERT INTO `character_reputation` VALUES ('9', '68', '0', '17');
INSERT INTO `character_reputation` VALUES ('9', '81', '0', '17');
INSERT INTO `character_reputation` VALUES ('9', '530', '0', '17');
INSERT INTO `character_reputation` VALUES ('9', '76', '0', '17');
INSERT INTO `character_reputation` VALUES ('9', '529', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '67', '0', '25');
INSERT INTO `character_reputation` VALUES ('9', '469', '0', '14');
INSERT INTO `character_reputation` VALUES ('9', '169', '0', '12');
INSERT INTO `character_reputation` VALUES ('9', '470', '0', '64');
INSERT INTO `character_reputation` VALUES ('9', '471', '0', '22');
INSERT INTO `character_reputation` VALUES ('9', '369', '0', '64');
INSERT INTO `character_reputation` VALUES ('9', '70', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '349', '0', '0');
INSERT INTO `character_reputation` VALUES ('9', '59', '0', '16');
INSERT INTO `character_reputation` VALUES ('9', '93', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '92', '0', '2');
INSERT INTO `character_reputation` VALUES ('9', '21', '0', '64');
INSERT INTO `character_reputation` VALUES ('9', '87', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '729', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '730', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '935', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '947', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '609', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '574', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '576', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '571', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '589', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '577', '0', '64');
INSERT INTO `character_reputation` VALUES ('6', '46', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '289', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '570', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '550', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '551', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '47', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '946', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '549', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '83', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '86', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '69', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '72', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '369', '0', '64');
INSERT INTO `character_reputation` VALUES ('6', '471', '0', '22');
INSERT INTO `character_reputation` VALUES ('6', '470', '0', '64');
INSERT INTO `character_reputation` VALUES ('6', '93', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '54', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '68', '891', '17');
INSERT INTO `character_reputation` VALUES ('6', '81', '891', '17');
INSERT INTO `character_reputation` VALUES ('6', '67', '0', '25');
INSERT INTO `character_reputation` VALUES ('6', '569', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '530', '891', '17');
INSERT INTO `character_reputation` VALUES ('6', '76', '891', '17');
INSERT INTO `character_reputation` VALUES ('6', '529', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '21', '0', '64');
INSERT INTO `character_reputation` VALUES ('6', '469', '0', '14');
INSERT INTO `character_reputation` VALUES ('6', '169', '0', '12');
INSERT INTO `character_reputation` VALUES ('6', '70', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '349', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '59', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '92', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '87', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '87', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '21', '0', '64');
INSERT INTO `character_reputation` VALUES ('7', '92', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '93', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '59', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '349', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '70', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '369', '0', '64');
INSERT INTO `character_reputation` VALUES ('7', '471', '0', '20');
INSERT INTO `character_reputation` VALUES ('7', '470', '0', '64');
INSERT INTO `character_reputation` VALUES ('7', '169', '0', '12');
INSERT INTO `character_reputation` VALUES ('7', '469', '0', '25');
INSERT INTO `character_reputation` VALUES ('7', '67', '0', '14');
INSERT INTO `character_reputation` VALUES ('7', '529', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '76', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '530', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '81', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '68', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '54', '0', '273');
INSERT INTO `character_reputation` VALUES ('7', '72', '0', '17');
INSERT INTO `character_reputation` VALUES ('7', '47', '0', '273');
INSERT INTO `character_reputation` VALUES ('7', '69', '0', '273');
INSERT INTO `character_reputation` VALUES ('7', '86', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '83', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '549', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '551', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '550', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '589', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '577', '0', '64');
INSERT INTO `character_reputation` VALUES ('7', '46', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '289', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '570', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '571', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '569', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '574', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '576', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '609', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '947', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '946', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '935', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '730', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '729', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '749', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '980', '0', '24');
INSERT INTO `character_reputation` VALUES ('7', '809', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '890', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '889', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '891', '0', '24');
INSERT INTO `character_reputation` VALUES ('7', '892', '0', '14');
INSERT INTO `character_reputation` VALUES ('7', '930', '0', '273');
INSERT INTO `character_reputation` VALUES ('7', '909', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '270', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '510', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '509', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '910', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '911', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '922', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '990', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '932', '0', '80');
INSERT INTO `character_reputation` VALUES ('7', '936', '0', '28');
INSERT INTO `character_reputation` VALUES ('7', '933', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '941', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '934', '0', '80');
INSERT INTO `character_reputation` VALUES ('7', '967', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '942', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '970', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '978', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '989', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1005', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '1011', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1012', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1015', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '1031', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1038', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1050', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1052', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '1064', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '1067', '0', '3');
INSERT INTO `character_reputation` VALUES ('7', '1068', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1073', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1077', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1085', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '1082', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '1091', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1090', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '949', '0', '24');
INSERT INTO `character_reputation` VALUES ('7', '948', '0', '8');
INSERT INTO `character_reputation` VALUES ('7', '952', '0', '0');
INSERT INTO `character_reputation` VALUES ('7', '1037', '0', '136');
INSERT INTO `character_reputation` VALUES ('7', '1097', '0', '12');
INSERT INTO `character_reputation` VALUES ('7', '1094', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1098', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1104', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1105', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1106', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1117', '0', '12');
INSERT INTO `character_reputation` VALUES ('7', '1118', '0', '12');
INSERT INTO `character_reputation` VALUES ('7', '1119', '0', '2');
INSERT INTO `character_reputation` VALUES ('7', '1124', '0', '6');
INSERT INTO `character_reputation` VALUES ('7', '1126', '0', '16');
INSERT INTO `character_reputation` VALUES ('7', '1136', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '1137', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '1154', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '1155', '0', '4');
INSERT INTO `character_reputation` VALUES ('7', '1156', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '1156', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '1155', '0', '4');
INSERT INTO `character_reputation` VALUES ('10', '1154', '0', '4');
INSERT INTO `character_reputation` VALUES ('10', '1137', '0', '4');
INSERT INTO `character_reputation` VALUES ('10', '1136', '0', '4');
INSERT INTO `character_reputation` VALUES ('10', '1126', '0', '0');
INSERT INTO `character_reputation` VALUES ('10', '1124', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '1119', '0', '0');
INSERT INTO `character_reputation` VALUES ('10', '1118', '0', '12');
INSERT INTO `character_reputation` VALUES ('10', '1117', '0', '12');
INSERT INTO `character_reputation` VALUES ('10', '1106', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '1105', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '1104', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '1098', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '1094', '0', '6');
INSERT INTO `character_reputation` VALUES ('10', '1097', '0', '12');
INSERT INTO `character_reputation` VALUES ('10', '1037', '0', '6');
INSERT INTO `character_reputation` VALUES ('10', '952', '0', '0');
INSERT INTO `character_reputation` VALUES ('10', '948', '0', '8');
INSERT INTO `character_reputation` VALUES ('10', '949', '0', '24');
INSERT INTO `character_reputation` VALUES ('10', '1090', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '1091', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '1082', '0', '2');
INSERT INTO `character_reputation` VALUES ('10', '1085', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '1077', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '1073', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '1068', '0', '6');
INSERT INTO `character_reputation` VALUES ('10', '1067', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '1064', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '1052', '0', '152');
INSERT INTO `character_reputation` VALUES ('10', '1050', '0', '6');
INSERT INTO `character_reputation` VALUES ('10', '1038', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '1031', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '1015', '0', '2');
INSERT INTO `character_reputation` VALUES ('10', '1012', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '1011', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '1005', '0', '4');
INSERT INTO `character_reputation` VALUES ('10', '989', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '978', '0', '0');
INSERT INTO `character_reputation` VALUES ('10', '970', '0', '0');
INSERT INTO `character_reputation` VALUES ('10', '942', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '967', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '934', '0', '80');
INSERT INTO `character_reputation` VALUES ('10', '941', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '933', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '936', '0', '28');
INSERT INTO `character_reputation` VALUES ('10', '932', '0', '80');
INSERT INTO `character_reputation` VALUES ('10', '990', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '922', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '911', '0', '17');
INSERT INTO `character_reputation` VALUES ('10', '910', '0', '0');
INSERT INTO `character_reputation` VALUES ('10', '509', '0', '2');
INSERT INTO `character_reputation` VALUES ('10', '510', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '270', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '909', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '930', '0', '6');
INSERT INTO `character_reputation` VALUES ('10', '892', '0', '24');
INSERT INTO `character_reputation` VALUES ('10', '891', '0', '0');
INSERT INTO `character_reputation` VALUES ('10', '889', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '890', '0', '6');
INSERT INTO `character_reputation` VALUES ('10', '809', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '980', '0', '24');
INSERT INTO `character_reputation` VALUES ('10', '749', '0', '0');
INSERT INTO `character_reputation` VALUES ('10', '729', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '730', '0', '2');
INSERT INTO `character_reputation` VALUES ('10', '935', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '946', '0', '0');
INSERT INTO `character_reputation` VALUES ('10', '947', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '609', '0', '0');
INSERT INTO `character_reputation` VALUES ('10', '576', '0', '2');
INSERT INTO `character_reputation` VALUES ('10', '574', '0', '4');
INSERT INTO `character_reputation` VALUES ('10', '569', '0', '4');
INSERT INTO `character_reputation` VALUES ('10', '571', '0', '4');
INSERT INTO `character_reputation` VALUES ('10', '570', '0', '4');
INSERT INTO `character_reputation` VALUES ('10', '289', '0', '4');
INSERT INTO `character_reputation` VALUES ('10', '46', '0', '4');
INSERT INTO `character_reputation` VALUES ('10', '577', '0', '64');
INSERT INTO `character_reputation` VALUES ('10', '589', '0', '6');
INSERT INTO `character_reputation` VALUES ('10', '550', '0', '4');
INSERT INTO `character_reputation` VALUES ('10', '551', '0', '4');
INSERT INTO `character_reputation` VALUES ('10', '549', '0', '4');
INSERT INTO `character_reputation` VALUES ('10', '83', '0', '4');
INSERT INTO `character_reputation` VALUES ('10', '86', '0', '4');
INSERT INTO `character_reputation` VALUES ('10', '69', '0', '6');
INSERT INTO `character_reputation` VALUES ('10', '47', '0', '6');
INSERT INTO `character_reputation` VALUES ('10', '72', '0', '6');
INSERT INTO `character_reputation` VALUES ('10', '54', '0', '6');
INSERT INTO `character_reputation` VALUES ('10', '68', '0', '17');
INSERT INTO `character_reputation` VALUES ('10', '81', '0', '17');
INSERT INTO `character_reputation` VALUES ('10', '530', '0', '17');
INSERT INTO `character_reputation` VALUES ('10', '76', '0', '17');
INSERT INTO `character_reputation` VALUES ('10', '529', '0', '0');
INSERT INTO `character_reputation` VALUES ('10', '67', '0', '25');
INSERT INTO `character_reputation` VALUES ('10', '469', '0', '14');
INSERT INTO `character_reputation` VALUES ('10', '169', '0', '12');
INSERT INTO `character_reputation` VALUES ('10', '470', '0', '64');
INSERT INTO `character_reputation` VALUES ('10', '471', '0', '22');
INSERT INTO `character_reputation` VALUES ('10', '369', '0', '64');
INSERT INTO `character_reputation` VALUES ('10', '70', '0', '2');
INSERT INTO `character_reputation` VALUES ('10', '349', '0', '0');
INSERT INTO `character_reputation` VALUES ('10', '59', '0', '16');
INSERT INTO `character_reputation` VALUES ('10', '93', '0', '2');
INSERT INTO `character_reputation` VALUES ('10', '92', '0', '2');
INSERT INTO `character_reputation` VALUES ('10', '21', '0', '64');
INSERT INTO `character_reputation` VALUES ('10', '87', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '87', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '21', '0', '64');
INSERT INTO `character_reputation` VALUES ('2', '92', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '93', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '59', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '349', '0', '0');
INSERT INTO `character_reputation` VALUES ('2', '70', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '369', '0', '64');
INSERT INTO `character_reputation` VALUES ('2', '471', '0', '20');
INSERT INTO `character_reputation` VALUES ('2', '470', '0', '64');
INSERT INTO `character_reputation` VALUES ('2', '169', '0', '12');
INSERT INTO `character_reputation` VALUES ('2', '469', '0', '25');
INSERT INTO `character_reputation` VALUES ('2', '67', '0', '14');
INSERT INTO `character_reputation` VALUES ('2', '529', '0', '0');
INSERT INTO `character_reputation` VALUES ('2', '76', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '530', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '81', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '68', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '54', '0', '17');
INSERT INTO `character_reputation` VALUES ('2', '72', '0', '273');
INSERT INTO `character_reputation` VALUES ('2', '47', '0', '273');
INSERT INTO `character_reputation` VALUES ('2', '69', '0', '273');
INSERT INTO `character_reputation` VALUES ('2', '86', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '83', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '549', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '551', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '550', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '589', '0', '0');
INSERT INTO `character_reputation` VALUES ('2', '577', '0', '64');
INSERT INTO `character_reputation` VALUES ('2', '46', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '289', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '570', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '571', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '569', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '574', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '576', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '609', '0', '0');
INSERT INTO `character_reputation` VALUES ('2', '947', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '946', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '935', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '730', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '729', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '749', '0', '0');
INSERT INTO `character_reputation` VALUES ('2', '980', '0', '24');
INSERT INTO `character_reputation` VALUES ('2', '809', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '890', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '889', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '891', '0', '24');
INSERT INTO `character_reputation` VALUES ('2', '892', '0', '14');
INSERT INTO `character_reputation` VALUES ('2', '930', '0', '273');
INSERT INTO `character_reputation` VALUES ('2', '909', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '270', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '510', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '509', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '910', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '911', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '922', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '990', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '932', '0', '80');
INSERT INTO `character_reputation` VALUES ('2', '936', '0', '28');
INSERT INTO `character_reputation` VALUES ('2', '933', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '941', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '934', '0', '80');
INSERT INTO `character_reputation` VALUES ('2', '967', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '942', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '970', '0', '0');
INSERT INTO `character_reputation` VALUES ('2', '978', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '989', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1005', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '1011', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1012', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1015', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '1031', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1038', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1050', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1052', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '1064', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '1067', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '1068', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1073', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1077', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1085', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '1082', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '1091', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1090', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '949', '0', '24');
INSERT INTO `character_reputation` VALUES ('2', '948', '0', '8');
INSERT INTO `character_reputation` VALUES ('2', '952', '0', '0');
INSERT INTO `character_reputation` VALUES ('2', '1037', '0', '136');
INSERT INTO `character_reputation` VALUES ('2', '1097', '0', '12');
INSERT INTO `character_reputation` VALUES ('2', '1094', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1098', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1104', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1105', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1106', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1117', '0', '12');
INSERT INTO `character_reputation` VALUES ('2', '1118', '0', '12');
INSERT INTO `character_reputation` VALUES ('2', '1119', '0', '2');
INSERT INTO `character_reputation` VALUES ('2', '1124', '0', '6');
INSERT INTO `character_reputation` VALUES ('2', '1126', '0', '16');
INSERT INTO `character_reputation` VALUES ('2', '1136', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '1137', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '1154', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '1155', '0', '4');
INSERT INTO `character_reputation` VALUES ('2', '1156', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '749', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '980', '0', '24');
INSERT INTO `character_reputation` VALUES ('6', '809', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '890', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '889', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '891', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '892', '0', '24');
INSERT INTO `character_reputation` VALUES ('6', '930', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '909', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '270', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '510', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '509', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '910', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '911', '3605', '17');
INSERT INTO `character_reputation` VALUES ('6', '922', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '990', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '932', '0', '80');
INSERT INTO `character_reputation` VALUES ('6', '936', '0', '28');
INSERT INTO `character_reputation` VALUES ('6', '933', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '941', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '934', '0', '80');
INSERT INTO `character_reputation` VALUES ('6', '967', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '942', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '970', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '978', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '989', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1005', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '1011', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1012', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1015', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '1031', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1038', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1050', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '1052', '0', '152');
INSERT INTO `character_reputation` VALUES ('6', '1064', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1067', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1068', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '1073', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1077', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1085', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1082', '0', '2');
INSERT INTO `character_reputation` VALUES ('6', '1091', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1090', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '949', '0', '24');
INSERT INTO `character_reputation` VALUES ('6', '948', '0', '8');
INSERT INTO `character_reputation` VALUES ('6', '952', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '1037', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '1097', '0', '12');
INSERT INTO `character_reputation` VALUES ('6', '1094', '0', '6');
INSERT INTO `character_reputation` VALUES ('6', '1098', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1104', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1105', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1106', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1117', '0', '12');
INSERT INTO `character_reputation` VALUES ('6', '1118', '0', '12');
INSERT INTO `character_reputation` VALUES ('6', '1119', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '1124', '0', '16');
INSERT INTO `character_reputation` VALUES ('6', '1126', '0', '0');
INSERT INTO `character_reputation` VALUES ('6', '1136', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '1137', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '1154', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '1155', '0', '4');
INSERT INTO `character_reputation` VALUES ('6', '1156', '0', '16');

-- ----------------------------
-- Table structure for `character_skills`
-- ----------------------------
DROP TABLE IF EXISTS `character_skills`;
CREATE TABLE `character_skills` (
  `guid` int(11) unsigned NOT NULL COMMENT 'Global Unique Identifier',
  `skill` mediumint(9) unsigned NOT NULL,
  `value` mediumint(9) unsigned NOT NULL,
  `max` mediumint(9) unsigned NOT NULL,
  PRIMARY KEY  (`guid`,`skill`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_skills
-- ----------------------------
INSERT INTO `character_skills` VALUES ('2', '8', '1', '1');
INSERT INTO `character_skills` VALUES ('2', '136', '1', '5');
INSERT INTO `character_skills` VALUES ('2', '313', '300', '300');
INSERT INTO `character_skills` VALUES ('2', '98', '300', '300');
INSERT INTO `character_skills` VALUES ('2', '162', '1', '5');
INSERT INTO `character_skills` VALUES ('2', '228', '1', '5');
INSERT INTO `character_skills` VALUES ('2', '6', '1', '1');
INSERT INTO `character_skills` VALUES ('2', '95', '1', '5');
INSERT INTO `character_skills` VALUES ('2', '415', '1', '1');
INSERT INTO `character_skills` VALUES ('9', '172', '290', '290');
INSERT INTO `character_skills` VALUES ('9', '44', '290', '290');
INSERT INTO `character_skills` VALUES ('9', '771', '1', '1');
INSERT INTO `character_skills` VALUES ('9', '43', '290', '290');
INSERT INTO `character_skills` VALUES ('9', '770', '1', '1');
INSERT INTO `character_skills` VALUES ('9', '762', '150', '150');
INSERT INTO `character_skills` VALUES ('9', '162', '290', '290');
INSERT INTO `character_skills` VALUES ('9', '673', '300', '300');
INSERT INTO `character_skills` VALUES ('9', '129', '270', '300');
INSERT INTO `character_skills` VALUES ('11', '118', '1', '275');
INSERT INTO `character_skills` VALUES ('11', '413', '1', '1');
INSERT INTO `character_skills` VALUES ('11', '293', '1', '1');
INSERT INTO `character_skills` VALUES ('6', '594', '1', '1');
INSERT INTO `character_skills` VALUES ('6', '162', '30', '30');
INSERT INTO `character_skills` VALUES ('6', '433', '1', '1');
INSERT INTO `character_skills` VALUES ('6', '137', '300', '300');
INSERT INTO `character_skills` VALUES ('11', '415', '1', '1');
INSERT INTO `character_skills` VALUES ('9', '772', '1', '1');
INSERT INTO `character_skills` VALUES ('9', '109', '300', '300');
INSERT INTO `character_skills` VALUES ('9', '229', '290', '290');
INSERT INTO `character_skills` VALUES ('9', '293', '1', '1');
INSERT INTO `character_skills` VALUES ('9', '413', '1', '1');
INSERT INTO `character_skills` VALUES ('9', '118', '290', '290');
INSERT INTO `character_skills` VALUES ('9', '414', '1', '1');
INSERT INTO `character_skills` VALUES ('9', '55', '290', '290');
INSERT INTO `character_skills` VALUES ('9', '95', '290', '290');
INSERT INTO `character_skills` VALUES ('9', '415', '1', '1');
INSERT INTO `character_skills` VALUES ('11', '414', '1', '1');
INSERT INTO `character_skills` VALUES ('11', '55', '1', '275');
INSERT INTO `character_skills` VALUES ('11', '95', '1', '275');
INSERT INTO `character_skills` VALUES ('7', '129', '270', '300');
INSERT INTO `character_skills` VALUES ('7', '98', '300', '300');
INSERT INTO `character_skills` VALUES ('7', '162', '270', '270');
INSERT INTO `character_skills` VALUES ('7', '762', '150', '150');
INSERT INTO `character_skills` VALUES ('7', '770', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '43', '270', '270');
INSERT INTO `character_skills` VALUES ('7', '771', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '44', '270', '270');
INSERT INTO `character_skills` VALUES ('7', '172', '270', '270');
INSERT INTO `character_skills` VALUES ('7', '772', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '229', '270', '270');
INSERT INTO `character_skills` VALUES ('7', '293', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '413', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '118', '1', '275');
INSERT INTO `character_skills` VALUES ('7', '414', '1', '1');
INSERT INTO `character_skills` VALUES ('7', '55', '270', '270');
INSERT INTO `character_skills` VALUES ('7', '95', '270', '270');
INSERT INTO `character_skills` VALUES ('7', '415', '1', '1');
INSERT INTO `character_skills` VALUES ('11', '229', '1', '275');
INSERT INTO `character_skills` VALUES ('11', '109', '300', '300');
INSERT INTO `character_skills` VALUES ('11', '772', '1', '1');
INSERT INTO `character_skills` VALUES ('11', '172', '1', '275');
INSERT INTO `character_skills` VALUES ('11', '44', '1', '275');
INSERT INTO `character_skills` VALUES ('11', '771', '1', '1');
INSERT INTO `character_skills` VALUES ('11', '315', '300', '300');
INSERT INTO `character_skills` VALUES ('11', '43', '1', '275');
INSERT INTO `character_skills` VALUES ('11', '770', '1', '1');
INSERT INTO `character_skills` VALUES ('11', '762', '150', '150');
INSERT INTO `character_skills` VALUES ('11', '162', '1', '275');
INSERT INTO `character_skills` VALUES ('11', '129', '1', '300');
INSERT INTO `character_skills` VALUES ('2', '176', '1', '5');
INSERT INTO `character_skills` VALUES ('2', '173', '1', '5');
INSERT INTO `character_skills` VALUES ('2', '253', '1', '1');
INSERT INTO `character_skills` VALUES ('2', '38', '1', '1');
INSERT INTO `character_skills` VALUES ('2', '118', '1', '5');
INSERT INTO `character_skills` VALUES ('2', '414', '1', '1');
INSERT INTO `character_skills` VALUES ('10', '415', '1', '1');
INSERT INTO `character_skills` VALUES ('10', '95', '1', '5');
INSERT INTO `character_skills` VALUES ('10', '54', '1', '5');
INSERT INTO `character_skills` VALUES ('10', '109', '300', '300');
INSERT INTO `character_skills` VALUES ('10', '756', '1', '1');
INSERT INTO `character_skills` VALUES ('10', '228', '1', '5');
INSERT INTO `character_skills` VALUES ('10', '162', '1', '5');
INSERT INTO `character_skills` VALUES ('10', '137', '300', '300');
INSERT INTO `character_skills` VALUES ('10', '136', '1', '5');
INSERT INTO `character_skills` VALUES ('10', '56', '1', '1');
INSERT INTO `character_skills` VALUES ('6', '185', '1', '75');
INSERT INTO `character_skills` VALUES ('6', '129', '1', '75');
INSERT INTO `character_skills` VALUES ('6', '43', '30', '30');
INSERT INTO `character_skills` VALUES ('6', '756', '1', '1');
INSERT INTO `character_skills` VALUES ('6', '109', '300', '300');
INSERT INTO `character_skills` VALUES ('6', '413', '1', '1');
INSERT INTO `character_skills` VALUES ('6', '414', '1', '1');
INSERT INTO `character_skills` VALUES ('6', '55', '30', '30');
INSERT INTO `character_skills` VALUES ('6', '95', '30', '30');
INSERT INTO `character_skills` VALUES ('6', '415', '1', '1');

-- ----------------------------
-- Table structure for `character_social`
-- ----------------------------
DROP TABLE IF EXISTS `character_social`;
CREATE TABLE `character_social` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Character Global Unique Identifier',
  `friend` int(11) unsigned NOT NULL default '0' COMMENT 'Friend Global Unique Identifier',
  `flags` tinyint(1) unsigned NOT NULL default '0' COMMENT 'Friend Flags',
  `note` varchar(48) NOT NULL default '' COMMENT 'Friend Note',
  PRIMARY KEY  (`guid`,`friend`,`flags`),
  KEY `guid` (`guid`),
  KEY `friend` (`friend`),
  KEY `guid_flags` (`guid`,`flags`),
  KEY `friend_flags` (`friend`,`flags`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_social
-- ----------------------------

-- ----------------------------
-- Table structure for `character_spell`
-- ----------------------------
DROP TABLE IF EXISTS `character_spell`;
CREATE TABLE `character_spell` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `spell` int(11) unsigned NOT NULL default '0' COMMENT 'Spell Identifier',
  `active` tinyint(3) unsigned NOT NULL default '1',
  `disabled` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`spell`),
  KEY `Idx_spell` (`spell`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_spell
-- ----------------------------
INSERT INTO `character_spell` VALUES ('6', '37836', '1', '0');
INSERT INTO `character_spell` VALUES ('6', '3273', '1', '0');
INSERT INTO `character_spell` VALUES ('6', '2550', '1', '0');
INSERT INTO `character_spell` VALUES ('6', '20271', '1', '0');
INSERT INTO `character_spell` VALUES ('6', '19740', '1', '0');
INSERT INTO `character_spell` VALUES ('6', '465', '1', '0');

-- ----------------------------
-- Table structure for `character_spell_cooldown`
-- ----------------------------
DROP TABLE IF EXISTS `character_spell_cooldown`;
CREATE TABLE `character_spell_cooldown` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier, Low part',
  `spell` int(11) unsigned NOT NULL default '0' COMMENT 'Spell Identifier',
  `item` int(11) unsigned NOT NULL default '0' COMMENT 'Item Identifier',
  `time` bigint(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`spell`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_spell_cooldown
-- ----------------------------

-- ----------------------------
-- Table structure for `character_stats`
-- ----------------------------
DROP TABLE IF EXISTS `character_stats`;
CREATE TABLE `character_stats` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier, Low part',
  `maxhealth` int(10) unsigned NOT NULL default '0',
  `maxpower1` int(10) unsigned NOT NULL default '0',
  `maxpower2` int(10) unsigned NOT NULL default '0',
  `maxpower3` int(10) unsigned NOT NULL default '0',
  `maxpower4` int(10) unsigned NOT NULL default '0',
  `maxpower5` int(10) unsigned NOT NULL default '0',
  `maxpower6` int(10) unsigned NOT NULL default '0',
  `maxpower7` int(10) unsigned NOT NULL default '0',
  `strength` int(10) unsigned NOT NULL default '0',
  `agility` int(10) unsigned NOT NULL default '0',
  `stamina` int(10) unsigned NOT NULL default '0',
  `intellect` int(10) unsigned NOT NULL default '0',
  `spirit` int(10) unsigned NOT NULL default '0',
  `armor` int(10) unsigned NOT NULL default '0',
  `resHoly` int(10) unsigned NOT NULL default '0',
  `resFire` int(10) unsigned NOT NULL default '0',
  `resNature` int(10) unsigned NOT NULL default '0',
  `resFrost` int(10) unsigned NOT NULL default '0',
  `resShadow` int(10) unsigned NOT NULL default '0',
  `resArcane` int(10) unsigned NOT NULL default '0',
  `blockPct` float unsigned NOT NULL default '0',
  `dodgePct` float unsigned NOT NULL default '0',
  `parryPct` float unsigned NOT NULL default '0',
  `critPct` float unsigned NOT NULL default '0',
  `rangedCritPct` float unsigned NOT NULL default '0',
  `spellCritPct` float unsigned NOT NULL default '0',
  `attackPower` int(10) unsigned NOT NULL default '0',
  `rangedAttackPower` int(10) unsigned NOT NULL default '0',
  `spellPower` int(10) unsigned NOT NULL default '0',
  `apmelee` int(11) NOT NULL,
  `ranged` int(11) NOT NULL,
  `blockrating` int(11) NOT NULL,
  `defrating` int(11) NOT NULL,
  `dodgerating` int(11) NOT NULL,
  `parryrating` int(11) NOT NULL,
  `resilience` int(11) NOT NULL,
  `manaregen` float NOT NULL,
  `melee_hitrating` int(11) NOT NULL,
  `melee_critrating` int(11) NOT NULL,
  `melee_hasterating` int(11) NOT NULL,
  `melee_mainmindmg` float NOT NULL,
  `melee_mainmaxdmg` float NOT NULL,
  `melee_offmindmg` float NOT NULL,
  `melee_offmaxdmg` float NOT NULL,
  `melee_maintime` float NOT NULL,
  `melee_offtime` float NOT NULL,
  `ranged_critrating` int(11) NOT NULL,
  `ranged_hasterating` int(11) NOT NULL,
  `ranged_hitrating` int(11) NOT NULL,
  `ranged_mindmg` float NOT NULL,
  `ranged_maxdmg` float NOT NULL,
  `ranged_attacktime` float NOT NULL,
  `spell_hitrating` int(11) NOT NULL,
  `spell_critrating` int(11) NOT NULL,
  `spell_hasterating` int(11) NOT NULL,
  `spell_bonusdmg` int(11) NOT NULL,
  `spell_bonusheal` int(11) NOT NULL,
  `spell_critproc` float NOT NULL,
  `account` int(11) unsigned NOT NULL default '0',
  `name` varchar(12) NOT NULL default '',
  `race` tinyint(3) unsigned NOT NULL default '0',
  `class` tinyint(3) unsigned NOT NULL default '0',
  `gender` tinyint(3) unsigned NOT NULL default '0',
  `level` tinyint(3) unsigned NOT NULL default '0',
  `map` int(11) unsigned NOT NULL default '0',
  `money` int(10) unsigned NOT NULL default '0',
  `totaltime` int(11) unsigned NOT NULL default '0',
  `online` int(10) unsigned NOT NULL default '0',
  `arenaPoints` int(10) unsigned NOT NULL default '0',
  `totalHonorPoints` int(10) unsigned NOT NULL default '0',
  `totalKills` int(10) unsigned NOT NULL default '0',
  `equipmentCache` longtext NOT NULL,
  `specCount` tinyint(3) unsigned NOT NULL default '1',
  `activeSpec` tinyint(3) unsigned NOT NULL default '0',
  `data` longtext NOT NULL,
  PRIMARY KEY  (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_stats
-- ----------------------------
INSERT INTO `character_stats` VALUES ('9', '2147483647', '0', '1000', '0', '100', '0', '8', '1000', '258', '113', '207', '28', '49', '3541', '0', '0', '0', '0', '0', '0', '0', '6.9821', '9.82319', '12.2255', '0.625485', '0', '670', '103', '0', '670', '103', '0', '0', '0', '64', '0', '0', '13', '43', '0', '111.221', '112.371', '111.221', '112.371', '2000', '2000', '43', '0', '13', '18.0714', '19.2214', '2000', '13', '43', '0', '0', '0', '3.19429', '5', 'Sora', '5', '6', '1', '58', '571', '0', '7385', '1', '0', '0', '0', '9 0 25 0 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100730373 2147483647 0 0 0 100 0 0 0 2147483647 0 1000 0 100 0 8 1000 0 0 0 0 0 0 0 0 0 0 0 0 0 0 58 35 0 0 0 8 2048 4194304 1157234688 1157234688 1157234688 1053038739 1069547520 58 58 0 1121874271 1122025004 1113334930 1113334930 0 0 0 0 0 0 1065353216 0 0 0 258 113 207 28 49 1125122048 1108869120 1120403456 0 0 0 0 0 0 0 3541 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1551 256 670 0 0 103 0 0 1099993673 1100596604 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 0 0 0 8 0 0 135680 16777216 1 0 0 12619 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 34652 0 34657 0 34655 0 0 0 34650 0 34651 0 34656 0 34648 0 34653 0 34649 0 34658 0 38147 0 0 0 0 0 34659 0 0 0 0 0 0 0 0 0 0 0 0 11033 1191182336 11051 1191182336 11035 1191182336 0 0 11039 1191182336 11045 1191182336 11047 1191182336 11049 1191182336 11041 1191182336 11043 1191182336 11053 1191182336 11063 1191182336 0 0 0 0 11037 1191182336 0 0 0 0 0 0 0 0 11055 1191182336 11057 1191182336 11059 1191182336 11061 1191182336 11065 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 5636 165800 43 19005730 0 44 19005730 0 55 19005730 0 95 19005730 0 109 19661100 0 118 19005730 0 262273 19661070 0 162 19005730 0 172 19005730 0 229 19005730 0 293 65537 0 413 65537 0 414 65537 0 415 65537 0 673 19661100 0 131834 9830550 0 770 65537 0 771 65537 0 772 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2 0 0 0 1088384349 1092430791 0 0 1094949782 1059069899 1059069899 0 1078751020 1078751020 1078751020 1078751020 1078751020 1078751020 119 0 8388609 0 0 8388608 0 4194304 0 0 0 128 0 12582912 32768 0 1 0 872415236 4096 0 512 64 8 0 0 269746240 0 1572864 536870912 0 17039360 256 0 0 0 0 134217728 0 0 0 0 0 0 66 0 0 0 524288 0 0 0 0 0 0 0 0 0 0 0 4 0 0 0 0 0 1 0 0 0 0 0 8192 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 131072 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 62277 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4294967295 0 0 0 64 0 13 13 13 43 43 43 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1036831949 1036831949 1036831949 1036831949 0 0 0 21 22 23 24 25 26 0 0 0 0 0 0 15 0 ', '1', '0', '9 0 25 0 1065353216 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100730373 2147483647 0 0 0 100 0 0 0 2147483647 0 1000 0 100 0 8 1000 0 0 0 0 0 0 0 0 0 0 0 0 0 0 58 35 0 0 0 8 2048 4194304 1157234688 1157234688 1157234688 1053038739 1069547520 58 58 0 1121874271 1122025004 1113334930 1113334930 0 0 0 0 0 0 1065353216 0 0 0 258 113 207 28 49 1125122048 1108869120 1120403456 0 0 0 0 0 0 0 3541 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1551 256 670 0 0 103 0 0 1099993673 1100596604 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1065353216 0 0 0 8 0 0 135680 16777216 1 0 0 12619 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 34652 0 34657 0 34655 0 0 0 34650 0 34651 0 34656 0 34648 0 34653 0 34649 0 34658 0 38147 0 0 0 0 0 34659 0 0 0 0 0 0 0 0 0 0 0 0 11033 1191182336 11051 1191182336 11035 1191182336 0 0 11039 1191182336 11045 1191182336 11047 1191182336 11049 1191182336 11041 1191182336 11043 1191182336 11053 1191182336 11063 1191182336 0 0 0 0 11037 1191182336 0 0 0 0 0 0 0 0 11055 1191182336 11057 1191182336 11059 1191182336 11061 1191182336 11065 1191182336 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 5636 165800 43 19005730 0 44 19005730 0 55 19005730 0 95 19005730 0 109 19661100 0 118 19005730 0 262273 19661070 0 162 19005730 0 172 19005730 0 229 19005730 0 293 65537 0 413 65537 0 414 65537 0 415 65537 0 673 19661100 0 131834 9830550 0 770 65537 0 771 65537 0 772 65537 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2 0 0 0 1088384349 1092430791 0 0 1094949782 1059069899 1059069899 0 1078751020 1078751020 1078751020 1078751020 1078751020 1078751020 119 0 8388609 0 0 8388608 0 4194304 0 0 0 128 0 12582912 32768 0 1 0 872415236 4096 0 512 64 8 0 0 269746240 0 1572864 536870912 0 17039360 256 0 0 0 0 134217728 0 0 0 0 0 0 66 0 0 0 524288 0 0 0 0 0 0 0 0 0 0 0 4 0 0 0 0 0 1 0 0 0 0 0 8192 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 131072 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 62277 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 1066611507 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4294967295 0 0 0 64 0 13 13 13 43 43 43 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1036831949 1036831949 1036831949 1036831949 0 0 0 21 22 23 24 25 26 0 0 0 0 0 0 15 0 ');

-- ----------------------------
-- Table structure for `character_talent`
-- ----------------------------
DROP TABLE IF EXISTS `character_talent`;
CREATE TABLE `character_talent` (
  `guid` int(11) unsigned NOT NULL,
  `talent_id` int(11) unsigned NOT NULL,
  `current_rank` tinyint(3) unsigned NOT NULL default '0',
  `spec` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`talent_id`,`spec`),
  KEY `guid_key` (`guid`),
  KEY `talent_key` (`talent_id`),
  KEY `spec_key` (`spec`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of character_talent
-- ----------------------------
INSERT INTO `character_talent` VALUES ('9', '1945', '0', '0');
INSERT INTO `character_talent` VALUES ('9', '2017', '0', '0');
INSERT INTO `character_talent` VALUES ('9', '1939', '0', '0');

-- ----------------------------
-- Table structure for `character_ticket`
-- ----------------------------
DROP TABLE IF EXISTS `character_ticket`;
CREATE TABLE `character_ticket` (
  `ticket_id` int(11) unsigned NOT NULL auto_increment,
  `guid` int(11) unsigned NOT NULL default '0',
  `ticket_text` text,
  `response_text` text,
  `ticket_lastchange` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`ticket_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_ticket
-- ----------------------------

-- ----------------------------
-- Table structure for `character_tutorial`
-- ----------------------------
DROP TABLE IF EXISTS `character_tutorial`;
CREATE TABLE `character_tutorial` (
  `account` bigint(20) unsigned NOT NULL auto_increment COMMENT 'Account Identifier',
  `tut0` int(11) unsigned NOT NULL default '0',
  `tut1` int(11) unsigned NOT NULL default '0',
  `tut2` int(11) unsigned NOT NULL default '0',
  `tut3` int(11) unsigned NOT NULL default '0',
  `tut4` int(11) unsigned NOT NULL default '0',
  `tut5` int(11) unsigned NOT NULL default '0',
  `tut6` int(11) unsigned NOT NULL default '0',
  `tut7` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`account`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of character_tutorial
-- ----------------------------
INSERT INTO `character_tutorial` VALUES ('5', '4294950903', '133564151', '0', '0', '0', '0', '0', '0');
INSERT INTO `character_tutorial` VALUES ('6', '2044210935', '130024066', '0', '0', '0', '0', '0', '0');

-- ----------------------------
-- Table structure for `characters`
-- ----------------------------
DROP TABLE IF EXISTS `characters`;
CREATE TABLE `characters` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `account` int(11) unsigned NOT NULL default '0' COMMENT 'Account Identifier',
  `data` longtext NOT NULL,
  `name` varchar(12) NOT NULL default '',
  `race` tinyint(3) unsigned NOT NULL default '0',
  `class` tinyint(3) unsigned NOT NULL default '0',
  `gender` tinyint(3) unsigned NOT NULL default '0',
  `level` tinyint(3) unsigned NOT NULL default '0',
  `xp` int(10) unsigned NOT NULL default '0',
  `money` int(10) unsigned NOT NULL default '0',
  `playerBytes` int(10) unsigned NOT NULL default '0',
  `playerBytes2` int(10) unsigned NOT NULL default '0',
  `playerFlags` int(10) unsigned NOT NULL default '0',
  `position_x` float NOT NULL default '0',
  `position_y` float NOT NULL default '0',
  `position_z` float NOT NULL default '0',
  `map` int(11) unsigned NOT NULL default '0' COMMENT 'Map Identifier',
  `dungeon_difficulty` tinyint(1) unsigned NOT NULL default '0',
  `orientation` float NOT NULL default '0',
  `taximask` longtext,
  `online` tinyint(3) unsigned NOT NULL default '0',
  `cinematic` tinyint(3) unsigned NOT NULL default '0',
  `totaltime` int(11) unsigned NOT NULL default '0',
  `leveltime` int(11) unsigned NOT NULL default '0',
  `logout_time` bigint(20) unsigned NOT NULL default '0',
  `is_logout_resting` tinyint(3) unsigned NOT NULL default '0',
  `rest_bonus` float NOT NULL default '0',
  `resettalents_cost` int(11) unsigned NOT NULL default '0',
  `resettalents_time` bigint(20) unsigned NOT NULL default '0',
  `trans_x` float NOT NULL default '0',
  `trans_y` float NOT NULL default '0',
  `trans_z` float NOT NULL default '0',
  `trans_o` float NOT NULL default '0',
  `transguid` bigint(20) unsigned NOT NULL default '0',
  `extra_flags` int(11) unsigned NOT NULL default '0',
  `stable_slots` tinyint(1) unsigned NOT NULL default '0',
  `at_login` int(11) unsigned NOT NULL default '0',
  `zone` int(11) unsigned NOT NULL default '0',
  `death_expire_time` bigint(20) unsigned NOT NULL default '0',
  `taxi_path` text,
  `arenaPoints` int(10) unsigned NOT NULL default '0',
  `totalHonorPoints` int(10) unsigned NOT NULL default '0',
  `todayHonorPoints` int(10) unsigned NOT NULL default '0',
  `yesterdayHonorPoints` int(10) unsigned NOT NULL default '0',
  `totalKills` int(10) unsigned NOT NULL default '0',
  `todayKills` smallint(5) unsigned NOT NULL default '0',
  `yesterdayKills` smallint(5) unsigned NOT NULL default '0',
  `chosenTitle` int(10) unsigned NOT NULL default '0',
  `knownCurrencies` bigint(20) unsigned NOT NULL default '0',
  `watchedFaction` int(10) unsigned NOT NULL default '0',
  `drunk` smallint(5) unsigned NOT NULL default '0',
  `health` int(10) unsigned NOT NULL default '0',
  `power1` int(10) unsigned NOT NULL default '0',
  `power2` int(10) unsigned NOT NULL default '0',
  `power3` int(10) unsigned NOT NULL default '0',
  `power4` int(10) unsigned NOT NULL default '0',
  `power5` int(10) unsigned NOT NULL default '0',
  `power6` int(10) unsigned NOT NULL default '0',
  `power7` int(10) unsigned NOT NULL default '0',
  `specCount` tinyint(3) unsigned NOT NULL default '1',
  `activeSpec` tinyint(3) unsigned NOT NULL default '0',
  `exploredZones` longtext,
  `equipmentCache` longtext,
  `ammoId` int(10) unsigned NOT NULL default '0',
  `knownTitles` longtext,
  `actionBars` tinyint(3) unsigned NOT NULL default '0',
  `deleteInfos_Account` int(11) unsigned default NULL,
  `deleteInfos_Name` varchar(12) default NULL,
  `deleteDate` bigint(20) default NULL,
  PRIMARY KEY  (`guid`),
  KEY `idx_account` (`account`),
  KEY `idx_online` (`online`),
  KEY `idx_name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';

-- ----------------------------
-- Records of characters
-- ----------------------------
INSERT INTO `characters` VALUES ('2', '5', '', 'Isellyoubuy', '7', '4', '1', '5', '85', '0', '100795140', '16777216', '0', '-6437.93', '-287.903', '3.9304', '1', '0', '1.95643', '32 0 0 8 0 0 0 0 0 0 0 0 0 0 ', '0', '1', '252', '252', '1290821047', '0', '480.587', '0', '0', '0', '0', '0', '0', '0', '2', '0', '0', '1377', '1290503813', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '4294967295', '0', '113', '0', '0', '0', '100', '0', '0', '0', '1', '0', '0 0 0 0 0 0 1048576 0 0 0 0 4194304 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 131072 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '0 0 0 0 0 0 49 0 56 0 0 0 48 0 55 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 0 0 0 28979 0 0 0 ', '0', '0 0 0 0 0 0 ', '0', null, null, null);

-- ----------------------------
-- Table structure for `corpse`
-- ----------------------------
DROP TABLE IF EXISTS `corpse`;
CREATE TABLE `corpse` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `player` int(11) unsigned NOT NULL default '0' COMMENT 'Character Global Unique Identifier',
  `position_x` float NOT NULL default '0',
  `position_y` float NOT NULL default '0',
  `position_z` float NOT NULL default '0',
  `orientation` float NOT NULL default '0',
  `map` int(11) unsigned NOT NULL default '0' COMMENT 'Map Identifier',
  `phaseMask` smallint(5) unsigned NOT NULL default '1',
  `time` bigint(20) unsigned NOT NULL default '0',
  `corpse_type` tinyint(3) unsigned NOT NULL default '0',
  `instance` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`),
  KEY `idx_type` (`corpse_type`),
  KEY `instance` (`instance`),
  KEY `Idx_player` (`player`),
  KEY `Idx_time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Death System';

-- ----------------------------
-- Records of corpse
-- ----------------------------

-- ----------------------------
-- Table structure for `creature_respawn`
-- ----------------------------
DROP TABLE IF EXISTS `creature_respawn`;
CREATE TABLE `creature_respawn` (
  `guid` int(10) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `respawntime` bigint(20) NOT NULL default '0',
  `instance` mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`instance`),
  KEY `instance` (`instance`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Grid Loading System';

-- ----------------------------
-- Records of creature_respawn
-- ----------------------------
INSERT INTO `creature_respawn` VALUES ('86785', '1291817102', '2');

-- ----------------------------
-- Table structure for `gameobject_respawn`
-- ----------------------------
DROP TABLE IF EXISTS `gameobject_respawn`;
CREATE TABLE `gameobject_respawn` (
  `guid` int(10) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `respawntime` bigint(20) NOT NULL default '0',
  `instance` mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`instance`),
  KEY `instance` (`instance`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Grid Loading System';

-- ----------------------------
-- Records of gameobject_respawn
-- ----------------------------

-- ----------------------------
-- Table structure for `group_instance`
-- ----------------------------
DROP TABLE IF EXISTS `group_instance`;
CREATE TABLE `group_instance` (
  `leaderGuid` int(11) unsigned NOT NULL default '0',
  `instance` int(11) unsigned NOT NULL default '0',
  `permanent` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`leaderGuid`,`instance`),
  KEY `instance` (`instance`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of group_instance
-- ----------------------------

-- ----------------------------
-- Table structure for `group_member`
-- ----------------------------
DROP TABLE IF EXISTS `group_member`;
CREATE TABLE `group_member` (
  `groupId` int(11) unsigned NOT NULL,
  `memberGuid` int(11) unsigned NOT NULL,
  `assistant` tinyint(1) unsigned NOT NULL,
  `subgroup` smallint(6) unsigned NOT NULL,
  PRIMARY KEY  (`groupId`,`memberGuid`),
  KEY `Idx_memberGuid` (`memberGuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='Groups';

-- ----------------------------
-- Records of group_member
-- ----------------------------

-- ----------------------------
-- Table structure for `groups`
-- ----------------------------
DROP TABLE IF EXISTS `groups`;
CREATE TABLE `groups` (
  `groupId` int(11) unsigned NOT NULL,
  `leaderGuid` int(11) unsigned NOT NULL,
  `mainTank` int(11) unsigned NOT NULL,
  `mainAssistant` int(11) unsigned NOT NULL,
  `lootMethod` tinyint(4) unsigned NOT NULL,
  `looterGuid` int(11) unsigned NOT NULL,
  `lootThreshold` tinyint(4) unsigned NOT NULL,
  `icon1` int(11) unsigned NOT NULL,
  `icon2` int(11) unsigned NOT NULL,
  `icon3` int(11) unsigned NOT NULL,
  `icon4` int(11) unsigned NOT NULL,
  `icon5` int(11) unsigned NOT NULL,
  `icon6` int(11) unsigned NOT NULL,
  `icon7` int(11) unsigned NOT NULL,
  `icon8` int(11) unsigned NOT NULL,
  `groupType` tinyint(1) unsigned NOT NULL,
  `difficulty` tinyint(3) unsigned NOT NULL default '0',
  `raiddifficulty` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`groupId`),
  UNIQUE KEY `leaderGuid` (`leaderGuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='Groups';

-- ----------------------------
-- Records of groups
-- ----------------------------

-- ----------------------------
-- Table structure for `guild`
-- ----------------------------
DROP TABLE IF EXISTS `guild`;
CREATE TABLE `guild` (
  `guildid` int(6) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `leaderguid` int(6) unsigned NOT NULL default '0',
  `EmblemStyle` int(5) NOT NULL default '0',
  `EmblemColor` int(5) NOT NULL default '0',
  `BorderStyle` int(5) NOT NULL default '0',
  `BorderColor` int(5) NOT NULL default '0',
  `BackgroundColor` int(5) NOT NULL default '0',
  `info` text NOT NULL,
  `motd` varchar(255) NOT NULL default '',
  `createdate` bigint(20) NOT NULL default '0',
  `BankMoney` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`guildid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Guild System';

-- ----------------------------
-- Records of guild
-- ----------------------------

-- ----------------------------
-- Table structure for `guild_bank_eventlog`
-- ----------------------------
DROP TABLE IF EXISTS `guild_bank_eventlog`;
CREATE TABLE `guild_bank_eventlog` (
  `guildid` int(11) unsigned NOT NULL default '0' COMMENT 'Guild Identificator',
  `LogGuid` int(11) unsigned NOT NULL default '0' COMMENT 'Log record identificator - auxiliary column',
  `TabId` tinyint(3) unsigned NOT NULL default '0' COMMENT 'Guild bank TabId',
  `EventType` tinyint(3) unsigned NOT NULL default '0' COMMENT 'Event type',
  `PlayerGuid` int(11) unsigned NOT NULL default '0',
  `ItemOrMoney` int(11) unsigned NOT NULL default '0',
  `ItemStackCount` tinyint(3) unsigned NOT NULL default '0',
  `DestTabId` tinyint(1) unsigned NOT NULL default '0' COMMENT 'Destination Tab Id',
  `TimeStamp` bigint(20) unsigned NOT NULL default '0' COMMENT 'Event UNIX time',
  PRIMARY KEY  (`guildid`,`LogGuid`,`TabId`),
  KEY `guildid_key` (`guildid`),
  KEY `Idx_PlayerGuid` (`PlayerGuid`),
  KEY `Idx_LogGuid` (`LogGuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of guild_bank_eventlog
-- ----------------------------

-- ----------------------------
-- Table structure for `guild_bank_item`
-- ----------------------------
DROP TABLE IF EXISTS `guild_bank_item`;
CREATE TABLE `guild_bank_item` (
  `guildid` int(11) unsigned NOT NULL default '0',
  `TabId` tinyint(1) unsigned NOT NULL default '0',
  `SlotId` tinyint(3) unsigned NOT NULL default '0',
  `item_guid` int(11) unsigned NOT NULL default '0',
  `item_entry` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guildid`,`TabId`,`SlotId`),
  KEY `guildid_key` (`guildid`),
  KEY `Idx_item_guid` (`item_guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of guild_bank_item
-- ----------------------------

-- ----------------------------
-- Table structure for `guild_bank_right`
-- ----------------------------
DROP TABLE IF EXISTS `guild_bank_right`;
CREATE TABLE `guild_bank_right` (
  `guildid` int(11) unsigned NOT NULL default '0',
  `TabId` tinyint(1) unsigned NOT NULL default '0',
  `rid` int(11) unsigned NOT NULL default '0',
  `gbright` tinyint(3) unsigned NOT NULL default '0',
  `SlotPerDay` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guildid`,`TabId`,`rid`),
  KEY `guildid_key` (`guildid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of guild_bank_right
-- ----------------------------

-- ----------------------------
-- Table structure for `guild_bank_tab`
-- ----------------------------
DROP TABLE IF EXISTS `guild_bank_tab`;
CREATE TABLE `guild_bank_tab` (
  `guildid` int(11) unsigned NOT NULL default '0',
  `TabId` tinyint(1) unsigned NOT NULL default '0',
  `TabName` varchar(100) NOT NULL default '',
  `TabIcon` varchar(100) NOT NULL default '',
  `TabText` text,
  PRIMARY KEY  (`guildid`,`TabId`),
  KEY `guildid_key` (`guildid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of guild_bank_tab
-- ----------------------------

-- ----------------------------
-- Table structure for `guild_eventlog`
-- ----------------------------
DROP TABLE IF EXISTS `guild_eventlog`;
CREATE TABLE `guild_eventlog` (
  `guildid` int(11) NOT NULL COMMENT 'Guild Identificator',
  `LogGuid` int(11) NOT NULL COMMENT 'Log record identificator - auxiliary column',
  `EventType` tinyint(1) NOT NULL COMMENT 'Event type',
  `PlayerGuid1` int(11) NOT NULL COMMENT 'Player 1',
  `PlayerGuid2` int(11) NOT NULL COMMENT 'Player 2',
  `NewRank` tinyint(2) NOT NULL COMMENT 'New rank(in case promotion/demotion)',
  `TimeStamp` bigint(20) NOT NULL COMMENT 'Event UNIX time',
  PRIMARY KEY  (`guildid`,`LogGuid`),
  KEY `Idx_PlayerGuid1` (`PlayerGuid1`),
  KEY `Idx_PlayerGuid2` (`PlayerGuid2`),
  KEY `Idx_LogGuid` (`LogGuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Guild Eventlog';

-- ----------------------------
-- Records of guild_eventlog
-- ----------------------------

-- ----------------------------
-- Table structure for `guild_member`
-- ----------------------------
DROP TABLE IF EXISTS `guild_member`;
CREATE TABLE `guild_member` (
  `guildid` int(6) unsigned NOT NULL default '0',
  `guid` int(11) unsigned NOT NULL default '0',
  `rank` tinyint(2) unsigned NOT NULL default '0',
  `pnote` varchar(255) NOT NULL default '',
  `offnote` varchar(255) NOT NULL default '',
  `BankResetTimeMoney` int(11) unsigned NOT NULL default '0',
  `BankRemMoney` int(11) unsigned NOT NULL default '0',
  `BankResetTimeTab0` int(11) unsigned NOT NULL default '0',
  `BankRemSlotsTab0` int(11) unsigned NOT NULL default '0',
  `BankResetTimeTab1` int(11) unsigned NOT NULL default '0',
  `BankRemSlotsTab1` int(11) unsigned NOT NULL default '0',
  `BankResetTimeTab2` int(11) unsigned NOT NULL default '0',
  `BankRemSlotsTab2` int(11) unsigned NOT NULL default '0',
  `BankResetTimeTab3` int(11) unsigned NOT NULL default '0',
  `BankRemSlotsTab3` int(11) unsigned NOT NULL default '0',
  `BankResetTimeTab4` int(11) unsigned NOT NULL default '0',
  `BankRemSlotsTab4` int(11) unsigned NOT NULL default '0',
  `BankResetTimeTab5` int(11) unsigned NOT NULL default '0',
  `BankRemSlotsTab5` int(11) unsigned NOT NULL default '0',
  UNIQUE KEY `guid_key` (`guid`),
  KEY `guildid_key` (`guildid`),
  KEY `guildid_rank_key` (`guildid`,`rank`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='Guild System';

-- ----------------------------
-- Records of guild_member
-- ----------------------------

-- ----------------------------
-- Table structure for `guild_rank`
-- ----------------------------
DROP TABLE IF EXISTS `guild_rank`;
CREATE TABLE `guild_rank` (
  `guildid` int(6) unsigned NOT NULL default '0',
  `rid` int(11) unsigned NOT NULL,
  `rname` varchar(255) NOT NULL default '',
  `rights` int(3) unsigned NOT NULL default '0',
  `BankMoneyPerDay` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guildid`,`rid`),
  KEY `Idx_rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Guild System';

-- ----------------------------
-- Records of guild_rank
-- ----------------------------

-- ----------------------------
-- Table structure for `instance`
-- ----------------------------
DROP TABLE IF EXISTS `instance`;
CREATE TABLE `instance` (
  `id` int(11) unsigned NOT NULL default '0',
  `map` int(11) unsigned NOT NULL default '0',
  `resettime` bigint(40) NOT NULL default '0',
  `difficulty` tinyint(1) unsigned NOT NULL default '0',
  `data` longtext,
  PRIMARY KEY  (`id`),
  KEY `map` (`map`),
  KEY `resettime` (`resettime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of instance
-- ----------------------------
INSERT INTO `instance` VALUES ('1', '603', '0', '0', '');
INSERT INTO `instance` VALUES ('2', '578', '1291809873', '0', '3 0 0 0');

-- ----------------------------
-- Table structure for `instance_reset`
-- ----------------------------
DROP TABLE IF EXISTS `instance_reset`;
CREATE TABLE `instance_reset` (
  `mapid` int(11) unsigned NOT NULL default '0',
  `difficulty` tinyint(1) unsigned NOT NULL default '0',
  `resettime` bigint(40) NOT NULL default '0',
  PRIMARY KEY  (`mapid`,`difficulty`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of instance_reset
-- ----------------------------
INSERT INTO `instance_reset` VALUES ('249', '0', '1292374800');
INSERT INTO `instance_reset` VALUES ('309', '0', '1291838400');
INSERT INTO `instance_reset` VALUES ('409', '0', '1292374800');
INSERT INTO `instance_reset` VALUES ('469', '0', '1292374800');
INSERT INTO `instance_reset` VALUES ('509', '0', '1291838400');
INSERT INTO `instance_reset` VALUES ('531', '0', '1292374800');
INSERT INTO `instance_reset` VALUES ('532', '0', '1292374800');
INSERT INTO `instance_reset` VALUES ('533', '0', '1292374800');
INSERT INTO `instance_reset` VALUES ('534', '0', '1292374800');
INSERT INTO `instance_reset` VALUES ('544', '0', '1292374800');
INSERT INTO `instance_reset` VALUES ('548', '0', '1292374800');
INSERT INTO `instance_reset` VALUES ('550', '0', '1292374800');
INSERT INTO `instance_reset` VALUES ('564', '0', '1292374800');
INSERT INTO `instance_reset` VALUES ('565', '0', '1292374800');
INSERT INTO `instance_reset` VALUES ('568', '0', '1292029200');
INSERT INTO `instance_reset` VALUES ('580', '0', '1292374800');
INSERT INTO `instance_reset` VALUES ('603', '0', '1292374800');
INSERT INTO `instance_reset` VALUES ('615', '0', '1292374800');
INSERT INTO `instance_reset` VALUES ('616', '0', '1292374800');
INSERT INTO `instance_reset` VALUES ('624', '0', '1292374800');
INSERT INTO `instance_reset` VALUES ('631', '0', '1292374800');
INSERT INTO `instance_reset` VALUES ('649', '0', '1292374800');
INSERT INTO `instance_reset` VALUES ('724', '0', '1292374800');
INSERT INTO `instance_reset` VALUES ('249', '1', '1292374800');
INSERT INTO `instance_reset` VALUES ('269', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('533', '1', '1292374800');
INSERT INTO `instance_reset` VALUES ('540', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('542', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('543', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('545', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('546', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('547', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('552', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('553', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('554', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('555', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('556', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('557', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('558', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('560', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('574', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('575', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('576', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('578', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('585', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('595', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('598', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('599', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('600', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('601', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('602', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('603', '1', '1292374800');
INSERT INTO `instance_reset` VALUES ('604', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('608', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('615', '1', '1292374800');
INSERT INTO `instance_reset` VALUES ('616', '1', '1292374800');
INSERT INTO `instance_reset` VALUES ('619', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('624', '1', '1292374800');
INSERT INTO `instance_reset` VALUES ('631', '1', '1292374800');
INSERT INTO `instance_reset` VALUES ('632', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('649', '1', '1292374800');
INSERT INTO `instance_reset` VALUES ('650', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('658', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('668', '1', '1291856400');
INSERT INTO `instance_reset` VALUES ('724', '1', '1292374800');
INSERT INTO `instance_reset` VALUES ('631', '2', '1292374800');
INSERT INTO `instance_reset` VALUES ('649', '2', '1292374800');
INSERT INTO `instance_reset` VALUES ('724', '2', '1292374800');
INSERT INTO `instance_reset` VALUES ('631', '3', '1292374800');
INSERT INTO `instance_reset` VALUES ('649', '3', '1292374800');
INSERT INTO `instance_reset` VALUES ('724', '3', '1292374800');

-- ----------------------------
-- Table structure for `item_instance`
-- ----------------------------
DROP TABLE IF EXISTS `item_instance`;
CREATE TABLE `item_instance` (
  `guid` int(11) unsigned NOT NULL default '0',
  `owner_guid` int(11) unsigned NOT NULL default '0',
  `data` longtext,
  `text` longtext,
  PRIMARY KEY  (`guid`),
  KEY `idx_owner_guid` (`owner_guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Item System';

-- ----------------------------
-- Records of item_instance
-- ----------------------------
INSERT INTO `item_instance` VALUES ('11061', '9', '11061 1191182336 7 38145 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11059', '9', '11059 1191182336 7 38145 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11057', '9', '11057 1191182336 7 38145 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11055', '9', '11055 1191182336 7 38145 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11053', '9', '11053 1191182336 3 34658 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11051', '9', '11051 1191182336 3 34657 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11047', '9', '11047 1191182336 3 34656 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 77 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11049', '9', '11049 1191182336 3 34648 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11043', '9', '11043 1191182336 3 34649 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 36 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11045', '9', '11045 1191182336 3 34651 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 36 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11041', '9', '11041 1191182336 3 34653 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 36 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11037', '9', '11037 1191182336 3 34659 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11039', '9', '11039 1191182336 3 34650 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 104 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11035', '9', '11035 1191182336 3 34655 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 63 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11033', '9', '11033 1191182336 3 34652 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 63 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('36', '2', '36 1191182336 3 56 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 24 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('38', '2', '38 1191182336 3 1395 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('40', '2', '40 1191182336 3 6096 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('42', '2', '42 1191182336 3 55 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('44', '2', '44 1191182336 3 35 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 17 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('46', '2', '46 1191182336 3 6948 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('10284', '6', '10284 1191182336 3 21020 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('13504', '6', '13504 1191182336 7 4496 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('13505', '6', '13505 1191182336 3 23353 1065353216 0 6 0 6 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('10279', '6', '10279 1191182336 7 4496 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('362', '7', '362 1191182336 3 34651 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('366', '7', '366 1191182336 3 34648 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 54 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('368', '7', '368 1191182336 3 34657 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('352', '7', '352 1191182336 3 34655 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 68 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('13501', '6', '13501 1191182336 3 24241 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 18 18 0 0 ', '');
INSERT INTO `item_instance` VALUES ('630', '6', '630 1191182336 3 6948 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('622', '6', '622 1191182336 3 24143 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('370', '7', '370 1191182336 3 34658 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('350', '7', '350 1191182336 3 34652 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 69 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('380', '7', '380 1191182336 3 38147 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('382', '7', '382 1191182336 3 41751 1065353216 0 7 0 7 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('354', '7', '354 1191182336 3 34659 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('356', '7', '356 1191182336 3 34650 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 115 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('358', '7', '358 1191182336 3 34653 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 39 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('360', '7', '360 1191182336 3 34649 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 39 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('364', '7', '364 1191182336 3 34656 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('372', '7', '372 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('374', '7', '374 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('376', '7', '376 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('378', '7', '378 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('500', '2', '500 1191182336 3 49 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('502', '2', '502 1191182336 3 48 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 17 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('504', '2', '504 1191182336 3 47 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('506', '2', '506 1191182336 3 2092 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 16 0 0 ', '');
INSERT INTO `item_instance` VALUES ('508', '2', '508 1191182336 3 50055 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 16 0 0 ', '');
INSERT INTO `item_instance` VALUES ('510', '2', '510 1191182336 3 28979 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('512', '2', '512 1191182336 3 6948 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9874', '7', '9874 1191182336 3 40582 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9872', '7', '9872 1191182336 3 41751 1065353216 0 7 0 7 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9870', '7', '9870 1191182336 3 38147 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9868', '7', '9868 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9866', '7', '9866 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9864', '7', '9864 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9862', '7', '9862 1191182336 7 38145 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9860', '7', '9860 1191182336 3 34658 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9840', '7', '9840 1191182336 3 34652 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9842', '7', '9842 1191182336 3 34655 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9844', '7', '9844 1191182336 3 34659 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9846', '7', '9846 1191182336 3 34650 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 115 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9848', '7', '9848 1191182336 3 34653 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9850', '7', '9850 1191182336 3 34649 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9852', '7', '9852 1191182336 3 34651 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9854', '7', '9854 1191182336 3 34656 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9856', '7', '9856 1191182336 3 34648 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('9858', '7', '9858 1191182336 3 34657 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('10296', '6', '10296 1191182336 3 20841 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('10500', '6', '10500 1191182336 3 159 1065353216 0 6 0 6 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('7855', '6', '7855 1191182336 7 20474 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('7889', '6', '7889 1191182336 3 20999 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 18 18 0 0 ', '');
INSERT INTO `item_instance` VALUES ('7912', '6', '7912 1191182336 3 20991 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21827', '2', '21827 1191182336 3 8151 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21826', '2', '21826 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21828', '2', '21828 1191182336 3 24948 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 31 4294967282 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21829', '2', '21829 1191182336 3 7517 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 405 0 0 411 0 0 0 0 0 0 877 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21252', '2', '21252 1191182336 3 25256 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 12 4294967256 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21253', '2', '21253 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('13503', '6', '13503 1191182336 3 2488 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21825', '2', '21825 1191182336 3 24936 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 40 4294967252 115 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21824', '2', '21824 1191182336 3 4634 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21823', '2', '21823 1191182336 3 27511 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21822', '2', '21822 1191182336 3 3223 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21821', '2', '21821 1191182336 3 24937 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 30 4294967251 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21820', '2', '21820 1191182336 3 20659 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 367 0 0 363 0 0 366 0 0 0 2154 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21819', '2', '21819 1191182336 3 36385 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 75 4294967251 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21818', '2', '21818 1191182336 3 1624 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21817', '2', '21817 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 19 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21816', '2', '21816 1191182336 3 2072 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 92 0 0 105 0 0 0 0 0 0 601 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21815', '2', '21815 1191182336 3 8106 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21814', '2', '21814 1191182336 3 25102 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2823 0 0 0 0 0 0 0 0 17 4294967253 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21813', '2', '21813 1191182336 3 38513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21812', '2', '21812 1191182336 3 1659 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21811', '2', '21811 1191182336 3 24716 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 22 4294967283 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21810', '2', '21810 1191182336 3 36514 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 108 4294967255 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21809', '2', '21809 1191182336 3 36442 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 56 4294967257 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21808', '2', '21808 1191182336 3 36270 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2818 0 0 0 0 0 0 0 0 0 0 0 75 4294967264 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21807', '2', '21807 1191182336 3 17969 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21806', '2', '21806 1191182336 3 24937 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 30 4294967255 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21805', '2', '21805 1191182336 3 28496 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2825 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 34 4294967239 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21804', '2', '21804 1191182336 3 3330 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21803', '2', '21803 1191182336 3 4047 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21802', '2', '21802 1191182336 3 14832 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21801', '2', '21801 1191182336 3 36387 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 78 4294967288 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21800', '2', '21800 1191182336 3 4771 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21799', '2', '21799 1191182336 3 14895 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 366 0 0 362 0 0 0 0 0 0 1207 115 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21798', '2', '21798 1191182336 3 24890 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 52 4294967286 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21797', '2', '21797 1191182336 3 5749 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21796', '2', '21796 1191182336 3 10367 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1951 0 0 0 0 0 0 0 0 0 1615 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21795', '2', '21795 1191182336 3 36399 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 108 4294967277 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21794', '2', '21794 1191182336 3 36413 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 54 4294967256 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21793', '2', '21793 1191182336 3 36375 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 97 4294967270 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21792', '2', '21792 1191182336 3 4767 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 18 18 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21791', '2', '21791 1191182336 3 5112 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21790', '2', '21790 1191182336 3 880 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21789', '2', '21789 1191182336 3 28541 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 16 4294967282 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21788', '2', '21788 1191182336 3 25278 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 4294967277 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21787', '2', '21787 1191182336 3 36057 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 78 4294967281 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21786', '2', '21786 1191182336 3 36287 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 108 4294967287 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21785', '2', '21785 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21784', '2', '21784 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21783', '2', '21783 1191182336 3 36428 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2816 0 0 0 0 0 0 0 0 0 0 0 0 0 0 56 4294967266 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21782', '2', '21782 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21781', '2', '21781 1191182336 3 4464 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21780', '2', '21780 1191182336 3 13757 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21779', '2', '21779 1191182336 3 13422 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21778', '2', '21778 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21777', '2', '21777 1191182336 3 826 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21776', '2', '21776 1191182336 3 36038 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 72 4294967280 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21775', '2', '21775 1191182336 3 37160 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21774', '2', '21774 1191182336 3 6204 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21773', '2', '21773 1191182336 3 36176 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 108 4294967270 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21772', '2', '21772 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21771', '2', '21771 1191182336 3 5029 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21770', '2', '21770 1191182336 3 3563 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21769', '2', '21769 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21768', '2', '21768 1191182336 3 24948 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 31 4294967270 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21767', '2', '21767 1191182336 3 24667 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 39 4294967270 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21766', '2', '21766 1191182336 3 36681 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 45 4294967288 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21765', '2', '21765 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21764', '2', '21764 1191182336 3 790 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 74 0 0 72 0 0 0 0 0 0 586 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21763', '2', '21763 1191182336 3 814 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21762', '2', '21762 1191182336 3 1214 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21761', '2', '21761 1191182336 3 27513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21760', '2', '21760 1191182336 3 2623 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21759', '2', '21759 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21758', '2', '21758 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21757', '2', '21757 1191182336 3 25228 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 40 4294967255 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21756', '2', '21756 1191182336 3 27511 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21755', '2', '21755 1191182336 3 36396 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 81 4294967284 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21754', '2', '21754 1191182336 3 36162 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 56 4294967256 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21753', '2', '21753 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21752', '2', '21752 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21751', '2', '21751 1191182336 3 41119 1065353216 0 2 0 2 0 0 0 0 0 12 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21750', '2', '21750 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 15 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21749', '2', '21749 1191182336 3 24775 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 52 4294967287 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21748', '2', '21748 1191182336 3 36781 1065353216 0 2 0 2 0 0 0 0 0 19 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21747', '2', '21747 1191182336 3 1460 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21746', '2', '21746 1191182336 3 10333 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21745', '2', '21745 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21744', '2', '21744 1191182336 3 1560 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21743', '2', '21743 1191182336 3 5743 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21742', '2', '21742 1191182336 3 20694 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21741', '2', '21741 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21740', '2', '21740 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21739', '2', '21739 1191182336 3 1927 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21738', '2', '21738 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 15 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21737', '2', '21737 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21736', '2', '21736 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21735', '2', '21735 1191182336 3 24662 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 39 4294967288 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21734', '2', '21734 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21733', '2', '21733 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21732', '2', '21732 1191182336 3 1943 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21731', '2', '21731 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 17 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21730', '2', '21730 1191182336 3 2623 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21729', '2', '21729 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21728', '2', '21728 1191182336 3 20655 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 366 0 0 2316 0 0 2372 0 0 0 2147 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21727', '2', '21727 1191182336 3 25068 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 29 4294967288 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21726', '2', '21726 1191182336 3 1475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21725', '2', '21725 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 7 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21724', '2', '21724 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 17 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21723', '2', '21723 1191182336 3 25172 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 40 4294967291 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21722', '2', '21722 1191182336 3 35995 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 60 4294967287 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21721', '2', '21721 1191182336 3 10561 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21720', '2', '21720 1191182336 3 25138 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 52 4294967289 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21719', '2', '21719 1191182336 3 2233 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21718', '2', '21718 1191182336 3 36176 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 108 4294967283 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21717', '2', '21717 1191182336 3 36456 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 56 4294967252 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21716', '2', '21716 1191182336 3 24601 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 40 4294967260 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21715', '2', '21715 1191182336 3 1473 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21714', '2', '21714 1191182336 3 4638 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21713', '2', '21713 1191182336 3 36582 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 43 4294967251 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21712', '2', '21712 1191182336 3 36539 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 97 4294967283 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21711', '2', '21711 1191182336 3 24999 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 39 4294967255 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21710', '2', '21710 1191182336 3 4676 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21709', '2', '21709 1191182336 3 8284 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21708', '2', '21708 1191182336 3 24712 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 30 4294967256 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21707', '2', '21707 1191182336 3 8245 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21706', '2', '21706 1191182336 3 2058 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21705', '2', '21705 1191182336 3 9249 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21704', '2', '21704 1191182336 3 2241 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21703', '2', '21703 1191182336 3 27511 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21702', '2', '21702 1191182336 3 814 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21701', '2', '21701 1191182336 3 36398 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2825 0 0 0 0 0 0 0 0 0 0 0 0 0 0 81 4294967276 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21700', '2', '21700 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21699', '2', '21699 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21698', '2', '21698 1191182336 3 2072 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2084 0 0 0 0 0 0 0 0 0 1804 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21697', '2', '21697 1191182336 3 3571 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21696', '2', '21696 1191182336 3 897 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21695', '2', '21695 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21694', '2', '21694 1191182336 3 1951 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21693', '2', '21693 1191182336 3 36054 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 78 4294967259 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21692', '2', '21692 1191182336 3 25172 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 40 4294967284 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21691', '2', '21691 1191182336 3 1944 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21690', '2', '21690 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 15 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21689', '2', '21689 1191182336 3 36054 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 78 4294967257 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21688', '2', '21688 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21687', '2', '21687 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21686', '2', '21686 1191182336 3 24722 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 41 4294967286 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21685', '2', '21685 1191182336 3 36174 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 81 4294967282 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21684', '2', '21684 1191182336 3 1944 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21683', '2', '21683 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21682', '2', '21682 1191182336 3 6360 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21681', '2', '21681 1191182336 3 14899 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 361 0 0 367 0 0 0 0 0 0 1208 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21680', '2', '21680 1191182336 3 12804 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21679', '2', '21679 1191182336 3 36377 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 72 4294967283 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21678', '2', '21678 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21677', '2', '21677 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21676', '2', '21676 1191182336 3 10561 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21675', '2', '21675 1191182336 3 8151 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21674', '2', '21674 1191182336 3 13422 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21673', '2', '21673 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21672', '2', '21672 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21671', '2', '21671 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21670', '2', '21670 1191182336 3 8350 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21669', '2', '21669 1191182336 3 24712 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 4294967277 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21668', '2', '21668 1191182336 3 19441 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21667', '2', '21667 1191182336 3 36598 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 108 4294967287 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21666', '2', '21666 1191182336 3 36058 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 58 4294967257 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21665', '2', '21665 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21664', '2', '21664 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21663', '2', '21663 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21662', '2', '21662 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21661', '2', '21661 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21660', '2', '21660 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21659', '2', '21659 1191182336 3 19441 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21658', '2', '21658 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21657', '2', '21657 1191182336 3 24825 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 30 4294967282 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21656', '2', '21656 1191182336 3 24774 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 39 4294967257 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21655', '2', '21655 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21654', '2', '21654 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 12 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21653', '2', '21653 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21652', '2', '21652 1191182336 3 36036 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 72 4294967257 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21651', '2', '21651 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21650', '2', '21650 1191182336 3 13422 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21649', '2', '21649 1191182336 3 814 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21648', '2', '21648 1191182336 3 24476 1065353216 0 2 0 2 0 0 0 0 0 15 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21647', '2', '21647 1191182336 3 24685 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 42 4294967259 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21646', '2', '21646 1191182336 3 1990 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 349 0 0 352 0 0 0 0 0 0 691 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21645', '2', '21645 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21644', '2', '21644 1191182336 3 36556 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 108 4294967251 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21643', '2', '21643 1191182336 3 36278 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2822 0 0 2824 0 0 0 0 0 0 0 0 78 4294967229 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21642', '2', '21642 1191182336 3 27515 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21641', '2', '21641 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 7 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20271', '2', '20271 1191182336 3 19441 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20270', '2', '20270 1191182336 3 36270 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 75 4294967282 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20269', '2', '20269 1191182336 3 30738 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20268', '2', '20268 1191182336 3 36288 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 108 4294967285 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20267', '2', '20267 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20266', '2', '20266 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20265', '2', '20265 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20264', '2', '20264 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 7 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20263', '2', '20263 1191182336 3 6197 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20262', '2', '20262 1191182336 3 24942 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 31 4294967251 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20261', '2', '20261 1191182336 3 37158 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20260', '2', '20260 1191182336 3 34829 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20259', '2', '20259 1191182336 3 9251 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20258', '2', '20258 1191182336 3 32540 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20257', '2', '20257 1191182336 3 36665 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 4294967280 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20256', '2', '20256 1191182336 3 30735 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20255', '2', '20255 1191182336 3 1169 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20254', '2', '20254 1191182336 3 11018 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20253', '2', '20253 1191182336 3 1982 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20252', '2', '20252 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20251', '2', '20251 1191182336 3 4589 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20250', '2', '20250 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20249', '2', '20249 1191182336 3 10026 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20248', '2', '20248 1191182336 3 2898 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20247', '2', '20247 1191182336 3 36581 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 42 4294967255 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20246', '2', '20246 1191182336 3 720 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20245', '2', '20245 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20244', '2', '20244 1191182336 3 37117 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20243', '2', '20243 1191182336 3 2257 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20242', '2', '20242 1191182336 3 3844 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20241', '2', '20241 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20240', '2', '20240 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20239', '2', '20239 1191182336 3 6205 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20238', '2', '20238 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20237', '2', '20237 1191182336 3 10629 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20236', '2', '20236 1191182336 3 1522 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20235', '2', '20235 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20234', '2', '20234 1191182336 3 24476 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20233', '2', '20233 1191182336 3 36280 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 104 4294967283 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20232', '2', '20232 1191182336 3 36040 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 97 4294967277 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20231', '2', '20231 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20230', '2', '20230 1191182336 3 36428 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 56 4294967251 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20229', '2', '20229 1191182336 3 6197 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20228', '2', '20228 1191182336 3 4454 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20227', '2', '20227 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20226', '2', '20226 1191182336 3 7730 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20225', '2', '20225 1191182336 3 24368 1065353216 0 2 0 2 0 0 0 0 0 22 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20224', '2', '20224 1191182336 3 37749 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20223', '2', '20223 1191182336 3 2824 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20222', '2', '20222 1191182336 3 5110 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20221', '2', '20221 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20220', '2', '20220 1191182336 3 13905 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20219', '2', '20219 1191182336 3 36781 1065353216 0 2 0 2 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20218', '2', '20218 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20217', '2', '20217 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20216', '2', '20216 1191182336 3 1728 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 105 105 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20215', '2', '20215 1191182336 3 9397 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20214', '2', '20214 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20213', '2', '20213 1191182336 3 2065 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20212', '2', '20212 1191182336 3 2291 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20211', '2', '20211 1191182336 3 2163 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20210', '2', '20210 1191182336 3 25264 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 16 4294967255 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20209', '2', '20209 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20208', '2', '20208 1191182336 3 4359 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20207', '2', '20207 1191182336 3 20679 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20206', '2', '20206 1191182336 3 25270 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 12 4294967285 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20205', '2', '20205 1191182336 3 32464 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20204', '2', '20204 1191182336 3 36174 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2819 0 0 0 0 0 0 0 0 0 0 0 81 4294967263 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20203', '2', '20203 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20202', '2', '20202 1191182336 3 4278 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20201', '2', '20201 1191182336 3 2110 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20200', '2', '20200 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20199', '2', '20199 1191182336 3 2100 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20198', '2', '20198 1191182336 3 1475 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20197', '2', '20197 1191182336 3 41119 1065353216 0 2 0 2 0 0 0 0 0 19 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20196', '2', '20196 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20195', '2', '20195 1191182336 3 7728 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20194', '2', '20194 1191182336 3 30736 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20193', '2', '20193 1191182336 3 25144 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 17 4294967255 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20192', '2', '20192 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20191', '2', '20191 1191182336 3 32540 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20190', '2', '20190 1191182336 3 36471 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 58 4294967257 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20189', '2', '20189 1191182336 3 24291 1065353216 0 2 0 2 0 0 0 0 0 164 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20188', '2', '20188 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20187', '2', '20187 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20186', '2', '20186 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20185', '2', '20185 1191182336 3 24368 1065353216 0 2 0 2 0 0 0 0 0 126 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20184', '2', '20184 1191182336 3 27513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20183', '2', '20183 1191182336 3 36055 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 104 4294967288 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20182', '2', '20182 1191182336 3 1457 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20181', '2', '20181 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20180', '2', '20180 1191182336 3 18611 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20179', '2', '20179 1191182336 3 13757 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20178', '2', '20178 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20177', '2', '20177 1191182336 3 45984 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20176', '2', '20176 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20175', '2', '20175 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20174', '2', '20174 1191182336 3 17414 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20173', '2', '20173 1191182336 3 13875 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20172', '2', '20172 1191182336 3 37160 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20171', '2', '20171 1191182336 3 4634 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20170', '2', '20170 1191182336 3 24653 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 38 4294967275 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20169', '2', '20169 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20168', '2', '20168 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20167', '2', '20167 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20166', '2', '20166 1191182336 3 5426 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20165', '2', '20165 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20164', '2', '20164 1191182336 3 24601 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 40 4294967290 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20163', '2', '20163 1191182336 3 21561 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20162', '2', '20162 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20161', '2', '20161 1191182336 3 18678 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20160', '2', '20160 1191182336 3 18678 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20159', '2', '20159 1191182336 3 44683 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 65 4294967257 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20158', '2', '20158 1191182336 3 2982 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20157', '2', '20157 1191182336 3 2283 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 18 18 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20156', '2', '20156 1191182336 3 20677 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20155', '2', '20155 1191182336 3 31901 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20154', '2', '20154 1191182336 3 2241 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20153', '2', '20153 1191182336 3 4481 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20152', '2', '20152 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20151', '2', '20151 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20150', '2', '20150 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20149', '2', '20149 1191182336 3 13024 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20148', '2', '20148 1191182336 3 36514 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 108 4294967252 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20147', '2', '20147 1191182336 3 28531 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 12 4294967255 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20146', '2', '20146 1191182336 3 16656 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20145', '2', '20145 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20144', '2', '20144 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20143', '2', '20143 1191182336 3 14169 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20142', '2', '20142 1191182336 3 6458 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20141', '2', '20141 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20140', '2', '20140 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20139', '2', '20139 1191182336 3 36525 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 42 4294967290 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20138', '2', '20138 1191182336 3 3042 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20137', '2', '20137 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20136', '2', '20136 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20135', '2', '20135 1191182336 3 13757 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20134', '2', '20134 1191182336 3 36553 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 97 4294967255 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20133', '2', '20133 1191182336 3 41427 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20132', '2', '20132 1191182336 3 20528 1065353216 0 2 0 2 0 0 0 0 0 15 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20131', '2', '20131 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20130', '2', '20130 1191182336 3 30458 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20129', '2', '20129 1191182336 3 7973 1065353216 0 2 0 2 0 0 0 0 0 7 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20128', '2', '20128 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20127', '2', '20127 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20126', '2', '20126 1191182336 3 31269 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 2803 0 0 2804 0 0 0 0 0 0 0 0 2 4294967238 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20125', '2', '20125 1191182336 3 8956 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20124', '2', '20124 1191182336 3 24663 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 52 4294967259 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20123', '2', '20123 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20122', '2', '20122 1191182336 3 2054 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20121', '2', '20121 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20120', '2', '20120 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20119', '2', '20119 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20118', '2', '20118 1191182336 3 21296 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20117', '2', '20117 1191182336 3 5624 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20116', '2', '20116 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20115', '2', '20115 1191182336 3 31229 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 40 4294967288 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20114', '2', '20114 1191182336 3 44749 1065353216 0 2 0 2 0 0 0 0 0 15 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20113', '2', '20113 1191182336 3 9251 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20112', '2', '20112 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20111', '2', '20111 1191182336 3 7728 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20110', '2', '20110 1191182336 3 2284 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20109', '2', '20109 1191182336 3 5971 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20108', '2', '20108 1191182336 3 3279 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20107', '2', '20107 1191182336 3 6514 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20106', '2', '20106 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20105', '2', '20105 1191182336 3 3261 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20104', '2', '20104 1191182336 3 24476 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20103', '2', '20103 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20102', '2', '20102 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20101', '2', '20101 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20100', '2', '20100 1191182336 3 36041 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 72 4294967271 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20099', '2', '20099 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 11 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20098', '2', '20098 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20097', '2', '20097 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20096', '2', '20096 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20095', '2', '20095 1191182336 3 13001 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20094', '2', '20094 1191182336 3 44165 1065353216 0 2 0 2 0 0 0 0 0 19 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20093', '2', '20093 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20092', '2', '20092 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20091', '2', '20091 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20090', '2', '20090 1191182336 3 13903 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20089', '2', '20089 1191182336 3 16653 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20088', '2', '20088 1191182336 3 13874 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20087', '2', '20087 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20086', '2', '20086 1191182336 3 31194 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 31 4294967260 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20085', '2', '20085 1191182336 3 37160 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20084', '2', '20084 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20083', '2', '20083 1191182336 3 32470 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20082', '2', '20082 1191182336 3 36288 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 108 4294967290 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20081', '2', '20081 1191182336 3 4359 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20080', '2', '20080 1191182336 3 21590 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20079', '2', '20079 1191182336 3 37756 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20078', '2', '20078 1191182336 3 14549 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19883', '2', '19883 1191182336 3 32717 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19884', '2', '19884 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19885', '2', '19885 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19886', '2', '19886 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19887', '2', '19887 1191182336 3 2734 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19888', '2', '19888 1191182336 3 30810 1065353216 0 2 0 2 0 0 0 0 0 53 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19889', '2', '19889 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19890', '2', '19890 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 13 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19891', '2', '19891 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19892', '2', '19892 1191182336 3 3844 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19893', '2', '19893 1191182336 3 935 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19894', '2', '19894 1191182336 3 36147 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 72 4294967286 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19895', '2', '19895 1191182336 3 32620 1065353216 0 2 0 2 0 0 0 0 0 174 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19896', '2', '19896 1191182336 3 9406 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19897', '2', '19897 1191182336 3 36152 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 97 4294967289 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19898', '2', '19898 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19899', '2', '19899 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19900', '2', '19900 1191182336 3 23320 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19901', '2', '19901 1191182336 3 13916 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19902', '2', '19902 1191182336 3 36272 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 101 4294967280 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19903', '2', '19903 1191182336 3 36609 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 97 4294967280 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19904', '2', '19904 1191182336 3 2039 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19905', '2', '19905 1191182336 3 1489 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 95 95 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19906', '2', '19906 1191182336 3 31191 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 30 4294967287 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19907', '2', '19907 1191182336 3 12238 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19908', '2', '19908 1191182336 3 8106 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19909', '2', '19909 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 15 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19910', '2', '19910 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19911', '2', '19911 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19912', '2', '19912 1191182336 3 29426 1065353216 0 2 0 2 0 0 0 0 0 95 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19913', '2', '19913 1191182336 3 31184 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2818 0 0 0 0 0 0 0 0 0 0 0 49 4294967264 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19914', '2', '19914 1191182336 3 21228 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19915', '2', '19915 1191182336 3 20708 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19916', '2', '19916 1191182336 3 3323 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 14 14 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19917', '2', '19917 1191182336 3 1993 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19918', '2', '19918 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19919', '2', '19919 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19920', '2', '19920 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19921', '2', '19921 1191182336 3 5111 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19922', '2', '19922 1191182336 3 36609 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 97 4294967260 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19923', '2', '19923 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 7 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19924', '2', '19924 1191182336 3 35652 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19925', '2', '19925 1191182336 3 31177 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2823 0 0 0 0 0 0 0 0 40 4294967253 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19926', '2', '19926 1191182336 3 28493 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2823 0 0 2803 0 0 0 0 0 0 0 0 41 4294967242 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19927', '2', '19927 1191182336 3 4481 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19928', '2', '19928 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 12 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19929', '2', '19929 1191182336 3 2725 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19930', '2', '19930 1191182336 3 20545 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19931', '2', '19931 1191182336 3 36567 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 42 4294967285 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19932', '2', '19932 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19933', '2', '19933 1191182336 3 9392 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19934', '2', '19934 1191182336 3 10561 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19935', '2', '19935 1191182336 3 35654 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19936', '2', '19936 1191182336 3 5624 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19937', '2', '19937 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19938', '2', '19938 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19939', '2', '19939 1191182336 3 25032 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 22 4294967255 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19940', '2', '19940 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19941', '2', '19941 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19942', '2', '19942 1191182336 3 36266 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 54 4294967291 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19943', '2', '19943 1191182336 3 5635 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19944', '2', '19944 1191182336 3 8366 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19945', '2', '19945 1191182336 3 36527 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 45 4294967251 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19946', '2', '19946 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19947', '2', '19947 1191182336 3 31232 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 4294967270 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19948', '2', '19948 1191182336 3 31554 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 63 4294967258 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19949', '2', '19949 1191182336 3 27515 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19950', '2', '19950 1191182336 3 45861 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19951', '2', '19951 1191182336 3 37770 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19952', '2', '19952 1191182336 3 25004 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 39 4294967260 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19953', '2', '19953 1191182336 3 9384 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19954', '2', '19954 1191182336 3 19441 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19955', '2', '19955 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19956', '2', '19956 1191182336 3 13003 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19957', '2', '19957 1191182336 3 816 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19958', '2', '19958 1191182336 3 31168 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 47 4294967252 135 135 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19959', '2', '19959 1191182336 3 9393 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19960', '2', '19960 1191182336 3 1440 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19961', '2', '19961 1191182336 3 28492 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 41 4294967247 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19962', '2', '19962 1191182336 3 2282 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19963', '2', '19963 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19964', '2', '19964 1191182336 3 16671 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19965', '2', '19965 1191182336 3 5759 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19966', '2', '19966 1191182336 3 31224 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 33 4294967288 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19967', '2', '19967 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19968', '2', '19968 1191182336 3 36456 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 56 4294967255 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19969', '2', '19969 1191182336 3 31180 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19970', '2', '19970 1191182336 3 5020 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19971', '2', '19971 1191182336 3 44666 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 101 4294967256 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19972', '2', '19972 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19973', '2', '19973 1191182336 3 4589 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19974', '2', '19974 1191182336 3 25243 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 13 4294967256 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19975', '2', '19975 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19976', '2', '19976 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19977', '2', '19977 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19978', '2', '19978 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19979', '2', '19979 1191182336 3 27513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19980', '2', '19980 1191182336 3 31229 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 40 4294967254 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19981', '2', '19981 1191182336 3 3331 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19982', '2', '19982 1191182336 3 24828 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 4294967281 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19983', '2', '19983 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19984', '2', '19984 1191182336 3 35664 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19985', '2', '19985 1191182336 3 24666 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2821 0 0 0 0 0 0 0 0 0 0 0 52 4294967261 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19986', '2', '19986 1191182336 3 4723 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19987', '2', '19987 1191182336 3 6148 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19988', '2', '19988 1191182336 3 31248 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 38 4294967256 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19989', '2', '19989 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19990', '2', '19990 1191182336 3 13880 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19991', '2', '19991 1191182336 3 20676 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19992', '2', '19992 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19993', '2', '19993 1191182336 3 10561 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19994', '2', '19994 1191182336 3 10403 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19995', '2', '19995 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19996', '2', '19996 1191182336 3 12804 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19997', '2', '19997 1191182336 3 13023 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19998', '2', '19998 1191182336 3 871 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 105 105 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19999', '2', '19999 1191182336 3 5767 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20000', '2', '20000 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20001', '2', '20001 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20002', '2', '20002 1191182336 3 25074 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 22 4294967260 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20003', '2', '20003 1191182336 3 9253 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20004', '2', '20004 1191182336 3 1926 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20005', '2', '20005 1191182336 3 8483 1065353216 0 2 0 2 0 0 0 0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20006', '2', '20006 1191182336 3 31170 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2821 0 0 0 0 0 0 0 0 0 0 0 47 4294967261 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20007', '2', '20007 1191182336 3 14553 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20008', '2', '20008 1191182336 3 13880 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20009', '2', '20009 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20010', '2', '20010 1191182336 3 6651 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20011', '2', '20011 1191182336 3 1981 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 140 140 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20012', '2', '20012 1191182336 3 36743 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20013', '2', '20013 1191182336 3 866 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1070 0 0 0 0 0 0 0 0 0 334 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20014', '2', '20014 1191182336 3 2227 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20015', '2', '20015 1191182336 3 1726 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20016', '2', '20016 1191182336 3 6353 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20017', '2', '20017 1191182336 3 4589 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20018', '2', '20018 1191182336 3 1443 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20019', '2', '20019 1191182336 3 30722 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20020', '2', '20020 1191182336 3 20658 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 362 0 0 363 0 0 361 0 0 0 2150 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20021', '2', '20021 1191182336 3 3048 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20022', '2', '20022 1191182336 3 17965 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20023', '2', '20023 1191182336 3 30736 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20024', '2', '20024 1191182336 3 4449 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20025', '2', '20025 1191182336 3 37771 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20026', '2', '20026 1191182336 3 30730 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20027', '2', '20027 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20028', '2', '20028 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20029', '2', '20029 1191182336 3 14558 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20030', '2', '20030 1191182336 3 31200 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20031', '2', '20031 1191182336 3 4632 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20032', '2', '20032 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20033', '2', '20033 1191182336 3 31882 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20034', '2', '20034 1191182336 3 31227 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2819 0 0 0 0 0 0 0 0 0 0 0 40 4294967263 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20035', '2', '20035 1191182336 3 13905 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20036', '2', '20036 1191182336 3 25088 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 22 4294967290 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20037', '2', '20037 1191182336 3 31214 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2823 0 0 0 0 0 0 0 0 46 4294967253 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20038', '2', '20038 1191182336 3 16714 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20039', '2', '20039 1191182336 3 944 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20040', '2', '20040 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20041', '2', '20041 1191182336 3 44155 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20042', '2', '20042 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20043', '2', '20043 1191182336 3 36486 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 46 4294967257 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20044', '2', '20044 1191182336 3 1608 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 92 0 0 108 0 0 0 0 0 0 684 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20045', '2', '20045 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20046', '2', '20046 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 19 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20047', '2', '20047 1191182336 3 9361 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20048', '2', '20048 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20049', '2', '20049 1191182336 3 2100 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20050', '2', '20050 1191182336 3 39970 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20051', '2', '20051 1191182336 3 36485 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 45 4294967255 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20052', '2', '20052 1191182336 3 25152 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 22 4294967290 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20053', '2', '20053 1191182336 3 814 1065353216 0 2 0 2 0 0 0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20054', '2', '20054 1191182336 3 30723 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20055', '2', '20055 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20056', '2', '20056 1191182336 3 27515 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20057', '2', '20057 1191182336 3 24291 1065353216 0 2 0 2 0 0 0 0 0 139 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20058', '2', '20058 1191182336 3 21561 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20059', '2', '20059 1191182336 3 13874 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20060', '2', '20060 1191182336 3 13001 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20061', '2', '20061 1191182336 3 7973 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20062', '2', '20062 1191182336 3 1475 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20063', '2', '20063 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20064', '2', '20064 1191182336 3 36003 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 62 4294967288 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20065', '2', '20065 1191182336 3 8226 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20066', '2', '20066 1191182336 3 14552 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20067', '2', '20067 1191182336 3 1315 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20068', '2', '20068 1191182336 3 11415 1065353216 0 2 0 2 0 0 0 0 0 7 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20069', '2', '20069 1191182336 3 8151 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20070', '2', '20070 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20071', '2', '20071 1191182336 3 1982 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20072', '2', '20072 1191182336 3 826 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20073', '2', '20073 1191182336 3 18711 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20074', '2', '20074 1191182336 3 36582 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 43 4294967251 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20075', '2', '20075 1191182336 3 2164 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20076', '2', '20076 1191182336 3 31182 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 49 4294967255 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20077', '2', '20077 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19882', '2', '19882 1191182336 3 5635 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19881', '2', '19881 1191182336 3 31174 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 47 4294967257 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19880', '2', '19880 1191182336 3 826 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19879', '2', '19879 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19878', '2', '19878 1191182336 3 20676 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19877', '2', '19877 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19876', '2', '19876 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19875', '2', '19875 1191182336 3 30722 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19874', '2', '19874 1191182336 3 19258 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19873', '2', '19873 1191182336 3 2567 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19872', '2', '19872 1191182336 3 16717 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19871', '2', '19871 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19870', '2', '19870 1191182336 3 1443 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19869', '2', '19869 1191182336 3 1204 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19868', '2', '19868 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19867', '2', '19867 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19866', '2', '19866 1191182336 3 2567 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19865', '2', '19865 1191182336 3 10560 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19864', '2', '19864 1191182336 3 14554 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19863', '2', '19863 1191182336 3 14553 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19862', '2', '19862 1191182336 3 24476 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19861', '2', '19861 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19860', '2', '19860 1191182336 3 36046 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 75 4294967287 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19859', '2', '19859 1191182336 3 2163 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19858', '2', '19858 1191182336 3 16655 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19857', '2', '19857 1191182336 3 44708 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19856', '2', '19856 1191182336 3 22528 1065353216 0 2 0 2 0 0 0 0 0 215 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19855', '2', '19855 1191182336 3 13755 1065353216 0 2 0 2 0 0 0 0 0 12 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19854', '2', '19854 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19853', '2', '19853 1191182336 3 1297 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19852', '2', '19852 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19851', '2', '19851 1191182336 3 31168 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 47 4294967260 135 135 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19850', '2', '19850 1191182336 3 2246 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19849', '2', '19849 1191182336 3 24724 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 23 4294967256 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19848', '2', '19848 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19847', '2', '19847 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19846', '2', '19846 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19845', '2', '19845 1191182336 3 24934 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 30 4294967255 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19844', '2', '19844 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19843', '2', '19843 1191182336 3 4044 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19842', '2', '19842 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19841', '2', '19841 1191182336 3 1263 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19840', '2', '19840 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19839', '2', '19839 1191182336 3 13422 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19838', '2', '19838 1191182336 3 14554 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19837', '2', '19837 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19836', '2', '19836 1191182336 3 2745 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19835', '2', '19835 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19834', '2', '19834 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19833', '2', '19833 1191182336 3 36597 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 104 4294967285 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19832', '2', '19832 1191182336 3 24245 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19831', '2', '19831 1191182336 3 36159 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 101 4294967256 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19830', '2', '19830 1191182336 3 25002 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 52 4294967286 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19829', '2', '19829 1191182336 3 1982 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19828', '2', '19828 1191182336 3 36163 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2820 0 0 0 0 0 0 0 0 0 0 0 78 4294967262 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19827', '2', '19827 1191182336 3 24779 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 39 4294967286 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19826', '2', '19826 1191182336 3 1521 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19825', '2', '19825 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19824', '2', '19824 1191182336 3 24773 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 39 4294967255 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19823', '2', '19823 1191182336 3 869 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 105 105 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19822', '2', '19822 1191182336 3 5749 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19821', '2', '19821 1191182336 3 36167 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 0 0 0 104 4294967279 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19820', '2', '19820 1191182336 3 6311 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19819', '2', '19819 1191182336 3 2099 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19818', '2', '19818 1191182336 3 1913 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19817', '2', '19817 1191182336 3 1677 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19816', '2', '19816 1191182336 3 36398 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 81 4294967287 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19815', '2', '19815 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19814', '2', '19814 1191182336 3 2245 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19813', '2', '19813 1191182336 3 17054 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19812', '2', '19812 1191182336 3 38303 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19811', '2', '19811 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19810', '2', '19810 1191182336 3 31161 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 46 4294967275 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19809', '2', '19809 1191182336 3 871 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 105 105 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19808', '2', '19808 1191182336 3 2246 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19807', '2', '19807 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19806', '2', '19806 1191182336 3 32470 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19805', '2', '19805 1191182336 3 36415 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 58 4294967256 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19804', '2', '19804 1191182336 3 38513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19803', '2', '19803 1191182336 3 44157 1065353216 0 2 0 2 0 0 0 0 0 17 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19802', '2', '19802 1191182336 3 1475 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19801', '2', '19801 1191182336 3 1608 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 92 0 0 104 0 0 0 0 0 0 599 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19800', '2', '19800 1191182336 3 43624 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19799', '2', '19799 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19798', '2', '19798 1191182336 3 25326 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 40 4294967255 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19797', '2', '19797 1191182336 3 2100 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19796', '2', '19796 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19795', '2', '19795 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19794', '2', '19794 1191182336 3 37756 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19793', '2', '19793 1191182336 3 3260 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19792', '2', '19792 1191182336 3 7755 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19791', '2', '19791 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19790', '2', '19790 1191182336 3 2232 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19789', '2', '19789 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19778', '10', '19778 1191182336 3 20891 1065353216 0 10 0 10 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19780', '10', '19780 1191182336 3 53 1065353216 0 10 0 10 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19782', '10', '19782 1191182336 3 52 1065353216 0 10 0 10 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19784', '10', '19784 1191182336 3 20978 1065353216 0 10 0 10 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19786', '10', '19786 1191182336 3 51 1065353216 0 10 0 10 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('19788', '10', '19788 1191182336 3 6948 1065353216 0 10 0 10 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21844', '2', '21844 1191182336 3 2204 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21845', '2', '21845 1191182336 3 1679 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21846', '2', '21846 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21847', '2', '21847 1191182336 3 36042 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 54 4294967288 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21848', '2', '21848 1191182336 3 832 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21849', '2', '21849 1191182336 3 27513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21850', '2', '21850 1191182336 3 27513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21851', '2', '21851 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21852', '2', '21852 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21853', '2', '21853 1191182336 3 25334 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 52 4294967282 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21854', '2', '21854 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21855', '2', '21855 1191182336 3 12804 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21856', '2', '21856 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21857', '2', '21857 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21858', '2', '21858 1191182336 3 27515 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21859', '2', '21859 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21860', '2', '21860 1191182336 3 24602 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 4294967281 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21861', '2', '21861 1191182336 3 10560 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21862', '2', '21862 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21863', '2', '21863 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21864', '2', '21864 1191182336 3 25054 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 29 4294967258 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21865', '2', '21865 1191182336 3 1475 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21866', '2', '21866 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21867', '2', '21867 1191182336 3 36781 1065353216 0 2 0 2 0 0 0 0 0 19 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21868', '2', '21868 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21869', '2', '21869 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21870', '2', '21870 1191182336 3 36781 1065353216 0 2 0 2 0 0 0 0 0 15 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21871', '2', '21871 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21872', '2', '21872 1191182336 3 18674 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21873', '2', '21873 1191182336 3 18672 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21874', '2', '21874 1191182336 3 7973 1065353216 0 2 0 2 0 0 0 0 0 11 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21875', '2', '21875 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21876', '2', '21876 1191182336 3 24717 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 31 4294967254 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21877', '2', '21877 1191182336 3 36044 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 75 4294967287 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21878', '2', '21878 1191182336 3 1925 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21879', '2', '21879 1191182336 3 13757 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21880', '2', '21880 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21881', '2', '21881 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21882', '2', '21882 1191182336 3 14900 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 360 0 0 367 0 0 0 0 0 0 1123 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21883', '2', '21883 1191182336 3 37145 1065353216 0 2 0 2 0 0 0 0 0 17 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21884', '2', '21884 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21885', '2', '21885 1191182336 3 36058 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 58 4294967260 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21886', '2', '21886 1191182336 3 10331 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21887', '2', '21887 1191182336 3 7072 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21888', '2', '21888 1191182336 3 2167 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21889', '2', '21889 1191182336 3 24775 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 52 4294967284 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21890', '2', '21890 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21891', '2', '21891 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21892', '2', '21892 1191182336 3 24893 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 29 4294967252 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21893', '2', '21893 1191182336 3 5750 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21894', '2', '21894 1191182336 3 5028 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21895', '2', '21895 1191182336 3 24713 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 40 4294967256 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21896', '2', '21896 1191182336 3 24779 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 39 4294967254 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21897', '2', '21897 1191182336 3 36709 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 104 4294967282 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21898', '2', '21898 1191182336 3 32718 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21899', '2', '21899 1191182336 3 3569 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21900', '2', '21900 1191182336 3 24601 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 4294967275 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21901', '2', '21901 1191182336 3 1608 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 92 0 0 108 0 0 0 0 0 0 684 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21902', '2', '21902 1191182336 3 36040 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 97 4294967260 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21903', '2', '21903 1191182336 3 36640 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 34 4294967256 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21904', '2', '21904 1191182336 3 5750 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21905', '2', '21905 1191182336 3 2254 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21906', '2', '21906 1191182336 3 36458 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 60 4294967252 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21907', '2', '21907 1191182336 3 36667 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 33 4294967259 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21908', '2', '21908 1191182336 3 1927 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21909', '2', '21909 1191182336 3 1929 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21910', '2', '21910 1191182336 3 24998 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 39 4294967270 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21911', '2', '21911 1191182336 3 1460 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21912', '2', '21912 1191182336 3 3057 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('17688', '6', '17688 1191182336 3 1414 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('17687', '6', '17687 1191182336 3 2589 1065353216 0 6 0 6 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('17686', '6', '17686 1191182336 3 20765 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('17685', '6', '17685 1191182336 3 1377 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 12 0 0 ', '');
INSERT INTO `item_instance` VALUES ('17684', '6', '17684 1191182336 3 2653 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 18 18 0 0 ', '');
INSERT INTO `item_instance` VALUES ('17683', '6', '17683 1191182336 3 23354 1065353216 0 6 0 6 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21254', '2', '21254 1191182336 3 28498 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 2804 0 0 2813 0 0 0 0 0 0 0 0 34 4294967244 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21640', '2', '21640 1191182336 3 5635 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21639', '2', '21639 1191182336 3 13422 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21638', '2', '21638 1191182336 3 27515 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21637', '2', '21637 1191182336 3 27513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21636', '2', '21636 1191182336 3 2084 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21635', '2', '21635 1191182336 3 5742 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21634', '2', '21634 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21633', '2', '21633 1191182336 3 41119 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21632', '2', '21632 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 17 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21631', '2', '21631 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21630', '2', '21630 1191182336 3 25117 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 17 4294967251 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21629', '2', '21629 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21628', '2', '21628 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21627', '2', '21627 1191182336 3 4303 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21626', '2', '21626 1191182336 3 24589 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 29 4294967260 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21625', '2', '21625 1191182336 3 8350 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21624', '11', '21624 1191182336 3 40582 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21622', '11', '21622 1191182336 3 41751 1065353216 0 11 0 11 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21620', '11', '21620 1191182336 3 38147 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21618', '11', '21618 1191182336 7 38145 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21616', '11', '21616 1191182336 7 38145 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21614', '11', '21614 1191182336 7 38145 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21612', '11', '21612 1191182336 7 38145 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21610', '11', '21610 1191182336 3 34658 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21608', '11', '21608 1191182336 3 34657 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21606', '11', '21606 1191182336 3 34648 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21604', '11', '21604 1191182336 3 34656 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21602', '11', '21602 1191182336 3 34651 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21600', '11', '21600 1191182336 3 34649 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21598', '11', '21598 1191182336 3 34653 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21596', '11', '21596 1191182336 3 34650 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 115 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21594', '11', '21594 1191182336 3 34659 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21592', '11', '21592 1191182336 3 34655 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21590', '11', '21590 1191182336 3 34652 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21588', '2', '21588 1191182336 3 25172 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2823 0 0 0 0 0 0 0 0 40 4294967253 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21587', '2', '21587 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21586', '2', '21586 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21585', '2', '21585 1191182336 3 13757 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21584', '2', '21584 1191182336 3 25088 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 22 4294967281 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21583', '2', '21583 1191182336 3 20653 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 367 0 0 363 0 0 366 0 0 0 2154 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21582', '2', '21582 1191182336 3 4723 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21581', '2', '21581 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21580', '2', '21580 1191182336 3 35979 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 56 4294967260 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21579', '2', '21579 1191182336 3 27511 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21578', '2', '21578 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21577', '2', '21577 1191182336 3 2265 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21576', '2', '21576 1191182336 3 3011 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21575', '2', '21575 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21574', '2', '21574 1191182336 3 4359 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21573', '2', '21573 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21572', '2', '21572 1191182336 3 25046 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 22 4294967286 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21571', '2', '21571 1191182336 3 12804 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21570', '2', '21570 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21569', '2', '21569 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21568', '2', '21568 1191182336 3 36154 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 54 4294967254 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21567', '2', '21567 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21566', '2', '21566 1191182336 3 24887 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 39 4294967289 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21565', '2', '21565 1191182336 3 27511 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21564', '2', '21564 1191182336 3 36011 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 64 4294967287 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21563', '2', '21563 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21562', '2', '21562 1191182336 3 6333 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21561', '2', '21561 1191182336 3 10561 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21560', '2', '21560 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21559', '2', '21559 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21558', '2', '21558 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21557', '2', '21557 1191182336 3 4589 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21556', '2', '21556 1191182336 3 6205 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21555', '2', '21555 1191182336 3 37145 1065353216 0 2 0 2 0 0 0 0 0 17 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21554', '2', '21554 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21553', '2', '21553 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21552', '2', '21552 1191182336 3 4439 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21551', '2', '21551 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21550', '2', '21550 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21549', '2', '21549 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21548', '2', '21548 1191182336 3 19943 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21547', '2', '21547 1191182336 3 36498 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 43 4294967251 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21546', '2', '21546 1191182336 3 36273 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2818 0 0 0 0 0 0 0 0 0 0 0 75 4294967264 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21545', '2', '21545 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21544', '2', '21544 1191182336 3 36380 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 75 4294967287 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21543', '2', '21543 1191182336 3 36626 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 34 4294967256 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21542', '2', '21542 1191182336 3 24609 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 41 4294967274 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21541', '2', '21541 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21540', '2', '21540 1191182336 3 24601 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 40 4294967260 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21539', '2', '21539 1191182336 3 28497 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2823 0 0 2803 0 0 0 0 0 0 0 0 34 4294967242 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21538', '2', '21538 1191182336 3 24773 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 39 4294967286 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21537', '2', '21537 1191182336 3 36003 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2820 0 0 0 0 0 0 0 0 0 0 0 62 4294967262 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21536', '2', '21536 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21535', '2', '21535 1191182336 3 4464 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21534', '2', '21534 1191182336 3 3341 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21533', '2', '21533 1191182336 3 31264 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 2803 0 0 2804 0 0 0 0 0 0 0 0 5 4294967238 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21532', '2', '21532 1191182336 3 1475 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21531', '2', '21531 1191182336 3 8151 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21530', '2', '21530 1191182336 3 4637 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21529', '2', '21529 1191182336 3 1314 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21528', '2', '21528 1191182336 3 25061 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2819 0 0 0 0 0 0 0 0 0 0 0 23 4294967263 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21527', '2', '21527 1191182336 3 1959 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21526', '2', '21526 1191182336 3 24828 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 30 4294967256 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21525', '2', '21525 1191182336 3 5182 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21524', '2', '21524 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21523', '2', '21523 1191182336 3 31264 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 2806 0 0 0 0 0 0 0 0 5 4294967237 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21522', '2', '21522 1191182336 3 1475 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21521', '2', '21521 1191182336 3 36514 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 108 4294967291 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21520', '2', '21520 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 11 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21519', '2', '21519 1191182336 3 24665 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2818 0 0 0 0 0 0 0 0 0 0 0 52 4294967264 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21518', '2', '21518 1191182336 3 12804 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21517', '2', '21517 1191182336 3 789 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2310 0 0 0 0 0 0 0 0 0 2030 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21516', '2', '21516 1191182336 3 892 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21515', '2', '21515 1191182336 3 36696 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 46 4294967290 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21514', '2', '21514 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21513', '2', '21513 1191182336 3 5079 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21512', '2', '21512 1191182336 3 7973 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21511', '2', '21511 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21510', '2', '21510 1191182336 3 24999 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 39 4294967251 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21509', '2', '21509 1191182336 3 1475 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21508', '2', '21508 1191182336 3 7072 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21507', '2', '21507 1191182336 3 36167 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 104 4294967256 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21506', '2', '21506 1191182336 3 10400 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21505', '2', '21505 1191182336 3 13757 1065353216 0 2 0 2 0 0 0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21504', '2', '21504 1191182336 3 41119 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21503', '2', '21503 1191182336 3 37160 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21502', '2', '21502 1191182336 3 24612 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 23 4294967288 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21501', '2', '21501 1191182336 3 14895 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 366 0 0 367 0 0 0 0 0 0 1209 115 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21500', '2', '21500 1191182336 3 24685 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 42 4294967260 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21499', '2', '21499 1191182336 3 4465 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21498', '2', '21498 1191182336 3 37145 1065353216 0 2 0 2 0 0 0 0 0 15 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21497', '2', '21497 1191182336 3 36584 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 46 4294967289 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21496', '2', '21496 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21495', '2', '21495 1191182336 3 24888 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 52 4294967281 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21494', '2', '21494 1191182336 3 5112 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21493', '2', '21493 1191182336 3 37160 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21492', '2', '21492 1191182336 3 4589 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21491', '2', '21491 1191182336 3 36584 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 46 4294967288 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21490', '2', '21490 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21489', '2', '21489 1191182336 3 19943 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21488', '2', '21488 1191182336 3 12804 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21487', '2', '21487 1191182336 3 4810 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21486', '2', '21486 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21485', '2', '21485 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21484', '2', '21484 1191182336 3 1677 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21483', '2', '21483 1191182336 3 24722 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 41 4294967256 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21482', '2', '21482 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21481', '2', '21481 1191182336 3 6199 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21480', '2', '21480 1191182336 3 2166 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21479', '2', '21479 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21478', '2', '21478 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21477', '2', '21477 1191182336 3 25312 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 17 4294967281 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21476', '2', '21476 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21475', '2', '21475 1191182336 3 36158 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 75 4294967284 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21474', '2', '21474 1191182336 3 1955 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21473', '2', '21473 1191182336 3 36444 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 60 4294967259 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21472', '2', '21472 1191182336 3 4634 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21471', '2', '21471 1191182336 3 4768 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 18 18 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21470', '2', '21470 1191182336 3 37160 1065353216 0 2 0 2 0 0 0 0 0 17 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21469', '2', '21469 1191182336 3 15687 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2170 0 0 0 0 0 0 0 0 0 1890 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21468', '2', '21468 1191182336 3 36372 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 72 4294967270 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21467', '2', '21467 1191182336 3 1314 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21466', '2', '21466 1191182336 3 7072 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21465', '2', '21465 1191182336 3 10141 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1120 0 0 1070 0 0 0 0 0 0 887 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21464', '2', '21464 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21463', '2', '21463 1191182336 3 37160 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21462', '2', '21462 1191182336 3 24944 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 41 4294967289 115 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21461', '2', '21461 1191182336 3 2981 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21460', '2', '21460 1191182336 3 35955 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2819 0 0 0 0 0 0 0 0 0 0 0 50 4294967263 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21459', '2', '21459 1191182336 3 25047 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 23 4294967256 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21458', '2', '21458 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21457', '2', '21457 1191182336 3 36398 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2822 0 0 2824 0 0 0 0 0 0 0 0 81 4294967229 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21456', '2', '21456 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21455', '2', '21455 1191182336 3 3076 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21454', '2', '21454 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 7 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21453', '2', '21453 1191182336 3 4589 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21452', '2', '21452 1191182336 3 8284 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21451', '2', '21451 1191182336 3 36485 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 45 4294967256 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21450', '2', '21450 1191182336 3 15687 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1119 0 0 0 0 0 0 0 0 0 384 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21449', '2', '21449 1191182336 3 24611 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 31 4294967290 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21448', '2', '21448 1191182336 3 1287 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21447', '2', '21447 1191182336 3 36275 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 78 4294967277 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21446', '2', '21446 1191182336 3 20655 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 366 0 0 2317 0 0 2373 0 0 0 2153 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21445', '2', '21445 1191182336 3 31256 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 2803 0 0 2804 0 0 0 0 0 0 0 0 5 4294967238 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21444', '2', '21444 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21443', '2', '21443 1191182336 3 5967 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21442', '2', '21442 1191182336 3 2203 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21441', '2', '21441 1191182336 3 16654 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21440', '2', '21440 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21439', '2', '21439 1191182336 3 25033 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 23 4294967260 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21255', '2', '21255 1191182336 3 8283 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21256', '2', '21256 1191182336 3 27515 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21257', '2', '21257 1191182336 3 25186 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 0 0 0 0 0 0 0 0 0 0 0 0 17 4294967278 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21258', '2', '21258 1191182336 3 25200 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 17 4294967252 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21259', '2', '21259 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21260', '2', '21260 1191182336 3 10367 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 363 0 0 366 0 0 0 0 0 0 614 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21261', '2', '21261 1191182336 3 25215 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 41 4294967288 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21262', '2', '21262 1191182336 3 1446 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21263', '2', '21263 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21264', '2', '21264 1191182336 3 2899 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21265', '2', '21265 1191182336 3 24476 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21266', '2', '21266 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21267', '2', '21267 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21268', '2', '21268 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21269', '2', '21269 1191182336 3 14812 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21270', '2', '21270 1191182336 3 25257 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 13 4294967255 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21271', '2', '21271 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21272', '2', '21272 1191182336 3 36554 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 101 4294967256 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21273', '2', '21273 1191182336 3 1945 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21274', '2', '21274 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21275', '2', '21275 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21276', '2', '21276 1191182336 3 36484 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 43 4294967288 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21277', '2', '21277 1191182336 3 36156 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 4294967270 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21278', '2', '21278 1191182336 3 28495 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2811 0 0 2803 0 0 2804 0 0 0 0 0 0 0 0 34 4294967241 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21279', '2', '21279 1191182336 3 36396 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 81 4294967284 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21280', '2', '21280 1191182336 3 9249 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21281', '2', '21281 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21282', '2', '21282 1191182336 3 19943 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21283', '2', '21283 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21284', '2', '21284 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21285', '2', '21285 1191182336 3 25062 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 24 4294967257 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21286', '2', '21286 1191182336 3 3186 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 76 0 0 69 0 0 0 0 0 0 673 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21287', '2', '21287 1191182336 3 37145 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21288', '2', '21288 1191182336 3 4589 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21289', '2', '21289 1191182336 3 32717 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21290', '2', '21290 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21291', '2', '21291 1191182336 3 36158 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 75 4294967256 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21292', '2', '21292 1191182336 3 36708 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 101 4294967289 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21293', '2', '21293 1191182336 3 10561 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21294', '2', '21294 1191182336 3 36667 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 33 4294967257 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21295', '2', '21295 1191182336 3 12804 1065353216 0 2 0 2 0 0 0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21296', '2', '21296 1191182336 3 2015 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21297', '2', '21297 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21298', '2', '21298 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21299', '2', '21299 1191182336 3 9249 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21300', '2', '21300 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21301', '2', '21301 1191182336 3 3053 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21302', '2', '21302 1191182336 3 24949 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 23 4294967260 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21303', '2', '21303 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21304', '2', '21304 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21305', '2', '21305 1191182336 3 1938 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21306', '2', '21306 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21307', '2', '21307 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21308', '2', '21308 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21309', '2', '21309 1191182336 3 14899 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 358 0 0 361 0 0 0 0 0 0 611 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21310', '2', '21310 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21311', '2', '21311 1191182336 3 10561 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21312', '2', '21312 1191182336 3 36274 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 0 0 0 56 4294967279 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21313', '2', '21313 1191182336 3 8224 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21314', '2', '21314 1191182336 3 36274 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 56 4294967289 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21315', '2', '21315 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21316', '2', '21316 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21317', '2', '21317 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21318', '2', '21318 1191182336 3 1523 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21319', '2', '21319 1191182336 3 36063 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 108 4294967274 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21320', '2', '21320 1191182336 3 3019 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21321', '2', '21321 1191182336 3 36525 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 42 4294967285 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21322', '2', '21322 1191182336 3 2265 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21323', '2', '21323 1191182336 3 7072 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21324', '2', '21324 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 19 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21325', '2', '21325 1191182336 3 756 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21326', '2', '21326 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21327', '2', '21327 1191182336 3 37160 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21328', '2', '21328 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21329', '2', '21329 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21330', '2', '21330 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 12 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21331', '2', '21331 1191182336 3 24476 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21332', '2', '21332 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21333', '2', '21333 1191182336 3 4359 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21334', '2', '21334 1191182336 3 36166 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 78 4294967259 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21335', '2', '21335 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21336', '2', '21336 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21337', '2', '21337 1191182336 3 37145 1065353216 0 2 0 2 0 0 0 0 0 7 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21338', '2', '21338 1191182336 3 1214 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21339', '2', '21339 1191182336 3 4676 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21340', '2', '21340 1191182336 3 36266 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 54 4294967252 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21341', '2', '21341 1191182336 3 25116 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 17 4294967287 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21342', '2', '21342 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21343', '2', '21343 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21344', '2', '21344 1191182336 3 36372 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2813 0 0 0 0 0 0 0 0 0 0 0 0 0 0 72 4294967269 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21345', '2', '21345 1191182336 3 27511 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21346', '2', '21346 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21347', '2', '21347 1191182336 3 7072 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21348', '2', '21348 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21349', '2', '21349 1191182336 3 17965 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21350', '2', '21350 1191182336 3 25292 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 4294967274 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21351', '2', '21351 1191182336 3 10135 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1082 0 0 0 0 0 0 0 0 0 346 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21352', '2', '21352 1191182336 3 24476 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21353', '2', '21353 1191182336 3 44703 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21354', '2', '21354 1191182336 3 4660 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21355', '2', '21355 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21356', '2', '21356 1191182336 3 36388 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 78 4294967285 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21357', '2', '21357 1191182336 3 1448 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21358', '2', '21358 1191182336 3 32717 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21359', '2', '21359 1191182336 3 5758 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21360', '2', '21360 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21361', '2', '21361 1191182336 3 2823 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21362', '2', '21362 1191182336 3 4477 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21363', '2', '21363 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21364', '2', '21364 1191182336 3 36265 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2825 0 0 0 0 0 0 0 0 0 0 0 0 0 0 72 4294967276 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21365', '2', '21365 1191182336 3 4359 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21366', '2', '21366 1191182336 3 10560 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21367', '2', '21367 1191182336 3 19441 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21368', '2', '21368 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21369', '2', '21369 1191182336 3 19943 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21370', '2', '21370 1191182336 3 36666 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 32 4294967258 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21371', '2', '21371 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21372', '2', '21372 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21373', '2', '21373 1191182336 3 36399 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 0 0 0 108 4294967279 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21374', '2', '21374 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21375', '2', '21375 1191182336 3 4463 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21376', '2', '21376 1191182336 3 24711 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2817 0 0 0 0 0 0 0 0 0 0 0 40 4294967265 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21377', '2', '21377 1191182336 3 24892 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2823 0 0 0 0 0 0 0 0 39 4294967253 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21378', '2', '21378 1191182336 3 10560 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21379', '2', '21379 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21380', '2', '21380 1191182336 3 5635 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21381', '2', '21381 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21382', '2', '21382 1191182336 3 1936 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21383', '2', '21383 1191182336 3 36470 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 56 4294967288 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21384', '2', '21384 1191182336 3 15687 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2132 0 0 0 0 0 0 0 0 0 1852 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21385', '2', '21385 1191182336 3 4634 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21386', '2', '21386 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21387', '2', '21387 1191182336 3 35971 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2820 0 0 0 0 0 0 0 0 0 0 0 53 4294967262 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21388', '2', '21388 1191182336 3 1933 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21389', '2', '21389 1191182336 3 20406 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21390', '2', '21390 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21391', '2', '21391 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21392', '2', '21392 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21393', '2', '21393 1191182336 3 9480 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21394', '2', '21394 1191182336 3 36163 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 78 4294967283 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21395', '2', '21395 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21396', '2', '21396 1191182336 3 36457 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 58 4294967252 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21397', '2', '21397 1191182336 3 22277 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21398', '2', '21398 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21399', '2', '21399 1191182336 3 1664 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21400', '2', '21400 1191182336 3 2054 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21401', '2', '21401 1191182336 3 2730 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21402', '2', '21402 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21403', '2', '21403 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21404', '2', '21404 1191182336 3 4359 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21405', '2', '21405 1191182336 3 6292 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21406', '2', '21406 1191182336 3 7072 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21407', '2', '21407 1191182336 3 3643 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 18 18 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21408', '2', '21408 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21409', '2', '21409 1191182336 3 24476 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21410', '2', '21410 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21411', '2', '21411 1191182336 3 1461 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21412', '2', '21412 1191182336 3 2265 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21413', '2', '21413 1191182336 3 36667 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 33 4294967257 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21414', '2', '21414 1191182336 3 2281 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21415', '2', '21415 1191182336 3 5256 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21416', '2', '21416 1191182336 3 20518 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21417', '2', '21417 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21418', '2', '21418 1191182336 3 10407 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21419', '2', '21419 1191182336 3 28531 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 12 4294967256 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21420', '2', '21420 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 17 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21421', '2', '21421 1191182336 3 25744 1065353216 0 2 0 2 0 0 0 0 0 172 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21422', '2', '21422 1191182336 3 25062 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 24 4294967252 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21423', '2', '21423 1191182336 3 36400 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 108 4294967286 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21424', '2', '21424 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21425', '2', '21425 1191182336 3 36285 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2822 0 0 2824 0 0 0 0 0 0 0 0 108 4294967229 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21426', '2', '21426 1191182336 3 36038 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 72 4294967260 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21427', '2', '21427 1191182336 3 6887 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21428', '2', '21428 1191182336 3 6180 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21429', '2', '21429 1191182336 3 6311 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21430', '2', '21430 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21431', '2', '21431 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21432', '2', '21432 1191182336 3 21113 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21433', '2', '21433 1191182336 3 10329 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21434', '2', '21434 1191182336 3 5319 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21435', '2', '21435 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21436', '2', '21436 1191182336 3 36556 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 108 4294967256 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21437', '2', '21437 1191182336 3 35836 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21438', '2', '21438 1191182336 3 36037 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 97 4294967257 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21843', '2', '21843 1191182336 3 13422 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21842', '2', '21842 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21841', '2', '21841 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21840', '2', '21840 1191182336 3 2046 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21839', '2', '21839 1191182336 3 36263 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 97 4294967280 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21838', '2', '21838 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 19 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21837', '2', '21837 1191182336 3 24936 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 40 4294967284 115 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21836', '2', '21836 1191182336 3 7973 1065353216 0 2 0 2 0 0 0 0 0 17 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21835', '2', '21835 1191182336 3 865 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 76 0 0 73 0 0 0 0 0 0 590 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21834', '2', '21834 1191182336 3 6197 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21833', '2', '21833 1191182336 3 27511 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21832', '2', '21832 1191182336 3 6200 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21831', '2', '21831 1191182336 3 6333 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21830', '2', '21830 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21251', '2', '21251 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21250', '2', '21250 1191182336 3 14826 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21249', '2', '21249 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21248', '2', '21248 1191182336 3 18512 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21247', '2', '21247 1191182336 3 36286 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 81 4294967288 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21246', '2', '21246 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21245', '2', '21245 1191182336 3 2265 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21244', '2', '21244 1191182336 3 2620 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21243', '2', '21243 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21242', '2', '21242 1191182336 3 36596 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 101 4294967256 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21241', '2', '21241 1191182336 3 4359 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21240', '2', '21240 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21239', '2', '21239 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21238', '2', '21238 1191182336 3 1351 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21237', '2', '21237 1191182336 3 4387 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21236', '2', '21236 1191182336 3 36680 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 43 4294967252 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21235', '2', '21235 1191182336 3 5743 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21234', '2', '21234 1191182336 3 37145 1065353216 0 2 0 2 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21233', '2', '21233 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21232', '2', '21232 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21231', '2', '21231 1191182336 3 25089 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 23 4294967277 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21230', '2', '21230 1191182336 3 24773 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 39 4294967289 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21229', '2', '21229 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21228', '2', '21228 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21227', '2', '21227 1191182336 3 31256 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2825 0 0 2803 0 0 2802 0 0 0 0 0 0 0 0 5 4294967236 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21226', '2', '21226 1191182336 3 36383 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 101 4294967285 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21225', '2', '21225 1191182336 3 24710 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 4294967281 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21224', '2', '21224 1191182336 3 13757 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21223', '2', '21223 1191182336 3 14897 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 351 0 0 353 0 0 0 0 0 0 1030 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21222', '2', '21222 1191182336 3 37160 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21221', '2', '21221 1191182336 3 2632 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2194 0 0 0 0 0 0 0 0 0 1914 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21220', '2', '21220 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21219', '2', '21219 1191182336 3 8106 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21218', '2', '21218 1191182336 3 24824 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 40 4294967256 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21217', '2', '21217 1191182336 3 24716 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 22 4294967285 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21216', '2', '21216 1191182336 3 13757 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21215', '2', '21215 1191182336 3 20661 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 362 0 0 363 0 0 361 0 0 0 2150 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21214', '2', '21214 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21213', '2', '21213 1191182336 3 24476 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21212', '2', '21212 1191182336 3 27511 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21211', '2', '21211 1191182336 3 4465 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21210', '2', '21210 1191182336 3 24825 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 30 4294967256 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21209', '2', '21209 1191182336 3 5182 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21208', '2', '21208 1191182336 3 36044 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 75 4294967290 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21207', '2', '21207 1191182336 3 25047 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 23 4294967254 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21206', '2', '21206 1191182336 3 24826 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2818 0 0 0 0 0 0 0 0 0 0 0 40 4294967264 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21205', '2', '21205 1191182336 3 1679 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21204', '2', '21204 1191182336 3 1475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21203', '2', '21203 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21202', '2', '21202 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21201', '2', '21201 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21200', '2', '21200 1191182336 3 4290 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21199', '2', '21199 1191182336 3 12804 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21198', '2', '21198 1191182336 3 37145 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21197', '2', '21197 1191182336 3 10561 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21196', '2', '21196 1191182336 3 4436 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21195', '2', '21195 1191182336 3 36378 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 54 4294967285 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21194', '2', '21194 1191182336 3 24476 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21193', '2', '21193 1191182336 3 27511 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21192', '2', '21192 1191182336 3 24665 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 52 4294967287 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21191', '2', '21191 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21190', '2', '21190 1191182336 3 36387 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 78 4294967284 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21189', '2', '21189 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21188', '2', '21188 1191182336 3 865 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 76 0 0 73 0 0 0 0 0 0 590 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21187', '2', '21187 1191182336 3 36429 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2814 0 0 0 0 0 0 0 0 0 0 0 0 0 0 58 4294967268 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21186', '2', '21186 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21185', '2', '21185 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21184', '2', '21184 1191182336 3 24710 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 4294967281 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21183', '2', '21183 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21182', '2', '21182 1191182336 3 24939 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 40 4294967252 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21181', '2', '21181 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21180', '2', '21180 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 12 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21179', '2', '21179 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21178', '2', '21178 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21177', '2', '21177 1191182336 3 24780 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 29 4294967282 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21176', '2', '21176 1191182336 3 5635 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21175', '2', '21175 1191182336 3 24663 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 52 4294967257 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21174', '2', '21174 1191182336 3 24724 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 23 4294967255 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21173', '2', '21173 1191182336 3 24780 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 29 4294967277 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21172', '2', '21172 1191182336 3 5752 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21171', '2', '21171 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21170', '2', '21170 1191182336 3 2166 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21169', '2', '21169 1191182336 3 880 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21168', '2', '21168 1191182336 3 37160 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21167', '2', '21167 1191182336 3 36003 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 62 4294967281 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21166', '2', '21166 1191182336 3 3227 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21165', '2', '21165 1191182336 3 15687 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2132 0 0 0 0 0 0 0 0 0 1852 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21164', '2', '21164 1191182336 3 35971 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 53 4294967281 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21163', '2', '21163 1191182336 3 13422 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21162', '2', '21162 1191182336 3 36063 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 108 4294967260 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21161', '2', '21161 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21160', '2', '21160 1191182336 3 36639 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 33 4294967288 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21159', '2', '21159 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21158', '2', '21158 1191182336 3 7072 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21157', '2', '21157 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 17 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21156', '2', '21156 1191182336 3 3042 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21155', '2', '21155 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21154', '2', '21154 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 7 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21153', '2', '21153 1191182336 3 36383 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 0 0 0 0 0 0 0 0 0 0 0 0 101 4294967278 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21152', '2', '21152 1191182336 3 36043 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 75 4294967257 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21151', '2', '21151 1191182336 3 4767 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 18 18 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21150', '2', '21150 1191182336 3 36781 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21149', '2', '21149 1191182336 3 36708 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 101 4294967280 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21148', '2', '21148 1191182336 3 25306 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 22 4294967290 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21147', '2', '21147 1191182336 3 14901 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1948 0 0 0 0 0 0 0 0 0 1612 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21146', '2', '21146 1191182336 3 7973 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21145', '2', '21145 1191182336 3 4290 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21144', '2', '21144 1191182336 3 24712 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 30 4294967255 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21143', '2', '21143 1191182336 3 36540 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 101 4294967260 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21142', '2', '21142 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21141', '2', '21141 1191182336 3 8254 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21140', '2', '21140 1191182336 3 4359 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21139', '2', '21139 1191182336 3 35995 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 60 4294967257 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21138', '2', '21138 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21137', '2', '21137 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21136', '2', '21136 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21135', '2', '21135 1191182336 3 1936 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21134', '2', '21134 1191182336 3 8151 1065353216 0 2 0 2 0 0 0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21133', '2', '21133 1191182336 3 24835 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 41 4294967287 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21132', '2', '21132 1191182336 3 2620 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21131', '2', '21131 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21130', '2', '21130 1191182336 3 2077 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 101 0 0 105 0 0 0 0 0 0 1027 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21129', '2', '21129 1191182336 3 24887 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 39 4294967257 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21128', '2', '21128 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21127', '2', '21127 1191182336 3 10560 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21126', '2', '21126 1191182336 3 4589 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21125', '2', '21125 1191182336 3 3341 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21124', '2', '21124 1191182336 3 36781 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21123', '2', '21123 1191182336 3 36555 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 104 4294967251 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21122', '2', '21122 1191182336 3 1460 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21121', '2', '21121 1191182336 3 2623 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21120', '2', '21120 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21119', '2', '21119 1191182336 3 9327 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21118', '2', '21118 1191182336 3 24948 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 31 4294967252 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21117', '2', '21117 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21116', '2', '21116 1191182336 3 36511 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2823 0 0 0 0 0 0 0 0 97 4294967253 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21115', '2', '21115 1191182336 3 36281 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 78 4294967290 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21114', '2', '21114 1191182336 3 2168 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21113', '2', '21113 1191182336 3 8151 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21112', '2', '21112 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21111', '2', '21111 1191182336 3 24476 1065353216 0 2 0 2 0 0 0 0 0 11 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21110', '2', '21110 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21109', '2', '21109 1191182336 3 36402 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 60 4294967251 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21108', '2', '21108 1191182336 3 24834 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 41 4294967283 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21107', '2', '21107 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21106', '2', '21106 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21105', '2', '21105 1191182336 3 25208 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 22 4294967256 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21104', '2', '21104 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21103', '2', '21103 1191182336 3 31256 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 2803 0 0 2804 0 0 0 0 0 0 0 0 5 4294967238 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21102', '2', '21102 1191182336 3 24666 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 52 4294967260 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21101', '2', '21101 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21100', '2', '21100 1191182336 3 36666 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 32 4294967259 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21099', '2', '21099 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21098', '2', '21098 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21097', '2', '21097 1191182336 3 36287 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2817 0 0 0 0 0 0 0 0 0 0 0 108 4294967265 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21096', '2', '21096 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21095', '2', '21095 1191182336 3 36155 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 4294967279 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21094', '2', '21094 1191182336 3 20406 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21093', '2', '21093 1191182336 3 25033 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 23 4294967291 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21092', '2', '21092 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21091', '2', '21091 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21090', '2', '21090 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21089', '2', '21089 1191182336 3 1215 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21088', '2', '21088 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21087', '2', '21087 1191182336 3 35963 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 52 4294967274 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21086', '2', '21086 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 19 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21085', '2', '21085 1191182336 3 25152 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 22 4294967286 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21084', '2', '21084 1191182336 3 18512 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21083', '2', '21083 1191182336 3 18512 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21082', '2', '21082 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21081', '2', '21081 1191182336 3 36397 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 108 4294967286 115 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21080', '2', '21080 1191182336 3 1604 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21079', '2', '21079 1191182336 3 25172 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 40 4294967255 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21078', '2', '21078 1191182336 3 36264 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 97 4294967287 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21077', '2', '21077 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21076', '2', '21076 1191182336 3 32717 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21075', '2', '21075 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21074', '2', '21074 1191182336 3 25005 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 29 4294967290 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21073', '2', '21073 1191182336 3 24942 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 31 4294967287 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21072', '2', '21072 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21071', '2', '21071 1191182336 3 7517 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 406 0 0 407 0 0 0 0 0 0 791 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21070', '2', '21070 1191182336 3 17963 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21069', '2', '21069 1191182336 3 37160 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21068', '2', '21068 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21067', '2', '21067 1191182336 3 24711 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 40 4294967288 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21066', '2', '21066 1191182336 3 13422 1065353216 0 2 0 2 0 0 0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21065', '2', '21065 1191182336 3 5256 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20663', '2', '20663 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20664', '2', '20664 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20665', '2', '20665 1191182336 3 20678 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20666', '2', '20666 1191182336 3 16647 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20667', '2', '20667 1191182336 3 31157 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 60 4294967254 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20668', '2', '20668 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20669', '2', '20669 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20670', '2', '20670 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20671', '2', '20671 1191182336 3 18709 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20672', '2', '20672 1191182336 3 14157 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20673', '2', '20673 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20674', '2', '20674 1191182336 3 19441 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20675', '2', '20675 1191182336 3 1935 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20676', '2', '20676 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20677', '2', '20677 1191182336 3 4589 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20678', '2', '20678 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20679', '2', '20679 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20680', '2', '20680 1191182336 3 25327 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 41 4294967255 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20681', '2', '20681 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20682', '2', '20682 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20683', '2', '20683 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20684', '2', '20684 1191182336 3 37158 1065353216 0 2 0 2 0 0 0 0 0 19 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20685', '2', '20685 1191182336 3 37147 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20686', '2', '20686 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20687', '2', '20687 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20688', '2', '20688 1191182336 3 899 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20689', '2', '20689 1191182336 3 24999 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 39 4294967251 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20690', '2', '20690 1191182336 3 2057 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20691', '2', '20691 1191182336 3 6332 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20692', '2', '20692 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20693', '2', '20693 1191182336 3 18612 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20694', '2', '20694 1191182336 3 44722 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20695', '2', '20695 1191182336 3 36164 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 78 4294967270 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20696', '2', '20696 1191182336 3 35652 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20697', '2', '20697 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20698', '2', '20698 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20699', '2', '20699 1191182336 3 27513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20700', '2', '20700 1191182336 3 44683 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2824 0 0 2816 0 0 0 0 0 0 0 0 65 4294967203 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20701', '2', '20701 1191182336 3 36170 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 58 4294967254 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20702', '2', '20702 1191182336 3 25463 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20703', '2', '20703 1191182336 3 2227 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20704', '2', '20704 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20705', '2', '20705 1191182336 3 7754 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20706', '2', '20706 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 19 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20707', '2', '20707 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20708', '2', '20708 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20709', '2', '20709 1191182336 3 37157 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20710', '2', '20710 1191182336 3 11937 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20711', '2', '20711 1191182336 3 22641 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20712', '2', '20712 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20713', '2', '20713 1191182336 3 36150 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 72 4294967283 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20714', '2', '20714 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20715', '2', '20715 1191182336 3 5134 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20716', '2', '20716 1191182336 3 21595 1065353216 0 2 0 2 0 0 0 0 0 12 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20717', '2', '20717 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20718', '2', '20718 1191182336 3 31155 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 60 4294967291 135 135 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20719', '2', '20719 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20720', '2', '20720 1191182336 3 24832 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 41 4294967289 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20721', '2', '20721 1191182336 3 814 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20722', '2', '20722 1191182336 3 920 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20723', '2', '20723 1191182336 3 23909 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20724', '2', '20724 1191182336 3 10561 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20725', '2', '20725 1191182336 3 43622 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20726', '2', '20726 1191182336 3 13912 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20727', '2', '20727 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20728', '2', '20728 1191182336 3 6355 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20729', '2', '20729 1191182336 3 2971 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20730', '2', '20730 1191182336 3 36382 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 75 4294967284 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20731', '2', '20731 1191182336 3 2623 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20732', '2', '20732 1191182336 3 767 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20733', '2', '20733 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20734', '2', '20734 1191182336 3 18742 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20735', '2', '20735 1191182336 3 12549 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20736', '2', '20736 1191182336 3 36456 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 56 4294967257 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20737', '2', '20737 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20738', '2', '20738 1191182336 3 24938 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2817 0 0 0 0 0 0 0 0 0 0 0 40 4294967265 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20739', '2', '20739 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20740', '2', '20740 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20741', '2', '20741 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20742', '2', '20742 1191182336 3 7973 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20743', '2', '20743 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20744', '2', '20744 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20745', '2', '20745 1191182336 3 935 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20746', '2', '20746 1191182336 3 31554 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 63 4294967260 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20747', '2', '20747 1191182336 3 37822 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20748', '2', '20748 1191182336 3 36416 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 60 4294967255 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20749', '2', '20749 1191182336 3 1958 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20750', '2', '20750 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20751', '2', '20751 1191182336 3 31176 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 40 4294967255 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20752', '2', '20752 1191182336 3 3415 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20753', '2', '20753 1191182336 3 20674 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1068 0 0 2321 0 0 2377 0 0 0 2156 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20754', '2', '20754 1191182336 3 31198 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 44 4294967257 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20755', '2', '20755 1191182336 3 36154 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2818 0 0 0 0 0 0 0 0 0 0 0 54 4294967264 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20756', '2', '20756 1191182336 3 35593 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20757', '2', '20757 1191182336 3 5819 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20758', '2', '20758 1191182336 3 2277 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20759', '2', '20759 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20760', '2', '20760 1191182336 3 827 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20761', '2', '20761 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20762', '2', '20762 1191182336 3 9384 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20763', '2', '20763 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20764', '2', '20764 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20765', '2', '20765 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20766', '2', '20766 1191182336 3 36056 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 104 4294967280 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20767', '2', '20767 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20768', '2', '20768 1191182336 3 1475 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20769', '2', '20769 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20770', '2', '20770 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20771', '2', '20771 1191182336 3 2072 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 95 0 0 100 0 0 0 0 0 0 768 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20772', '2', '20772 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20773', '2', '20773 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20774', '2', '20774 1191182336 3 24709 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 30 4294967254 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20775', '2', '20775 1191182336 3 1679 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20776', '2', '20776 1191182336 3 4359 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20777', '2', '20777 1191182336 3 36046 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2817 0 0 0 0 0 0 0 0 0 0 0 75 4294967265 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20778', '2', '20778 1191182336 3 25268 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 12 4294967256 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20779', '2', '20779 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20780', '2', '20780 1191182336 3 19943 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20781', '2', '20781 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20782', '2', '20782 1191182336 3 13757 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20783', '2', '20783 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20784', '2', '20784 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20785', '2', '20785 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20786', '2', '20786 1191182336 3 5180 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20787', '2', '20787 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20788', '2', '20788 1191182336 3 36553 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 97 4294967283 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20789', '2', '20789 1191182336 3 31157 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 60 4294967255 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20790', '2', '20790 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 12 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20791', '2', '20791 1191182336 3 12804 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20792', '2', '20792 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20793', '2', '20793 1191182336 3 36272 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 101 4294967291 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20794', '2', '20794 1191182336 3 4388 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967291 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20795', '2', '20795 1191182336 3 1215 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20796', '2', '20796 1191182336 3 9480 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20797', '2', '20797 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20798', '2', '20798 1191182336 3 1384 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20799', '2', '20799 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20800', '2', '20800 1191182336 3 44687 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 65 4294967221 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20801', '2', '20801 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20802', '2', '20802 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20803', '2', '20803 1191182336 3 1713 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20804', '2', '20804 1191182336 3 13001 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20805', '2', '20805 1191182336 3 36528 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 46 4294967277 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20806', '2', '20806 1191182336 3 14900 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 366 0 0 367 0 0 0 0 0 0 1209 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20807', '2', '20807 1191182336 3 9486 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 95 95 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20808', '2', '20808 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20809', '2', '20809 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20810', '2', '20810 1191182336 3 4716 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20811', '2', '20811 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20812', '2', '20812 1191182336 3 1300 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20813', '2', '20813 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20814', '2', '20814 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20815', '2', '20815 1191182336 3 14832 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20816', '2', '20816 1191182336 3 10567 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20817', '2', '20817 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20818', '2', '20818 1191182336 3 11937 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20819', '2', '20819 1191182336 3 24603 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 30 4294967288 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20820', '2', '20820 1191182336 3 13757 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20821', '2', '20821 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20822', '2', '20822 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20823', '2', '20823 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 19 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20824', '2', '20824 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20825', '2', '20825 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20826', '2', '20826 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20827', '2', '20827 1191182336 3 10561 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20828', '2', '20828 1191182336 3 4656 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20829', '2', '20829 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20830', '2', '20830 1191182336 3 1189 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20831', '2', '20831 1191182336 3 754 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20832', '2', '20832 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20833', '2', '20833 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20834', '2', '20834 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20835', '2', '20835 1191182336 3 5758 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20836', '2', '20836 1191182336 3 29426 1065353216 0 2 0 2 0 0 0 0 0 72 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20837', '2', '20837 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20838', '2', '20838 1191182336 3 5750 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20839', '2', '20839 1191182336 3 1455 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20840', '2', '20840 1191182336 3 4589 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20841', '2', '20841 1191182336 3 16654 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20842', '2', '20842 1191182336 3 31181 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2820 0 0 0 0 0 0 0 0 0 0 0 40 4294967262 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20843', '2', '20843 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20844', '2', '20844 1191182336 3 24607 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 41 4294967260 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20845', '2', '20845 1191182336 3 9396 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20846', '2', '20846 1191182336 3 36056 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 104 4294967260 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20847', '2', '20847 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 19 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20848', '2', '20848 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20849', '2', '20849 1191182336 3 13916 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20850', '2', '20850 1191182336 3 36286 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 81 4294967256 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20851', '2', '20851 1191182336 3 2911 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20852', '2', '20852 1191182336 3 2227 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20853', '2', '20853 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20854', '2', '20854 1191182336 3 31125 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20855', '2', '20855 1191182336 3 1351 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20856', '2', '20856 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20857', '2', '20857 1191182336 3 3321 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20858', '2', '20858 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20859', '2', '20859 1191182336 3 24476 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20860', '2', '20860 1191182336 3 21595 1065353216 0 2 0 2 0 0 0 0 0 17 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20861', '2', '20861 1191182336 3 13422 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20862', '2', '20862 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20863', '2', '20863 1191182336 3 25201 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 17 4294967252 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20864', '2', '20864 1191182336 3 4434 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20865', '2', '20865 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20866', '2', '20866 1191182336 3 6309 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20867', '2', '20867 1191182336 3 25271 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 13 4294967286 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20868', '2', '20868 1191182336 3 2620 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20869', '2', '20869 1191182336 3 3058 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20870', '2', '20870 1191182336 3 12607 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20871', '2', '20871 1191182336 3 28533 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 12 4294967286 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20872', '2', '20872 1191182336 3 24476 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20873', '2', '20873 1191182336 3 3336 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20874', '2', '20874 1191182336 3 7072 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20875', '2', '20875 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20876', '2', '20876 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20877', '2', '20877 1191182336 3 36039 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 97 4294967287 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20878', '2', '20878 1191182336 3 35666 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20879', '2', '20879 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20880', '2', '20880 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20881', '2', '20881 1191182336 3 3312 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20882', '2', '20882 1191182336 3 6660 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20883', '2', '20883 1191182336 3 13757 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20884', '2', '20884 1191182336 3 31231 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2819 0 0 0 0 0 0 0 0 0 0 0 40 4294967263 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20885', '2', '20885 1191182336 3 6292 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20886', '2', '20886 1191182336 3 3000 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20887', '2', '20887 1191182336 3 35654 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20888', '2', '20888 1191182336 3 4698 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20889', '2', '20889 1191182336 3 21595 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20890', '2', '20890 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20891', '2', '20891 1191182336 3 13024 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20892', '2', '20892 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20893', '2', '20893 1191182336 3 27515 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20894', '2', '20894 1191182336 3 38303 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20895', '2', '20895 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20896', '2', '20896 1191182336 3 28452 1065353216 0 2 0 2 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20897', '2', '20897 1191182336 3 3415 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20898', '2', '20898 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20899', '2', '20899 1191182336 3 27513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20900', '2', '20900 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20901', '2', '20901 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20902', '2', '20902 1191182336 3 13877 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20903', '2', '20903 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20904', '2', '20904 1191182336 3 23329 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20905', '2', '20905 1191182336 3 2265 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20906', '2', '20906 1191182336 3 24823 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 30 4294967257 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20907', '2', '20907 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20908', '2', '20908 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20909', '2', '20909 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20910', '2', '20910 1191182336 3 17969 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20911', '2', '20911 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20912', '2', '20912 1191182336 3 6357 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20913', '2', '20913 1191182336 3 18600 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20914', '2', '20914 1191182336 3 12549 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20915', '2', '20915 1191182336 3 10574 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20916', '2', '20916 1191182336 3 2807 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20917', '2', '20917 1191182336 3 36038 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 72 4294967280 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20918', '2', '20918 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20919', '2', '20919 1191182336 3 5751 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20920', '2', '20920 1191182336 3 756 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20921', '2', '20921 1191182336 3 36164 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 0 0 0 0 0 0 0 0 0 0 0 0 78 4294967278 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20922', '2', '20922 1191182336 3 37158 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20923', '2', '20923 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20924', '2', '20924 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20925', '2', '20925 1191182336 3 20552 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20926', '2', '20926 1191182336 3 10560 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20927', '2', '20927 1191182336 3 31212 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 60 4294967287 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20928', '2', '20928 1191182336 3 10623 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20929', '2', '20929 1191182336 3 6555 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20930', '2', '20930 1191182336 3 753 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20931', '2', '20931 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20932', '2', '20932 1191182336 3 19441 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20933', '2', '20933 1191182336 3 10560 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20934', '2', '20934 1191182336 3 766 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20935', '2', '20935 1191182336 3 6364 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20936', '2', '20936 1191182336 3 44156 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20937', '2', '20937 1191182336 3 36471 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 58 4294967257 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20938', '2', '20938 1191182336 3 21562 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20939', '2', '20939 1191182336 3 17963 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20940', '2', '20940 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20941', '2', '20941 1191182336 3 37771 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20942', '2', '20942 1191182336 3 31268 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2825 0 0 2803 0 0 2802 0 0 0 0 0 0 0 0 2 4294967236 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20943', '2', '20943 1191182336 3 27513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20944', '2', '20944 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20945', '2', '20945 1191182336 3 2822 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20946', '2', '20946 1191182336 3 5117 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20947', '2', '20947 1191182336 3 6579 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20948', '2', '20948 1191182336 3 1218 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20949', '2', '20949 1191182336 3 18744 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20950', '2', '20950 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20951', '2', '20951 1191182336 3 3280 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20952', '2', '20952 1191182336 3 16646 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20953', '2', '20953 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20954', '2', '20954 1191182336 3 15313 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20955', '2', '20955 1191182336 3 10571 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20956', '2', '20956 1191182336 3 24665 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 52 4294967258 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20957', '2', '20957 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20958', '2', '20958 1191182336 3 9397 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20959', '2', '20959 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20960', '2', '20960 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20961', '2', '20961 1191182336 3 14982 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 358 0 0 362 0 0 0 0 0 0 696 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20962', '2', '20962 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 7 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20963', '2', '20963 1191182336 3 5425 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20964', '2', '20964 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20965', '2', '20965 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20966', '2', '20966 1191182336 3 25214 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 40 4294967256 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20967', '2', '20967 1191182336 3 41119 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20968', '2', '20968 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20969', '2', '20969 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20970', '2', '20970 1191182336 3 3327 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20971', '2', '20971 1191182336 3 2735 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20972', '2', '20972 1191182336 3 3335 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20973', '2', '20973 1191182336 3 31238 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 30 4294967287 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20974', '2', '20974 1191182336 3 44732 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 126 4294967260 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20975', '2', '20975 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20976', '2', '20976 1191182336 3 36175 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 108 4294967287 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20977', '2', '20977 1191182336 3 2274 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20978', '2', '20978 1191182336 3 1475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20979', '2', '20979 1191182336 3 27513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20980', '2', '20980 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20981', '2', '20981 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20982', '2', '20982 1191182336 3 37160 1065353216 0 2 0 2 0 0 0 0 0 15 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20983', '2', '20983 1191182336 3 20692 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1298 0 0 0 0 0 0 0 0 0 1362 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20984', '2', '20984 1191182336 3 6309 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20985', '2', '20985 1191182336 3 10460 1065353216 0 2 0 2 0 0 0 0 0 1 600 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20986', '2', '20986 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20987', '2', '20987 1191182336 3 19441 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20988', '2', '20988 1191182336 3 3186 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 103 0 0 0 0 0 0 0 0 0 114 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20989', '2', '20989 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20990', '2', '20990 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20991', '2', '20991 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20992', '2', '20992 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20993', '2', '20993 1191182336 3 22277 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20994', '2', '20994 1191182336 3 6555 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20995', '2', '20995 1191182336 3 2108 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20996', '2', '20996 1191182336 3 24603 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 30 4294967287 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20997', '2', '20997 1191182336 3 10407 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20998', '2', '20998 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20999', '2', '20999 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21000', '2', '21000 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21001', '2', '21001 1191182336 3 19441 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21002', '2', '21002 1191182336 3 35963 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 52 4294967270 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21003', '2', '21003 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21004', '2', '21004 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21005', '2', '21005 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21006', '2', '21006 1191182336 3 2740 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21007', '2', '21007 1191182336 3 24826 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 4294967281 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21008', '2', '21008 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21009', '2', '21009 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21010', '2', '21010 1191182336 3 9444 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21011', '2', '21011 1191182336 3 12804 1065353216 0 2 0 2 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21012', '2', '21012 1191182336 3 2204 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21013', '2', '21013 1191182336 3 2021 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21014', '2', '21014 1191182336 3 36541 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 104 4294967255 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21015', '2', '21015 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21016', '2', '21016 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21017', '2', '21017 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21018', '2', '21018 1191182336 3 36036 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 72 4294967287 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21019', '2', '21019 1191182336 3 36267 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 4294967279 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21020', '2', '21020 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21021', '2', '21021 1191182336 3 37145 1065353216 0 2 0 2 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21022', '2', '21022 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21023', '2', '21023 1191182336 3 1659 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21024', '2', '21024 1191182336 3 20693 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21025', '2', '21025 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21026', '2', '21026 1191182336 3 25001 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2818 0 0 0 0 0 0 0 0 0 0 0 39 4294967264 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21027', '2', '21027 1191182336 3 19441 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21028', '2', '21028 1191182336 3 13422 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21029', '2', '21029 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21030', '2', '21030 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21031', '2', '21031 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21032', '2', '21032 1191182336 3 814 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21033', '2', '21033 1191182336 3 36597 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 104 4294967256 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21034', '2', '21034 1191182336 3 885 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21035', '2', '21035 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21036', '2', '21036 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21037', '2', '21037 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21038', '2', '21038 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21039', '2', '21039 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21040', '2', '21040 1191182336 3 7072 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21041', '2', '21041 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21042', '2', '21042 1191182336 3 36584 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2823 0 0 0 0 0 0 0 0 46 4294967253 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21043', '2', '21043 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21044', '2', '21044 1191182336 3 24608 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 31 4294967288 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21045', '2', '21045 1191182336 3 24936 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 40 4294967283 115 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21046', '2', '21046 1191182336 3 12804 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21047', '2', '21047 1191182336 3 28495 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2811 0 0 2803 0 0 2804 0 0 0 0 0 0 0 0 34 4294967241 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21048', '2', '21048 1191182336 3 25264 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 16 4294967291 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21049', '2', '21049 1191182336 3 24599 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 40 4294967257 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21050', '2', '21050 1191182336 3 5635 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21051', '2', '21051 1191182336 3 24608 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 31 4294967259 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21052', '2', '21052 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21053', '2', '21053 1191182336 3 9262 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21054', '2', '21054 1191182336 3 25326 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 4294967279 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21055', '2', '21055 1191182336 3 36570 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 46 4294967256 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21056', '2', '21056 1191182336 3 8151 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21057', '2', '21057 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21058', '2', '21058 1191182336 3 36428 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2817 0 0 0 0 0 0 0 0 0 0 0 56 4294967265 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21059', '2', '21059 1191182336 3 10560 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21060', '2', '21060 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21061', '2', '21061 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21062', '2', '21062 1191182336 3 8152 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21063', '2', '21063 1191182336 3 36399 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 108 4294967287 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('21064', '2', '21064 1191182336 3 6204 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20662', '2', '20662 1191182336 3 36668 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 34 4294967258 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20661', '2', '20661 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20660', '2', '20660 1191182336 3 44682 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 70 4294967257 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20659', '2', '20659 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20658', '2', '20658 1191182336 3 20527 1065353216 0 2 0 2 0 0 0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20657', '2', '20657 1191182336 3 8303 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20656', '2', '20656 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20655', '2', '20655 1191182336 3 10559 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20654', '2', '20654 1191182336 3 45986 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20653', '2', '20653 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20652', '2', '20652 1191182336 3 3018 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20651', '2', '20651 1191182336 3 36624 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 32 4294967288 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20650', '2', '20650 1191182336 3 7734 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20649', '2', '20649 1191182336 3 36978 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20648', '2', '20648 1191182336 3 6333 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20647', '2', '20647 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20646', '2', '20646 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20645', '2', '20645 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20644', '2', '20644 1191182336 3 36161 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 4294967281 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20643', '2', '20643 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20642', '2', '20642 1191182336 3 20662 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 362 0 0 358 0 0 366 0 0 0 2151 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20641', '2', '20641 1191182336 3 32715 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20640', '2', '20640 1191182336 3 31246 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2819 0 0 0 0 0 0 0 0 0 0 0 51 4294967263 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20639', '2', '20639 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20638', '2', '20638 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20637', '2', '20637 1191182336 3 36038 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 72 4294967260 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20636', '2', '20636 1191182336 3 13901 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20635', '2', '20635 1191182336 3 9378 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20634', '2', '20634 1191182336 3 7729 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20633', '2', '20633 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20632', '2', '20632 1191182336 3 8223 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20631', '2', '20631 1191182336 3 9308 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20630', '2', '20630 1191182336 3 1384 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20629', '2', '20629 1191182336 3 5423 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20628', '2', '20628 1191182336 3 814 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20627', '2', '20627 1191182336 3 3429 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20626', '2', '20626 1191182336 3 35653 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20625', '2', '20625 1191182336 3 36048 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 101 4294967277 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20624', '2', '20624 1191182336 3 3263 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20623', '2', '20623 1191182336 3 11040 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20622', '2', '20622 1191182336 3 13000 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20621', '2', '20621 1191182336 3 4700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20620', '2', '20620 1191182336 3 36443 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2816 0 0 0 0 0 0 0 0 58 4294967252 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20619', '2', '20619 1191182336 3 1203 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20618', '2', '20618 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20617', '2', '20617 1191182336 3 16692 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20616', '2', '20616 1191182336 3 13915 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20615', '2', '20615 1191182336 3 1459 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20614', '2', '20614 1191182336 3 2738 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20613', '2', '20613 1191182336 3 13904 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20612', '2', '20612 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20611', '2', '20611 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20610', '2', '20610 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20609', '2', '20609 1191182336 3 8246 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20608', '2', '20608 1191182336 3 24401 1065353216 0 2 0 2 0 0 0 0 0 148 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20607', '2', '20607 1191182336 3 39970 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20606', '2', '20606 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20605', '2', '20605 1191182336 3 6360 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20604', '2', '20604 1191182336 3 7973 1065353216 0 2 0 2 0 0 0 0 0 19 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20603', '2', '20603 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20602', '2', '20602 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20601', '2', '20601 1191182336 3 20545 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20600', '2', '20600 1191182336 3 6355 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20599', '2', '20599 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20598', '2', '20598 1191182336 3 10403 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20597', '2', '20597 1191182336 3 7734 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20596', '2', '20596 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20595', '2', '20595 1191182336 3 16656 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20594', '2', '20594 1191182336 3 8179 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20593', '2', '20593 1191182336 3 9746 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 18 18 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20592', '2', '20592 1191182336 3 1604 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20591', '2', '20591 1191182336 3 20708 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20590', '2', '20590 1191182336 3 31155 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 60 4294967260 135 135 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20589', '2', '20589 1191182336 3 6307 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20588', '2', '20588 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20587', '2', '20587 1191182336 3 27511 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20586', '2', '20586 1191182336 3 5523 1065353216 0 2 0 2 0 0 0 0 0 11 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20585', '2', '20585 1191182336 3 4394 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20584', '2', '20584 1191182336 3 25144 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 17 4294967290 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20583', '2', '20583 1191182336 3 34859 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20582', '2', '20582 1191182336 3 9249 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20581', '2', '20581 1191182336 3 18679 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20580', '2', '20580 1191182336 3 19943 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20579', '2', '20579 1191182336 3 4785 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20578', '2', '20578 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 11 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20577', '2', '20577 1191182336 3 36043 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 4294967275 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20576', '2', '20576 1191182336 3 13884 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20575', '2', '20575 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20574', '2', '20574 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20573', '2', '20573 1191182336 3 19441 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20572', '2', '20572 1191182336 3 18512 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20571', '2', '20571 1191182336 3 13884 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20570', '2', '20570 1191182336 3 16654 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20569', '2', '20569 1191182336 3 6299 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20568', '2', '20568 1191182336 3 36062 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 81 4294967271 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20567', '2', '20567 1191182336 3 36414 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 56 4294967251 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20566', '2', '20566 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20565', '2', '20565 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20564', '2', '20564 1191182336 3 24942 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 31 4294967255 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20563', '2', '20563 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20562', '2', '20562 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20561', '2', '20561 1191182336 3 897 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20560', '2', '20560 1191182336 3 22642 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20559', '2', '20559 1191182336 3 25158 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 40 4294967282 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20558', '2', '20558 1191182336 3 23354 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20557', '2', '20557 1191182336 3 22281 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20556', '2', '20556 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20555', '2', '20555 1191182336 3 13757 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20554', '2', '20554 1191182336 3 4951 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 18 18 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20553', '2', '20553 1191182336 3 30809 1065353216 0 2 0 2 0 0 0 0 0 61 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20552', '2', '20552 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20551', '2', '20551 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20550', '2', '20550 1191182336 3 6458 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20549', '2', '20549 1191182336 3 814 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20548', '2', '20548 1191182336 3 25144 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 17 4294967283 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20547', '2', '20547 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20546', '2', '20546 1191182336 3 10402 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20545', '2', '20545 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20544', '2', '20544 1191182336 3 1077 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20543', '2', '20543 1191182336 3 10560 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20542', '2', '20542 1191182336 3 10407 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20541', '2', '20541 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20540', '2', '20540 1191182336 3 36383 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 101 4294967280 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20539', '2', '20539 1191182336 3 13883 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20538', '2', '20538 1191182336 3 13755 1065353216 0 2 0 2 0 0 0 0 0 12 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20537', '2', '20537 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20536', '2', '20536 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20535', '2', '20535 1191182336 3 24606 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 31 4294967290 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20534', '2', '20534 1191182336 3 36584 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 46 4294967256 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20533', '2', '20533 1191182336 3 2066 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20532', '2', '20532 1191182336 3 27513 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20531', '2', '20531 1191182336 3 1928 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20530', '2', '20530 1191182336 3 34826 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20529', '2', '20529 1191182336 3 37159 1065353216 0 2 0 2 0 0 0 0 0 18 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20528', '2', '20528 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20527', '2', '20527 1191182336 3 37145 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20526', '2', '20526 1191182336 3 4444 1065353216 0 2 0 2 0 0 0 0 0 1 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20525', '2', '20525 1191182336 3 34828 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20524', '2', '20524 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20523', '2', '20523 1191182336 3 41119 1065353216 0 2 0 2 0 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20522', '2', '20522 1191182336 3 3072 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20521', '2', '20521 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20520', '2', '20520 1191182336 3 24664 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 39 4294967260 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20519', '2', '20519 1191182336 3 36175 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 108 4294967290 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20518', '2', '20518 1191182336 3 1475 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20517', '2', '20517 1191182336 3 36289 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2822 0 0 2824 0 0 0 0 0 0 0 0 81 4294967229 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20516', '2', '20516 1191182336 3 36528 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 46 4294967255 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20515', '2', '20515 1191182336 3 2013 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20514', '2', '20514 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20513', '2', '20513 1191182336 3 16649 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20512', '2', '20512 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20511', '2', '20511 1191182336 3 3053 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20510', '2', '20510 1191182336 3 13422 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20509', '2', '20509 1191182336 3 5109 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20508', '2', '20508 1191182336 3 23329 1065353216 0 2 0 2 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20507', '2', '20507 1191182336 3 36430 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2815 0 0 2802 0 0 0 0 0 0 0 0 0 0 0 60 4294967267 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20506', '2', '20506 1191182336 3 6359 1065353216 0 2 0 2 0 0 0 0 0 13 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20505', '2', '20505 1191182336 3 36045 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 101 4294967288 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20504', '2', '20504 1191182336 3 9406 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20503', '2', '20503 1191182336 3 10628 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20502', '2', '20502 1191182336 3 2546 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20501', '2', '20501 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20500', '2', '20500 1191182336 3 6355 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20499', '2', '20499 1191182336 3 36570 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 46 4294967256 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20498', '2', '20498 1191182336 3 4096 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20497', '2', '20497 1191182336 3 2300 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20496', '2', '20496 1191182336 3 1639 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1098 0 0 0 0 0 0 0 0 0 363 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20495', '2', '20495 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20494', '2', '20494 1191182336 3 23329 1065353216 0 2 0 2 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20493', '2', '20493 1191182336 3 6358 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20492', '2', '20492 1191182336 3 44695 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 3727 0 0 2805 0 0 0 0 0 0 0 0 126 4294967204 80 80 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20491', '2', '20491 1191182336 3 2108 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20490', '2', '20490 1191182336 3 6205 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20489', '2', '20489 1191182336 3 814 1065353216 0 2 0 2 0 0 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20488', '2', '20488 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20487', '2', '20487 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20486', '2', '20486 1191182336 3 2065 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20485', '2', '20485 1191182336 3 2745 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20484', '2', '20484 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20483', '2', '20483 1191182336 3 36276 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 78 4294967283 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20482', '2', '20482 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20481', '2', '20481 1191182336 3 18676 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20480', '2', '20480 1191182336 3 20655 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 366 0 0 359 0 0 2607 0 0 0 2143 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20479', '2', '20479 1191182336 3 20541 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20478', '2', '20478 1191182336 3 814 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20477', '2', '20477 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20476', '2', '20476 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20475', '2', '20475 1191182336 3 8289 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20474', '2', '20474 1191182336 3 12804 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20473', '2', '20473 1191182336 3 5635 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20472', '2', '20472 1191182336 3 4359 1065353216 0 2 0 2 0 0 0 0 0 9 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20272', '2', '20272 1191182336 3 37145 1065353216 0 2 0 2 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20273', '2', '20273 1191182336 3 36042 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 54 4294967277 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20274', '2', '20274 1191182336 3 5183 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20275', '2', '20275 1191182336 3 14549 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20276', '2', '20276 1191182336 3 14555 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20277', '2', '20277 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20278', '2', '20278 1191182336 3 13887 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20279', '2', '20279 1191182336 3 24637 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 4294967271 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20280', '2', '20280 1191182336 3 1935 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20281', '2', '20281 1191182336 3 10367 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 358 0 0 362 0 0 0 0 0 0 696 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20282', '2', '20282 1191182336 3 6332 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20283', '2', '20283 1191182336 3 31192 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 30 4294967260 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20284', '2', '20284 1191182336 3 13422 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20285', '2', '20285 1191182336 3 2291 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20286', '2', '20286 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 9 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20287', '2', '20287 1191182336 3 868 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 105 105 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20288', '2', '20288 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20289', '2', '20289 1191182336 3 2057 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20290', '2', '20290 1191182336 3 36161 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 4294967270 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20291', '2', '20291 1191182336 3 5637 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20292', '2', '20292 1191182336 3 10402 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20293', '2', '20293 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 11 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20294', '2', '20294 1191182336 3 31234 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20295', '2', '20295 1191182336 3 16671 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20296', '2', '20296 1191182336 3 37761 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20297', '2', '20297 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20298', '2', '20298 1191182336 3 12531 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20299', '2', '20299 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20300', '2', '20300 1191182336 3 28494 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2823 0 0 0 0 0 0 0 0 41 4294967240 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20301', '2', '20301 1191182336 3 22897 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20302', '2', '20302 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20303', '2', '20303 1191182336 3 37756 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20304', '2', '20304 1191182336 3 36168 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 104 4294967283 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20305', '2', '20305 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20306', '2', '20306 1191182336 3 25068 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2816 0 0 0 0 0 0 0 0 0 0 0 0 0 0 29 4294967266 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20307', '2', '20307 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20308', '2', '20308 1191182336 3 20677 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20309', '2', '20309 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20310', '2', '20310 1191182336 3 31284 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20311', '2', '20311 1191182336 3 16713 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20312', '2', '20312 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20313', '2', '20313 1191182336 3 24773 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 39 4294967286 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20314', '2', '20314 1191182336 3 19441 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20315', '2', '20315 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20316', '2', '20316 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20317', '2', '20317 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20318', '2', '20318 1191182336 3 31234 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20319', '2', '20319 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20320', '2', '20320 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20321', '2', '20321 1191182336 3 31125 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20322', '2', '20322 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20323', '2', '20323 1191182336 3 40195 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20324', '2', '20324 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20325', '2', '20325 1191182336 3 13422 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20326', '2', '20326 1191182336 3 27516 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20327', '2', '20327 1191182336 3 21882 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20328', '2', '20328 1191182336 3 41119 1065353216 0 2 0 2 0 0 0 0 0 15 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20329', '2', '20329 1191182336 3 44475 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20330', '2', '20330 1191182336 3 2039 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20331', '2', '20331 1191182336 3 34828 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20332', '2', '20332 1191182336 3 6356 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20333', '2', '20333 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20334', '2', '20334 1191182336 3 7973 1065353216 0 2 0 2 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20335', '2', '20335 1191182336 3 5524 1065353216 0 2 0 2 0 0 0 0 0 15 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20336', '2', '20336 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20337', '2', '20337 1191182336 3 13422 1065353216 0 2 0 2 0 0 0 0 0 12 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20338', '2', '20338 1191182336 3 44156 1065353216 0 2 0 2 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20339', '2', '20339 1191182336 3 24101 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20340', '2', '20340 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20341', '2', '20341 1191182336 3 25229 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 41 4294967287 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20342', '2', '20342 1191182336 3 2623 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20343', '2', '20343 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20344', '2', '20344 1191182336 3 9420 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20345', '2', '20345 1191182336 3 5110 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20346', '2', '20346 1191182336 3 3319 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20347', '2', '20347 1191182336 3 13422 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20348', '2', '20348 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20349', '2', '20349 1191182336 3 24888 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 52 4294967289 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20350', '2', '20350 1191182336 3 37749 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20351', '2', '20351 1191182336 3 1945 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20352', '2', '20352 1191182336 3 39682 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20353', '2', '20353 1191182336 3 25110 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 22 4294967286 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20354', '2', '20354 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 14 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20355', '2', '20355 1191182336 3 24658 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 50 4294967260 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20356', '2', '20356 1191182336 3 37145 1065353216 0 2 0 2 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20357', '2', '20357 1191182336 3 12535 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20358', '2', '20358 1191182336 3 5066 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20359', '2', '20359 1191182336 3 36036 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 72 4294967258 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20360', '2', '20360 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20361', '2', '20361 1191182336 3 36384 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2825 0 0 0 0 0 0 0 0 0 0 0 0 0 0 101 4294967276 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20362', '2', '20362 1191182336 3 29426 1065353216 0 2 0 2 0 0 0 0 0 71 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20363', '2', '20363 1191182336 3 24604 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 22 4294967259 25 25 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20364', '2', '20364 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20365', '2', '20365 1191182336 3 40199 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20366', '2', '20366 1191182336 3 7072 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20367', '2', '20367 1191182336 3 18588 1065353216 0 2 0 2 0 0 0 0 0 11 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20368', '2', '20368 1191182336 3 1944 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20369', '2', '20369 1191182336 3 814 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20370', '2', '20370 1191182336 3 44156 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20371', '2', '20371 1191182336 3 31183 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 0 0 0 49 4294967279 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20372', '2', '20372 1191182336 3 4611 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20373', '2', '20373 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20374', '2', '20374 1191182336 3 10514 1065353216 0 2 0 2 0 0 0 0 0 11 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20375', '2', '20375 1191182336 3 25000 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2819 0 0 0 0 0 0 0 0 0 0 0 52 4294967263 115 115 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20376', '2', '20376 1191182336 3 3164 1065353216 0 2 0 2 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20377', '2', '20377 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20378', '2', '20378 1191182336 3 4377 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20379', '2', '20379 1191182336 3 36158 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 75 4294967282 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20380', '2', '20380 1191182336 3 18612 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20381', '2', '20381 1191182336 3 23334 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20382', '2', '20382 1191182336 3 8364 1065353216 0 2 0 2 0 0 0 0 0 19 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20383', '2', '20383 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20384', '2', '20384 1191182336 3 25201 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 17 4294967291 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20385', '2', '20385 1191182336 3 3295 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20386', '2', '20386 1191182336 3 767 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20387', '2', '20387 1191182336 3 5267 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20388', '2', '20388 1191182336 3 24711 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 40 4294967257 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20389', '2', '20389 1191182336 3 5066 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20390', '2', '20390 1191182336 3 31195 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 44 4294967260 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20391', '2', '20391 1191182336 3 24368 1065353216 0 2 0 2 0 0 0 0 0 165 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20392', '2', '20392 1191182336 3 36395 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2820 0 0 0 0 0 0 0 0 0 0 0 81 4294967262 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20393', '2', '20393 1191182336 3 2277 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20394', '2', '20394 1191182336 3 31185 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 49 4294967280 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20395', '2', '20395 1191182336 3 24778 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 52 4294967256 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20396', '2', '20396 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20397', '2', '20397 1191182336 3 8224 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20398', '2', '20398 1191182336 3 20541 1065353216 0 2 0 2 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20399', '2', '20399 1191182336 3 4402 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20400', '2', '20400 1191182336 3 18712 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20401', '2', '20401 1191182336 3 31940 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2813 0 0 2824 0 0 0 0 0 0 0 0 35 4294967230 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20402', '2', '20402 1191182336 3 31183 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 49 4294967291 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20403', '2', '20403 1191182336 3 39681 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20404', '2', '20404 1191182336 3 1486 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20405', '2', '20405 1191182336 3 9061 1065353216 0 2 0 2 0 0 0 0 0 7 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20406', '2', '20406 1191182336 3 6299 1065353216 0 2 0 2 0 0 0 0 0 19 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20407', '2', '20407 1191182336 3 31219 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 60 4294967285 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20408', '2', '20408 1191182336 3 44700 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20409', '2', '20409 1191182336 3 10574 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20410', '2', '20410 1191182336 3 37755 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20411', '2', '20411 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20412', '2', '20412 1191182336 3 25152 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 22 4294967290 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20413', '2', '20413 1191182336 3 2327 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20414', '2', '20414 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20415', '2', '20415 1191182336 3 18512 1065353216 0 2 0 2 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20416', '2', '20416 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20417', '2', '20417 1191182336 3 18612 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20418', '2', '20418 1191182336 3 24611 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 31 4294967290 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20419', '2', '20419 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20420', '2', '20420 1191182336 3 23386 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20421', '2', '20421 1191182336 3 31164 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2823 0 0 0 0 0 0 0 0 44 4294967253 40 40 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20422', '2', '20422 1191182336 3 1401 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20423', '2', '20423 1191182336 3 16714 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20424', '2', '20424 1191182336 3 4481 1065353216 0 2 0 2 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20425', '2', '20425 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20426', '2', '20426 1191182336 3 36458 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 2813 0 0 0 0 0 0 0 0 60 4294967251 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20427', '2', '20427 1191182336 3 6292 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20428', '2', '20428 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20429', '2', '20429 1191182336 3 1355 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20430', '2', '20430 1191182336 3 36166 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 78 4294967256 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20431', '2', '20431 1191182336 3 30809 1065353216 0 2 0 2 0 0 0 0 0 80 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20432', '2', '20432 1191182336 3 9755 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20433', '2', '20433 1191182336 3 36486 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 46 4294967256 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20434', '2', '20434 1191182336 3 814 1065353216 0 2 0 2 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20435', '2', '20435 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20436', '2', '20436 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20437', '2', '20437 1191182336 3 31200 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20438', '2', '20438 1191182336 3 22279 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20439', '2', '20439 1191182336 3 10562 1065353216 0 2 0 2 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20440', '2', '20440 1191182336 3 36155 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2819 0 0 0 0 0 0 0 0 0 0 0 75 4294967263 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20441', '2', '20441 1191182336 3 22527 1065353216 0 2 0 2 0 0 0 0 0 209 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20442', '2', '20442 1191182336 3 36168 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 104 4294967280 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20443', '2', '20443 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20444', '2', '20444 1191182336 3 10328 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20445', '2', '20445 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20446', '2', '20446 1191182336 3 25194 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 22 4294967280 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20447', '2', '20447 1191182336 3 25215 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 41 4294967257 85 85 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20448', '2', '20448 1191182336 3 865 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 0 0 73 0 0 0 0 0 0 591 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20449', '2', '20449 1191182336 3 45909 1065353216 0 2 0 2 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20450', '2', '20450 1191182336 3 1288 1065353216 0 2 0 2 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20451', '2', '20451 1191182336 3 31892 1065353216 0 2 0 2 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20452', '2', '20452 1191182336 3 6195 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20453', '2', '20453 1191182336 3 10505 1065353216 0 2 0 2 0 0 0 0 0 11 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20454', '2', '20454 1191182336 3 2258 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20455', '2', '20455 1191182336 3 19943 1065353216 0 2 0 2 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20456', '2', '20456 1191182336 3 31181 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 40 4294967258 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20457', '2', '20457 1191182336 3 36172 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 81 4294967277 45 45 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20458', '2', '20458 1191182336 3 2898 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20459', '2', '20459 1191182336 3 36168 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 104 4294967256 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20460', '2', '20460 1191182336 3 24948 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 31 4294967270 70 70 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20461', '2', '20461 1191182336 3 44505 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20462', '2', '20462 1191182336 3 24890 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 52 4294967282 60 60 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20463', '2', '20463 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20464', '2', '20464 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20465', '2', '20465 1191182336 3 31234 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 90 90 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20466', '2', '20466 1191182336 3 9060 1065353216 0 2 0 2 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20467', '2', '20467 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20468', '2', '20468 1191182336 3 9719 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20469', '2', '20469 1191182336 3 31298 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20470', '2', '20470 1191182336 3 28541 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 16 4294967289 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('20471', '2', '20471 1191182336 3 1489 1065353216 0 2 0 2 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 95 95 0 0 ', '');
INSERT INTO `item_instance` VALUES ('5435', '6', '5435 1191182336 3 21013 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 0 0 ', '');
INSERT INTO `item_instance` VALUES ('7885', '6', '7885 1191182336 3 20994 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11063', '9', '11063 1191182336 3 38147 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');
INSERT INTO `item_instance` VALUES ('11065', '9', '11065 1191182336 3 41751 1065353216 0 9 0 9 0 0 0 0 0 10 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ', '');

-- ----------------------------
-- Table structure for `item_loot`
-- ----------------------------
DROP TABLE IF EXISTS `item_loot`;
CREATE TABLE `item_loot` (
  `guid` int(11) unsigned NOT NULL default '0',
  `owner_guid` int(11) unsigned NOT NULL default '0',
  `itemid` int(11) unsigned NOT NULL default '0',
  `amount` int(11) unsigned NOT NULL default '0',
  `suffix` int(11) unsigned NOT NULL default '0',
  `property` int(11) NOT NULL default '0',
  PRIMARY KEY  (`guid`,`itemid`),
  KEY `idx_owner_guid` (`owner_guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Item System';

-- ----------------------------
-- Records of item_loot
-- ----------------------------

-- ----------------------------
-- Table structure for `mail`
-- ----------------------------
DROP TABLE IF EXISTS `mail`;
CREATE TABLE `mail` (
  `id` int(11) unsigned NOT NULL default '0' COMMENT 'Identifier',
  `messageType` tinyint(3) unsigned NOT NULL default '0',
  `stationery` tinyint(3) NOT NULL default '41',
  `mailTemplateId` mediumint(8) unsigned NOT NULL default '0',
  `sender` int(11) unsigned NOT NULL default '0' COMMENT 'Character Global Unique Identifier',
  `receiver` int(11) unsigned NOT NULL default '0' COMMENT 'Character Global Unique Identifier',
  `subject` longtext,
  `body` longtext,
  `has_items` tinyint(3) unsigned NOT NULL default '0',
  `expire_time` bigint(40) NOT NULL default '0',
  `deliver_time` bigint(40) NOT NULL default '0',
  `money` int(11) unsigned NOT NULL default '0',
  `cod` int(11) unsigned NOT NULL default '0',
  `checked` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_receiver` (`receiver`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Mail System';

-- ----------------------------
-- Records of mail
-- ----------------------------
INSERT INTO `mail` VALUES ('2', '0', '61', '0', '2', '2', 'This item(s) have problems with equipping/storing in inventory.', 'There\'s were problems with equipping item(s).', '1', '1293010901', '1290418901', '0', '0', '4');

-- ----------------------------
-- Table structure for `mail_items`
-- ----------------------------
DROP TABLE IF EXISTS `mail_items`;
CREATE TABLE `mail_items` (
  `mail_id` int(11) NOT NULL default '0',
  `item_guid` int(11) NOT NULL default '0',
  `item_template` int(11) NOT NULL default '0',
  `receiver` int(11) unsigned NOT NULL default '0' COMMENT 'Character Global Unique Identifier',
  PRIMARY KEY  (`mail_id`,`item_guid`),
  KEY `idx_receiver` (`receiver`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of mail_items
-- ----------------------------
INSERT INTO `mail_items` VALUES ('2', '38', '1395', '2');
INSERT INTO `mail_items` VALUES ('2', '40', '6096', '2');
INSERT INTO `mail_items` VALUES ('2', '504', '47', '2');
INSERT INTO `mail_items` VALUES ('2', '506', '2092', '2');
INSERT INTO `mail_items` VALUES ('2', '508', '50055', '2');
INSERT INTO `mail_items` VALUES ('2', '512', '6948', '2');

-- ----------------------------
-- Table structure for `pet_aura`
-- ----------------------------
DROP TABLE IF EXISTS `pet_aura`;
CREATE TABLE `pet_aura` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `caster_guid` bigint(20) unsigned NOT NULL default '0' COMMENT 'Full Global Unique Identifier',
  `item_guid` int(11) unsigned NOT NULL default '0',
  `spell` int(11) unsigned NOT NULL default '0',
  `stackcount` int(11) NOT NULL default '1',
  `remaincharges` int(11) NOT NULL default '0',
  `basepoints0` int(11) NOT NULL default '0',
  `basepoints1` int(11) NOT NULL default '0',
  `basepoints2` int(11) NOT NULL default '0',
  `maxduration0` int(11) NOT NULL default '0',
  `maxduration1` int(11) NOT NULL default '0',
  `maxduration2` int(11) NOT NULL default '0',
  `remaintime0` int(11) NOT NULL default '0',
  `remaintime1` int(11) NOT NULL default '0',
  `remaintime2` int(11) NOT NULL default '0',
  `effIndexMask` int(11) NOT NULL default '0',
  PRIMARY KEY  (`guid`,`caster_guid`,`item_guid`,`spell`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Pet System';

-- ----------------------------
-- Records of pet_aura
-- ----------------------------

-- ----------------------------
-- Table structure for `pet_spell`
-- ----------------------------
DROP TABLE IF EXISTS `pet_spell`;
CREATE TABLE `pet_spell` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier',
  `spell` int(11) unsigned NOT NULL default '0' COMMENT 'Spell Identifier',
  `active` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`spell`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Pet System';

-- ----------------------------
-- Records of pet_spell
-- ----------------------------

-- ----------------------------
-- Table structure for `pet_spell_cooldown`
-- ----------------------------
DROP TABLE IF EXISTS `pet_spell_cooldown`;
CREATE TABLE `pet_spell_cooldown` (
  `guid` int(11) unsigned NOT NULL default '0' COMMENT 'Global Unique Identifier, Low part',
  `spell` int(11) unsigned NOT NULL default '0' COMMENT 'Spell Identifier',
  `time` bigint(20) unsigned NOT NULL default '0',
  PRIMARY KEY  (`guid`,`spell`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pet_spell_cooldown
-- ----------------------------

-- ----------------------------
-- Table structure for `petition`
-- ----------------------------
DROP TABLE IF EXISTS `petition`;
CREATE TABLE `petition` (
  `ownerguid` int(10) unsigned NOT NULL,
  `petitionguid` int(10) unsigned default '0',
  `name` varchar(255) NOT NULL default '',
  `type` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`ownerguid`,`type`),
  UNIQUE KEY `index_ownerguid_petitionguid` (`ownerguid`,`petitionguid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Guild System';

-- ----------------------------
-- Records of petition
-- ----------------------------

-- ----------------------------
-- Table structure for `petition_sign`
-- ----------------------------
DROP TABLE IF EXISTS `petition_sign`;
CREATE TABLE `petition_sign` (
  `ownerguid` int(10) unsigned NOT NULL,
  `petitionguid` int(11) unsigned NOT NULL default '0',
  `playerguid` int(11) unsigned NOT NULL default '0',
  `player_account` int(11) unsigned NOT NULL default '0',
  `type` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`petitionguid`,`playerguid`),
  KEY `Idx_playerguid` (`playerguid`),
  KEY `Idx_ownerguid` (`ownerguid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Guild System';

-- ----------------------------
-- Records of petition_sign
-- ----------------------------

-- ----------------------------
-- Table structure for `saved_variables`
-- ----------------------------
DROP TABLE IF EXISTS `saved_variables`;
CREATE TABLE `saved_variables` (
  `NextArenaPointDistributionTime` bigint(40) unsigned NOT NULL default '0',
  `NextDailyQuestResetTime` bigint(40) unsigned NOT NULL default '0',
  `NextWeeklyQuestResetTime` bigint(40) unsigned NOT NULL default '0',
  `NextRandomBGResetTime` bigint(40) unsigned NOT NULL default '0',
  `NextMonthlyQuestResetTime` bigint(40) unsigned NOT NULL default '0',
  `cleaning_flags` int(11) unsigned NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='Variable Saves';

-- ----------------------------
-- Records of saved_variables
-- ----------------------------
INSERT INTO `saved_variables` VALUES ('0', '1291806000', '1291806000', '1291806000', '1293858000', '0');
INSERT INTO `saved_variables` VALUES ('0', '1291806000', '1291806000', '1291806000', '1293858000', '0');
INSERT INTO `saved_variables` VALUES ('0', '1291806000', '1291806000', '1291806000', '1293858000', '0');
