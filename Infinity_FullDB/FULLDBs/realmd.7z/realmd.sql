/*
Navicat MySQL Data Transfer

Source Server         : 127.0.0.1_3306
Source Server Version : 50045
Source Host           : 127.0.0.1:3306
Source Database       : realmd

Target Server Type    : MYSQL
Target Server Version : 50045
File Encoding         : 65001

Date: 2010-12-08 05:08:50
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `account`
-- ----------------------------
DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
  `id` int(11) unsigned NOT NULL auto_increment COMMENT 'Identifier',
  `username` varchar(32) NOT NULL default '',
  `sha_pass_hash` varchar(40) NOT NULL default '',
  `gmlevel` tinyint(3) unsigned NOT NULL default '0',
  `sessionkey` longtext,
  `v` longtext,
  `s` longtext,
  `email` text,
  `joindate` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `last_ip` varchar(30) NOT NULL default '0.0.0.0',
  `failed_logins` int(11) unsigned NOT NULL default '0',
  `locked` tinyint(3) unsigned NOT NULL default '0',
  `last_login` timestamp NOT NULL default '0000-00-00 00:00:00',
  `active_realm_id` int(11) unsigned NOT NULL default '0',
  `expansion` tinyint(3) unsigned NOT NULL default '0',
  `mutetime` bigint(40) unsigned NOT NULL default '0',
  `locale` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `idx_username` (`username`),
  KEY `idx_gmlevel` (`gmlevel`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Account System';

-- ----------------------------
-- Records of account
-- ----------------------------
INSERT INTO `account` VALUES ('5', 'ADMIN', '8301316D0D8448A34FA6D0C6BF1CBFA2B4A1A93A', '3', '655E24E6D841C969A8D67884FD909C07D116089DDC309D72CDF29C70B7C468D8D741054CFE5EF00F', '29D45DA3F2B02CAE3F2179491C8F2860BA2A5A1EBBBFB5F0D6D2A62D34C38995', 'D9004F6FE02075E0CA0A4C467B8DD91569C67CA3E3338596FF9E5C11ED40779B', null, '2010-11-14 16:58:05', '127.0.0.1', '0', '0', '2010-12-08 05:04:07', '0', '3', '0', '0');

-- ----------------------------
-- Table structure for `account_banned`
-- ----------------------------
DROP TABLE IF EXISTS `account_banned`;
CREATE TABLE `account_banned` (
  `id` int(11) NOT NULL default '0' COMMENT 'Account id',
  `bandate` bigint(40) NOT NULL default '0',
  `unbandate` bigint(40) NOT NULL default '0',
  `bannedby` varchar(50) NOT NULL,
  `banreason` varchar(255) NOT NULL,
  `active` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`id`,`bandate`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Ban List';

-- ----------------------------
-- Records of account_banned
-- ----------------------------

-- ----------------------------
-- Table structure for `ip_banned`
-- ----------------------------
DROP TABLE IF EXISTS `ip_banned`;
CREATE TABLE `ip_banned` (
  `ip` varchar(32) NOT NULL default '0.0.0.0',
  `bandate` bigint(40) NOT NULL,
  `unbandate` bigint(40) NOT NULL,
  `bannedby` varchar(50) NOT NULL default '[Console]',
  `banreason` varchar(255) NOT NULL default 'no reason',
  PRIMARY KEY  (`ip`,`bandate`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Banned IPs';

-- ----------------------------
-- Records of ip_banned
-- ----------------------------

-- ----------------------------
-- Table structure for `log`
-- ----------------------------
DROP TABLE IF EXISTS `log`;
CREATE TABLE `log` (
  `entry` int(10) unsigned NOT NULL auto_increment,
  `email` varchar(32) default NULL,
  `txn_id` varchar(32) default NULL,
  `date` datetime default NULL,
  `status` varchar(16) default NULL,
  `amount` float unsigned default NULL,
  `info` blob,
  PRIMARY KEY  (`entry`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of log
-- ----------------------------

-- ----------------------------
-- Table structure for `realmcharacters`
-- ----------------------------
DROP TABLE IF EXISTS `realmcharacters`;
CREATE TABLE `realmcharacters` (
  `realmid` int(11) unsigned NOT NULL default '0',
  `acctid` bigint(20) unsigned NOT NULL,
  `numchars` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`realmid`,`acctid`),
  KEY `acctid` (`acctid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Realm Character Tracker';

-- ----------------------------
-- Records of realmcharacters
-- ----------------------------
INSERT INTO `realmcharacters` VALUES ('1', '1', '0');
INSERT INTO `realmcharacters` VALUES ('1', '2', '0');
INSERT INTO `realmcharacters` VALUES ('1', '3', '0');
INSERT INTO `realmcharacters` VALUES ('1', '4', '0');
INSERT INTO `realmcharacters` VALUES ('1', '5', '3');
INSERT INTO `realmcharacters` VALUES ('1', '6', '2');

-- ----------------------------
-- Table structure for `realmd_db_version`
-- ----------------------------
DROP TABLE IF EXISTS `realmd_db_version`;
CREATE TABLE `realmd_db_version` (
  `required_10008_01_realmd_realmd_db_version` bit(1) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='Last applied sql update to DB';

-- ----------------------------
-- Records of realmd_db_version
-- ----------------------------
INSERT INTO `realmd_db_version` VALUES (null);

-- ----------------------------
-- Table structure for `realmlist`
-- ----------------------------
DROP TABLE IF EXISTS `realmlist`;
CREATE TABLE `realmlist` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `name` varchar(32) NOT NULL default '',
  `address` varchar(32) NOT NULL default '127.0.0.1',
  `port` int(11) NOT NULL default '8085',
  `icon` tinyint(3) unsigned NOT NULL default '0',
  `realmflags` tinyint(3) unsigned NOT NULL default '2' COMMENT 'Supported masks: 0x1 (invalid, not show in realm list), 0x2 (offline, set by mangosd), 0x4 (show version and build), 0x20 (new players), 0x40 (recommended)',
  `timezone` tinyint(3) unsigned NOT NULL default '0',
  `allowedSecurityLevel` tinyint(3) unsigned NOT NULL default '0',
  `population` float unsigned NOT NULL default '0',
  `realmbuilds` varchar(64) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `idx_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Realm System';

-- ----------------------------
-- Records of realmlist
-- ----------------------------
INSERT INTO `realmlist` VALUES ('1', 'The_Fallen_Server', '127.0.0.1', '8085', '1', '0', '1', '0', '0.02', '12340 ');

-- ----------------------------
-- Table structure for `shop_points`
-- ----------------------------
DROP TABLE IF EXISTS `shop_points`;
CREATE TABLE `shop_points` (
  `id` bigint(20) unsigned NOT NULL,
  `points` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of shop_points
-- ----------------------------

-- ----------------------------
-- Table structure for `uptime`
-- ----------------------------
DROP TABLE IF EXISTS `uptime`;
CREATE TABLE `uptime` (
  `realmid` int(11) unsigned NOT NULL,
  `starttime` bigint(20) unsigned NOT NULL default '0',
  `startstring` varchar(64) NOT NULL default '',
  `uptime` bigint(20) unsigned NOT NULL default '0',
  `maxplayers` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`realmid`,`starttime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Uptime system';

-- ----------------------------
-- Records of uptime
-- ----------------------------
INSERT INTO `uptime` VALUES ('1', '1291802114', '2010-12-08 04:55:14', '603', '1');
INSERT INTO `uptime` VALUES ('1', '1291801922', '2010-12-08 04:52:02', '0', '0');
INSERT INTO `uptime` VALUES ('1', '1291801696', '2010-12-08 04:48:16', '0', '0');
INSERT INTO `uptime` VALUES ('1', '1291801517', '2010-12-08 04:45:17', '0', '0');
INSERT INTO `uptime` VALUES ('1', '1291800804', '2010-12-08 04:33:24', '0', '0');
INSERT INTO `uptime` VALUES ('1', '1291598378', '2010-12-05 20:19:38', '0', '0');
INSERT INTO `uptime` VALUES ('1', '1291597780', '2010-12-05 20:09:40', '0', '0');
INSERT INTO `uptime` VALUES ('1', '1291597624', '2010-12-05 20:07:04', '0', '0');
INSERT INTO `uptime` VALUES ('1', '1291597404', '2010-12-05 20:03:24', '0', '0');
INSERT INTO `uptime` VALUES ('1', '1291587618', '2010-12-05 17:20:18', '0', '0');
INSERT INTO `uptime` VALUES ('1', '1291572699', '2010-12-05 13:11:39', '3003', '1');
INSERT INTO `uptime` VALUES ('1', '1291467627', '2010-12-04 08:00:27', '9003', '1');
INSERT INTO `uptime` VALUES ('1', '1291456687', '2010-12-04 04:58:07', '8406', '1');
INSERT INTO `uptime` VALUES ('1', '1291453407', '2010-12-04 04:03:27', '2402', '0');
INSERT INTO `uptime` VALUES ('1', '1291286236', '2010-12-02 05:37:16', '0', '0');
INSERT INTO `uptime` VALUES ('1', '1291285134', '2010-12-02 05:18:54', '0', '0');
INSERT INTO `uptime` VALUES ('1', '1291283957', '2010-12-02 04:59:17', '0', '0');
INSERT INTO `uptime` VALUES ('1', '1291276318', '2010-12-02 02:51:58', '0', '0');
INSERT INTO `uptime` VALUES ('1', '1291276172', '2010-12-02 02:49:32', '0', '0');
INSERT INTO `uptime` VALUES ('1', '1291275169', '2010-12-02 02:32:49', '602', '0');
INSERT INTO `uptime` VALUES ('1', '1291274464', '2010-12-02 02:21:04', '0', '0');
INSERT INTO `uptime` VALUES ('1', '1291272377', '2010-12-02 01:46:17', '1810', '1');
INSERT INTO `uptime` VALUES ('1', '1290969879', '2010-11-28 13:44:39', '0', '0');
INSERT INTO `uptime` VALUES ('1', '1290965848', '2010-11-28 12:37:28', '3002', '1');
INSERT INTO `uptime` VALUES ('1', '1290957565', '2010-11-28 10:19:25', '2403', '1');
INSERT INTO `uptime` VALUES ('1', '1290847348', '2010-11-27 03:42:28', '1803', '1');
INSERT INTO `uptime` VALUES ('1', '1290846423', '2010-11-27 03:27:03', '603', '0');
INSERT INTO `uptime` VALUES ('1', '1290825486', '2010-11-26 21:38:06', '9603', '1');
INSERT INTO `uptime` VALUES ('1', '1290821403', '2010-11-26 20:30:03', '3601', '1');
INSERT INTO `uptime` VALUES ('1', '1290821252', '2010-11-26 20:27:32', '0', '0');
INSERT INTO `uptime` VALUES ('1', '1290820770', '2010-11-26 20:19:30', '0', '0');

-- ----------------------------
-- Table structure for `voting`
-- ----------------------------
DROP TABLE IF EXISTS `voting`;
CREATE TABLE `voting` (
  `user_ip` varchar(30) NOT NULL,
  `sites` int(10) unsigned NOT NULL default '0',
  `time` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`user_ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of voting
-- ----------------------------
