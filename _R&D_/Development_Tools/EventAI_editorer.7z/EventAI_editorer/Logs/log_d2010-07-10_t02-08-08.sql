--
-- Session start: 2010.07.10 - 02:08:08 @haze family
--
UPDATE creature_ai_scripts SET event_type = 4, event_param1 = 0, event_param2 = 0, event_param3 = 0, event_param4 = 0, action1_type = 21, action1_param1 = 0, action1_param2 = 0, action1_param3 = 0, action2_type = 0, action2_param1 = 0 WHERE id = 670001552;
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 2, 0, 100, 1, 100, 1, 1, 100, 11, 53117, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, '0');
REPLACE INTO creature_ai_scripts VALUES (NULL, 29102, 4, 0, 100, 1, 0, 0, 0, 0, 21, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
REPLACE INTO creature_ai_scripts VALUES (NULL, 29102, 2, 0, 100, 1, 100, 1, 1, 100, 11, 53345, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, '');
REPLACE INTO creature_ai_scripts VALUES (NULL, 29103, 4, 0, 100, 1, 0, 0, 0, 0, 21, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
REPLACE INTO creature_ai_scripts VALUES (NULL, 29103, 2, 0, 100, 1, 100, 1, 1, 100, 11, 53345, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, '');
--
-- Session end: 2010.07.10 - 02:27:11 @haze family
--