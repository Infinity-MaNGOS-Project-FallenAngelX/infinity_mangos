--
-- Session start: 2010.07.08 - 09:41:37 @haze family
--
UPDATE creature_ai_scripts SET  WHERE id = 670001554;
UPDATE creature_ai_scripts SET event_type = 4, action1_type = 11, action1_param1 = 53117, action1_param2 = 1, action1_param3 = 1, action2_type = 21 WHERE id = 670001554;
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 6, 251658240, 100, 0, 0, 0, 0, 0, 15, 12779, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
--
-- Session end: 2010.07.08 - 10:55:14 @haze family
--