--
-- Session start: 2010.07.08 - 09:21:41 @haze family
--
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 4, 0, 100, 1, 0, 0, 0, 0, 20, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'scarlet ballista');
--
-- Session end: 2010.07.08 - 09:27:43 @haze family
--