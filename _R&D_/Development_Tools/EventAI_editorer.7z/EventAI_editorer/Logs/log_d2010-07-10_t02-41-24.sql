--
-- Session start: 2010.07.10 - 02:41:25 @haze family
--
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 6, 0, 100, 0, 0, 0, 0, 0, 33, 29104, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
REPLACE INTO creature_ai_scripts VALUES (NULL, 29102, 6, 0, 100, 0, 0, 0, 0, 0, 33, 29102, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
REPLACE INTO creature_ai_scripts VALUES (NULL, 29103, 6, 0, 100, 0, 0, 0, 0, 0, 33, 29103, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
--
-- Session end: 2010.07.10 - 02:51:22 @haze family
--