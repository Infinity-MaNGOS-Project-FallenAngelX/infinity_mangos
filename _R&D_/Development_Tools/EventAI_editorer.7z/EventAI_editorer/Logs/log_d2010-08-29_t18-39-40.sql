--
-- Session start: 2010.08.29 - 18:39:41 @haze family
--
UPDATE creature_ai_scripts SET event_param1 = 999 WHERE id = 670001547;
--
-- Session end: 2010.08.29 - 18:40:03 @haze family
--