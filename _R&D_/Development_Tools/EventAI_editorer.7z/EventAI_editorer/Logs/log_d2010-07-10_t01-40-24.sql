--
-- Session start: 2010.07.10 - 01:40:24 @haze family
--
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 2, 0, 100, 1, 100, 1, 1, 99, 11, 53117, 1, 7, 21, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE creature_ai_scripts SET event_param4 = 100, action1_type = 21, action1_param1 = 0, action1_param2 = 0, action1_param3 = 0, action2_type = 11, action2_param1 = 53117, action2_param2 = 1, action2_param3 = 7, action3_type = 21 WHERE id = 670001552;
UPDATE creature_ai_scripts SET action3_type = 0 WHERE id = 670001552;
UPDATE creature_ai_scripts SET action1_type = 11, action1_param1 = 53117, action1_param2 = 1, action1_param3 = 7, action2_type = 18, action2_param1 = 4, action2_param2 = 0, action2_param3 = 0 WHERE id = 670001552;
--
-- Session end: 2010.07.10 - 02:06:41 @haze family
--