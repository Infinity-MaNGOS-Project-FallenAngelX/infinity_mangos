--
-- Session start: 2010.07.09 - 05:23:22 @haze family
--
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 4, 0, 100, 1, 0, 0, 0, 0, 11, 53117, 1, 22, 21, 1, 0, 0, 22, 1, 0, 0, '');
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 0, 2147483645, 100, 1, 30, 45, 30, 45, 11, 53117, 1, 22, 22, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE creature_ai_scripts SET event_type = 2, event_flags = 0, event_param1 = 100, event_param4 = 100, action2_param1 = 0 WHERE id = 670001552;
UPDATE creature_ai_scripts SET event_flags = 0 WHERE id = 670001553;
DELETE FROM creature_ai_scripts WHERE id = 670001553;
DELETE FROM creature_ai_scripts WHERE id = 670001553;
UPDATE creature_ai_scripts SET event_type = 4, event_flags = 1, event_param1 = 0, event_param4 = 0, action3_type = 0, action3_param1 = 0 WHERE id = 670001552;
DELETE FROM creature_ai_scripts WHERE id = 670001552;
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 5, 0, 100, 1, 1, 1, 0, 0, 11, 53117, 1, 1, 21, 0, 0, 0, 11, 53117, 1, 1, '');
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 5, 0, 100, 1, 1, 1, 0, 0, 11, 53117, 1, 1, 21, 0, 0, 0, 11, 53117, 1, 1, '0');
DELETE FROM creature_ai_scripts WHERE id = 670001554;
--
-- Session end: 2010.07.09 - 05:49:19 @haze family
--