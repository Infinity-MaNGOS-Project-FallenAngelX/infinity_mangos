--
-- Session start: 2010.07.09 - 05:51:42 @haze family
--
UPDATE creature_ai_scripts SET event_type = 4, event_flags = 0, event_param1 = 0, event_param2 = 0, action3_type = 22, action3_param1 = 1, action3_param2 = 0, action3_param3 = 0 WHERE id = 670001555;
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 2, 2147483645, 100, 0, 100, 5, 0, 0, 11, 53117, 1, 1, 21, 0, 0, 0, 22, 1, 0, 0, '0');
UPDATE creature_ai_scripts SET event_inverse_phase_mask = 2147483646, event_flags = 1, action3_type = 11, action3_param1 = 53117, action3_param2 = 1, action3_param3 = 1 WHERE id = 670001555;
UPDATE creature_ai_scripts SET event_flags = 1 WHERE id = 670001556;
UPDATE creature_ai_scripts SET event_inverse_phase_mask = 2147483646, action3_type = 0, action3_param1 = 0 WHERE id = 670001556;
UPDATE creature_ai_scripts SET action3_type = 22, action3_param1 = 1 WHERE id = 670001556;
UPDATE creature_ai_scripts SET action3_type = 22, action3_param1 = 1, action3_param2 = 0, action3_param3 = 0 WHERE id = 670001555;
UPDATE creature_ai_scripts SET event_param1 = , event_param2 = , event_param3 = 5, event_param4 = 100 WHERE id = 670001556;
UPDATE creature_ai_scripts SET event_param1 = , event_param2 = , event_param3 = 5, event_param4 = 100 WHERE id = 670001556;
DELETE FROM creature_ai_scripts WHERE id = 670001556;
DELETE FROM creature_ai_scripts WHERE id = 670001556;
DELETE FROM creature_ai_scripts WHERE id = 670001556;
DELETE FROM creature_ai_scripts WHERE id = 670001556;
DELETE FROM creature_ai_scripts WHERE id = 670001556;
DELETE FROM creature_ai_scripts WHERE id = 670001556;
DELETE FROM creature_ai_scripts WHERE id = 670001556;
DELETE FROM creature_ai_scripts WHERE id = 670001556;
DELETE FROM creature_ai_scripts WHERE id = 670001555;
DELETE FROM creature_ai_scripts WHERE id = 670001555;
DELETE FROM creature_ai_scripts WHERE id = 670001555;
DELETE FROM creature_ai_scripts WHERE id = 670001555;
DELETE FROM creature_ai_scripts WHERE id = 670001555;
DELETE FROM creature_ai_scripts WHERE id = 670001555;
DELETE FROM creature_ai_scripts WHERE id = 670001555;
DELETE FROM creature_ai_scripts WHERE id = 670001555;
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 4, 2147483646, 100, 1, 0, 0, 0, 0, 11, 53117, 1, 1, 21, 0, 0, 0, 22, 1, 0, 0, '0');
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 4, 2147483646, 100, 1, 0, 0, 0, 0, 11, 53117, 1, 1, 21, 0, 0, 0, 22, 1, 0, 0, '0');
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 4, 2147483646, 100, 1, 0, 0, 0, 0, 11, 53117, 1, 1, 21, 0, 0, 0, 22, 1, 0, 0, '0');
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 4, 2147483646, 100, 1, 0, 0, 0, 0, 11, 53117, 1, 1, 21, 0, 0, 0, 22, 1, 0, 0, '0');
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 4, 2147483646, 100, 1, 0, 0, 0, 0, 11, 53117, 1, 1, 21, 0, 0, 0, 22, 1, 0, 0, '0');
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 4, 2147483646, 100, 1, 0, 0, 0, 0, 11, 53117, 1, 1, 21, 0, 0, 0, 22, 1, 0, 0, '0');
--
-- Session end: 2010.07.09 - 06:05:16 @haze family
--