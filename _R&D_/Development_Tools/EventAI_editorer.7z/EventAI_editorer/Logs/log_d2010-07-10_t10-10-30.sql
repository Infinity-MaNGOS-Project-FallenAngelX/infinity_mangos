--
-- Session start: 2010.07.10 - 10:10:30 @haze family
--
UPDATE creature_ai_scripts SET event_flags = 0 WHERE id = 670001552;
UPDATE creature_ai_scripts SET event_flags = 0 WHERE id = 670001556;
UPDATE creature_ai_scripts SET event_flags = 0 WHERE id = 670001554;
--
-- Session end: 2010.07.10 - 10:12:09 @haze family
--