--
-- Session start: 2010.07.08 - 13:25:03 @haze family
--
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 4, 2147483646, 100, 1, 0, 0, 0, 0, 11, 53117, 1, 1, 21, 0, 0, 0, 22, 1, 0, 0, 'aggro no move start arrow');
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 4, 2147483646, 100, 0, 0, 0, 0, 0, 11, 53117, 1, 1, 21, 0, 0, 0, 22, 1, 0, 0, 'aggro no move start arrow');
DELETE FROM creature_ai_scripts WHERE id = 670001556;
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 0, 2147483646, 100, 1, 10, 30, 5, 90, 11, 53117, 1, 1, 15, 12779, 0, 0, 22, 2, 0, 0, 'phase 1-- ballista assuaslt');
UPDATE creature_ai_scripts SET event_flags = 0 WHERE id = 670001558;
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 6, 0, 100, 0, 0, 0, 0, 0, 26, 12779, 0, 0, 22, 0, 0, 0, 0, 0, 0, 0, 'phase 2');
UPDATE creature_ai_scripts SET event_inverse_phase_mask = 2147483646 WHERE id = 670001559;
--
-- Session end: 2010.07.08 - 22:16:46 @haze family
--