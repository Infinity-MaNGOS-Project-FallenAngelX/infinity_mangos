--
-- Session start: 2010.07.09 - 03:30:53 @haze family
--
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 5, 0, 100, 1, 0, 0, 0, 0, 33, 29104, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
UPDATE creature_ai_scripts SET event_type = 6, action1_type = 15, action1_param1 = 12779, action2_type = 33, action2_param1 = 29104, action2_param2 = 6 WHERE id = 670001552;
--
-- Session end: 2010.07.09 - 04:08:07 @haze family
--