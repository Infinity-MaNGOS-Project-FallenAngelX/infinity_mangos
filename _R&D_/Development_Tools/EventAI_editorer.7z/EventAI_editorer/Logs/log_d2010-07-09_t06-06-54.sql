--
-- Session start: 2010.07.09 - 06:06:54 @haze family
--
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 4, 2147483645, 100, 0, 0, 0, 0, 0, 21, 0, 0, 0, 39, 150, 0, 0, 0, 0, 0, 0, '');
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 2, 2147483646, 100, 1, 100, 90, 1, 90, 11, 53117, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
--
-- Session end: 2010.07.09 - 06:12:26 @haze family
--