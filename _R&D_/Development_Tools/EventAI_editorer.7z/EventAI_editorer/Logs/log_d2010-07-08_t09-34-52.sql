--
-- Session start: 2010.07.08 - 09:34:52 @haze family
--
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 4, 0, 100, 1, 0, 0, 0, 0, 20, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'scarlet ballista');
DELETE FROM creature_ai_scripts WHERE id = 670001553;
REPLACE INTO creature_ai_scripts VALUES (NULL, 29104, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM creature_ai_scripts WHERE id = 670001552;
UPDATE creature_ai_scripts SET event_flags = 1 WHERE id = 670001554;
--
-- Session end: 2010.07.08 - 09:40:37 @haze family
--