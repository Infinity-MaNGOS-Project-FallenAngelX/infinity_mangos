--
-- Session start: 2010.08.29 - 18:27:20 @haze family
--
REPLACE INTO creature_ai_scripts VALUES (NULL, 9999999, 22, 0, 100, 6, 0, 0, 0, 0, 12, 39863, 4, 999999999999999999999999999999999999999, 0, 0, 0, 0, 0, 0, 0, 0, '');
REPLACE INTO creature_ai_scripts VALUES (NULL, 9999999, 22, 0, 100, 6, -1666203, 0, 0, 0, 12, 39863, 4, 999999999999999999999999999999999999999, 0, 0, 0, 0, 0, 0, 0, 0, '');
DELETE FROM creature_ai_scripts WHERE id = 670001546;
--
-- Session end: 2010.08.29 - 18:33:46 @haze family
--