-- 11/16/2010 10:40:46 AM
UPDATE `creature_template` SET `ScriptName` = 'npc_scarlet_minecar' WHERE `entry` = 28817;
-- 11/16/2010 11:25:34 PM
DELETE FROM `creature_template_addon` WHERE (`entry`=28864);
INSERT INTO `creature_template_addon` (`entry`, `mount`, `bytes1`, `bytes2`, `emote`, `moveflags`, `auras`) VALUES (28864, 0, 0, 0, 0, 0, '61453 0 61453 2');
-- 11/17/2010 12:55:58 AM
UPDATE `creature_template` SET `spell4` = 52588 WHERE `entry` = 28833;
-- 11/17/2010 1:37:16 AM
UPDATE `creature_template` SET `spell4` = 0 WHERE `entry` = 28833;
-- 11/17/2010 1:38:04 AM
UPDATE `creature_template` SET `spell1` = 57403 WHERE `entry` = 28864;
-- 11/17/2010 1:51:18 AM
DELETE FROM `creature_template_addon` WHERE (`entry`=28864);
INSERT INTO `creature_template_addon` (`entry`, `mount`, `bytes1`, `bytes2`, `emote`, `moveflags`, `auras`) VALUES (28864, 0, 0, 0, 0, 0, '61453 0 61453 2');

-- 11/17/2010 2:22:30 AM
UPDATE `creature_template` SET `ScriptName` = 'mob_land_cannon' WHERE `entry` = 28850;
-- 11/17/2010 2:42:00 AM
DELETE FROM `creature` WHERE `id`=28833;
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`phaseMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(4456475, 28833, 609, 1, 1, 0, 0, 2265.26, -6190.15, 12.9752, 1.94359, 25, 0, 0, 26140, 2117, 0, 0),
(4456468, 28833, 609, 1, 1, 0, 0, 2110.31, -6182.88, 12.9535, 1.23178, 25, 0, 0, 26140, 2117, 0, 0),
(4456467, 28833, 609, 1, 1, 0, 0, 2115.53, -6185.41, 13.0516, 1.21455, 25, 0, 0, 26140, 2117, 0, 0),
(4456473, 28833, 609, 1, 1, 0, 0, 2259.49, -6192.26, 12.8938, 1.82874, 25, 0, 0, 26140, 2117, 0, 0),
(4456474, 28833, 609, 1, 1, 0, 0, 2253.41, -6194.36, 12.8233, 1.83659, 25, 0, 0, 26140, 2117, 0, 0),
(4456469, 28833, 609, 1, 1, 0, 0, 2104.37, -6180.76, 12.8765, 1.22786, 25, 0, 0, 26140, 2117, 0, 0);

-- 11/17/2010 4:50:24 AM
DELETE FROM `creature_questrelation` WHERE `quest` = 12717;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 12717;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 12717;
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 28919;
INSERT INTO `gameobject_questrelation` (`id`, `quest`) VALUES (190936, 12717);
DELETE FROM `creature_involvedrelation` WHERE `quest` = 12717;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 12717;
INSERT INTO `gameobject_involvedrelation` (`id`, `quest`) VALUES (190936, 12717);

-- 11/17/2010 4:58:04 AM
DELETE FROM `creature_questrelation` WHERE `quest` = 12717;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 12717;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 12717;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (28919, 12717);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 28919;
DELETE FROM `creature_involvedrelation` WHERE `quest` = 12717;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 12717;
INSERT INTO `gameobject_involvedrelation` (`id`, `quest`) VALUES (190936, 12717);

-- 11/17/2010 5:01:33 AM
DELETE FROM `creature_questrelation` WHERE `quest` = 12716;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 12716;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 12716;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (28919, 12716);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 28919;
DELETE FROM `creature_involvedrelation` WHERE `quest` = 12716;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 12716;
INSERT INTO `creature_involvedrelation` (`id`, `quest`) VALUES (28919, 12716);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry`=28919;
UPDATE `quest_template` SET `ExclusiveGroup` = 12716 WHERE `entry` = 12716;
-- 11/17/2010 6:44:57 AM
DELETE FROM `creature_questrelation` WHERE `quest` = 12720;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 12720;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 12720;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (28911, 12720);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 28911;
DELETE FROM `creature_involvedrelation` WHERE `quest` = 12720;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 12720;
INSERT INTO `creature_involvedrelation` (`id`, `quest`) VALUES (28911, 12720);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry`=28911;
UPDATE `quest_template` SET `ReqSpellCast1` = 52781 WHERE `entry` = 12720;
-- 11/17/2010 6:56:09 AM
DELETE FROM `creature_questrelation` WHERE `quest` = 12720;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 12720;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 12720;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (28911, 12720);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 28911;
DELETE FROM `creature_involvedrelation` WHERE `quest` = 12720;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 12720;
INSERT INTO `creature_involvedrelation` (`id`, `quest`) VALUES (28911, 12720);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry`=28911;
UPDATE `quest_template` SET `ReqCreatureOrGOId1` = 28984 WHERE `entry` = 12720;
-- 11/17/2010 7:01:07 AM
DELETE FROM `creature_questrelation` WHERE `quest` = 12720;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 12720;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 12720;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (28911, 12720);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 28911;
DELETE FROM `creature_involvedrelation` WHERE `quest` = 12720;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 12720;
INSERT INTO `creature_involvedrelation` (`id`, `quest`) VALUES (28911, 12720);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry`=28911;
UPDATE `quest_template` SET `ReqCreatureOrGOCount1` = 1 WHERE `entry` = 12720;
-- 11/17/2010 7:43:05 AM
DELETE FROM `creature_questrelation` WHERE `quest` = 12720;
DELETE FROM `gameobject_questrelation` WHERE `quest` = 12720;
UPDATE `item_template` SET `StartQuest`=0 WHERE `StartQuest` = 12720;
INSERT INTO `creature_questrelation` (`id`, `quest`) VALUES (28911, 12720);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry` = 28911;
DELETE FROM `creature_involvedrelation` WHERE `quest` = 12720;
DELETE FROM `gameobject_involvedrelation` WHERE `quest` = 12720;
INSERT INTO `creature_involvedrelation` (`id`, `quest`) VALUES (28911, 12720);
UPDATE `creature_template` SET `npcflag`=`npcflag`|2 WHERE `entry`=28911;
UPDATE `quest_template` SET `ReqCreatureOrGOId1` = 0, `ReqCreatureOrGOCount1` = 0, `ReqSpellCast1` = 0 WHERE `entry` = 12720;
-- 11/17/2010 8:43:34 AM
UPDATE `creature_template` SET `mechanic_immune_mask` = 2146435071 WHERE `entry` = 28447;
-- 11/17/2010 9:31:06 AM
DELETE FROM `creature` WHERE `id`=28957;
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`phaseMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(4457160, 28957, 609, 1, 4, 0, 0, 1416.47, -6017.81, 116.357, 1, 360, 0, 0, 0, 0, 0, 1);

-- 11/17/2010 9:59:09 AM
DELETE FROM `creature` WHERE `id`=28957;
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`phaseMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(4457160, 28957, 609, 1, 4, 0, 0, 1416.47, -6017.81, 116.357, 1, 360, 0, 0, 0, 0, 0, 1);

-- 11/17/2010 9:59:42 AM
DELETE FROM `creature` WHERE `id`=28957;
INSERT INTO `creature` (`guid`,`id`,`map`,`spawnMask`,`phaseMask`,`modelid`,`equipment_id`,`position_x`,`position_y`,`position_z`,`orientation`,`spawntimesecs`,`spawndist`,`currentwaypoint`,`curhealth`,`curmana`,`DeathState`,`MovementType`) VALUES
(4457160, 28957, 609, 1, 4, 0, 0, 1416.47, -6017.81, 116.357, 1, 360, 0, 0, 0, 0, 0, 0);

